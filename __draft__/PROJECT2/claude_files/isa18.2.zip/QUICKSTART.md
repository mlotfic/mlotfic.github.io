# Alarm Manager - Quickstart Guide

Get the alarm manager running in **5 minutes** with Docker Compose.

## Prerequisites

- Docker & Docker Compose installed
- PM5110 meter (or compatible Modbus device) on your network
- Network connectivity to the device

## Quick Setup

### 1. Clone/Extract the Module

```bash
cd alarm_manager
```

### 2. Configure Your Modbus Device

Edit `docker-compose.yml` and update the Modbus device IP address:

```yaml
alarm-manager:
  environment:
    MODBUS_HOST: 192.168.1.100  # ← CHANGE THIS to your device IP
```

### 3. Start All Services

```bash
docker-compose up -d
```

This starts:
- PostgreSQL database
- MQTT broker (Mosquitto)
- Alarm Manager application
- pgAdmin (database UI)
- MQTT Explorer (MQTT UI)

### 4. Verify Services

```bash
docker-compose ps
```

All services should show "Up" status.

### 5. Check Logs

```bash
docker-compose logs -f alarm-manager
```

You should see:
```
INFO - Database connection pool initialized
INFO - Connected to MQTT broker
INFO - ModbusPoller initialized for PM5110_MTR01
INFO - Alarm Manager initialized successfully
```

### 6. Monitor MQTT Messages

Open browser to http://localhost:4000 (MQTT Explorer)

Connect to `mosquitto:1883` and subscribe to:
```
UNS/#
```

You should see messages on:
- `UNS/EgyptPlant/devices/PM5110_MTR01/alarms/events`
- `UNS/EgyptPlant/scada/alarms/isa/events`

### 7. View Database

Open browser to http://localhost:5050 (pgAdmin)

Login:
- Email: `admin@localhost`
- Password: `admin`

Add server:
- Host: `postgres`
- Port: `5432`
- Database: `alarm_manager`
- Username: `postgres`
- Password: `postgres`

Query active alarms:
```sql
SELECT * FROM active_isa_alarms;
```

## Test the System

### Run Test Script

```bash
docker-compose exec alarm-manager python /app/tests/test_alarm_manager.py
```

Expected output:
```
✓ Database test PASSED
✓ MQTT test PASSED
✓ Storage test PASSED

Total: 3/3 tests passed
```

### Simulate an Alarm

Trigger an alarm on your PM5110 device (e.g., disconnect a phase).

Watch the logs:
```bash
docker-compose logs -f alarm-manager
```

You should see:
```
INFO - PM5110_MTR01 HR40112.bit0 (phase_loss): 0→1
INFO - Device alarm event stored: PM5110_MTR01/phase_loss state=ON
INFO - ISA alarm activated: PWR_PHASE_LOSS (suppressed=False)
```

Check MQTT Explorer - you'll see two events:
1. Device alarm event on `UNS/EgyptPlant/devices/PM5110_MTR01/alarms/events`
2. ISA alarm event on `UNS/EgyptPlant/scada/alarms/isa/events`

## Next Steps

### Customize Alarms

1. Edit CSV templates in `templates/`
2. Reimport to database:
   ```bash
   docker-compose exec postgres psql -U postgres -d alarm_manager -c "\COPY device_alarm_map FROM '/templates/device_alarm_map.csv' WITH (FORMAT csv, HEADER true);"
   ```
3. Restart alarm manager:
   ```bash
   docker-compose restart alarm-manager
   ```

### Add More Devices

Edit `config/config.yaml`:
```yaml
modbus_devices:
  - device_id: PM5110_MTR01
    host: 192.168.1.100
    # ... existing config
  
  - device_id: PM5110_MTR02  # New device
    host: 192.168.1.101
    port: 502
    unit_id: 1
    poll_interval_ms: 1000
    timeout_ms: 3000
    alarm_register: 40112
    alarm_register_type: holding
```

Restart:
```bash
docker-compose restart alarm-manager
```

### Connect Your SCADA/HMI

Subscribe to MQTT topics:
```
UNS/EgyptPlant/scada/alarms/isa/events
UNS/EgyptPlant/scada/alarms/isa/state
```

Use the JSON payloads to display alarms in your HMI.

## Troubleshooting

### Can't Connect to Modbus Device

```bash
# Test connectivity
docker-compose exec alarm-manager ping 192.168.1.100

# Check Modbus port
docker-compose exec alarm-manager nc -zv 192.168.1.100 502
```

### No Alarms in Database

Check if device is mapped:
```sql
SELECT * FROM device_alarm_map WHERE device_id = 'PM5110_MTR01';
```

If empty, import CSV:
```bash
docker-compose exec postgres psql -U postgres -d alarm_manager -c "\COPY device_alarm_map FROM '/templates/device_alarm_map.csv' WITH (FORMAT csv, HEADER true);"
```

### MQTT Not Publishing

Check broker logs:
```bash
docker-compose logs mosquitto
```

Test manually:
```bash
# Subscribe to all topics
docker-compose exec mosquitto mosquitto_sub -t 'UNS/#' -v

# In another terminal, publish test message
docker-compose exec mosquitto mosquitto_pub -t 'test' -m 'hello'
```

## Stop & Clean Up

```bash
# Stop all services
docker-compose down

# Stop and remove all data
docker-compose down -v
```

## Production Deployment

For production:

1. Change default passwords in `docker-compose.yml`
2. Enable MQTT authentication (edit `config/mosquitto.conf`)
3. Use external PostgreSQL/TimescaleDB
4. Set up backups
5. Configure firewall rules
6. Use SSL/TLS for MQTT
7. Set log level to WARNING or ERROR

See full README.md for production guidelines.

---

**Need Help?**

Check the logs:
```bash
docker-compose logs -f
```

Run diagnostics:
```bash
docker-compose exec alarm-manager python /app/tests/test_alarm_manager.py
```

Review documentation:
- `README.md` - Full documentation
- `docs/pm5110_alarm_mapping_guide.md` - Implementation guide
