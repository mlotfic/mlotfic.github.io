"""
Modbus Poller Module
Handles Modbus TCP polling and edge detection for alarm registers
"""

from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException
from datetime import datetime
from typing import Optional, Dict, List, Tuple
import logging
import time


logger = logging.getLogger(__name__)


class ModbusPoller:
    """Modbus TCP poller with edge detection"""
    
    def __init__(
        self,
        device_id: str,
        host: str,
        port: int = 502,
        unit_id: int = 1,
        timeout_ms: int = 3000
    ):
        """
        Initialize Modbus poller
        
        Args:
            device_id: Device identifier
            host: Modbus TCP host
            port: Modbus TCP port
            unit_id: Modbus unit/slave ID
            timeout_ms: Connection timeout (ms)
        """
        self.device_id = device_id
        self.host = host
        self.port = port
        self.unit_id = unit_id
        self.timeout_s = timeout_ms / 1000.0
        
        self.client = ModbusTcpClient(
            host=host,
            port=port,
            timeout=self.timeout_s
        )
        
        # Edge detection: store previous values
        self.previous_values: Dict[str, int] = {}
        
        # Connection state
        self.connected = False
        self.last_error: Optional[str] = None
        self.last_good_read: Optional[datetime] = None
        
        logger.info(f"ModbusPoller initialized for {device_id} at {host}:{port}")
    
    def connect(self) -> bool:
        """Establish Modbus connection"""
        try:
            self.connected = self.client.connect()
            if self.connected:
                logger.info(f"Connected to {self.device_id} at {self.host}:{self.port}")
                self.last_error = None
            else:
                self.last_error = "Connection failed"
                logger.error(f"Failed to connect to {self.device_id}")
            return self.connected
        except Exception as e:
            self.connected = False
            self.last_error = str(e)
            logger.error(f"Connection error for {self.device_id}: {e}")
            return False
    
    def disconnect(self):
        """Close Modbus connection"""
        try:
            self.client.close()
            self.connected = False
            logger.info(f"Disconnected from {self.device_id}")
        except Exception as e:
            logger.error(f"Disconnect error for {self.device_id}: {e}")
    
    def read_holding_register(
        self, 
        address: int, 
        count: int = 1
    ) -> Optional[List[int]]:
        """
        Read holding register(s)
        
        Args:
            address: Register address (Modbus addressing)
            count: Number of registers to read
        
        Returns:
            List of register values or None on error
        """
        if not self.connected:
            logger.warning(f"Not connected to {self.device_id}")
            return None
        
        try:
            # Note: pymodbus uses 0-based addressing
            # If your address is 40112 (Modbus addressing), use 40112-40001=111
            result = self.client.read_holding_registers(
                address=address - 40001,
                count=count,
                slave=self.unit_id
            )
            
            if result.isError():
                self.last_error = f"Modbus error: {result}"
                logger.error(f"Read error for {self.device_id} HR{address}: {result}")
                return None
            
            self.last_good_read = datetime.utcnow()
            self.last_error = None
            return result.registers
        
        except ModbusException as e:
            self.last_error = str(e)
            logger.error(f"Modbus exception for {self.device_id} HR{address}: {e}")
            return None
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"Unexpected error reading {self.device_id} HR{address}: {e}")
            return None
    
    def read_alarm_word(
        self, 
        address: int
    ) -> Tuple[Optional[int], str]:
        """
        Read alarm word register
        
        Args:
            address: Register address
        
        Returns:
            Tuple of (value, quality)
            quality: 'GOOD', 'BAD', 'UNCERTAIN'
        """
        values = self.read_holding_register(address, count=1)
        
        if values is None:
            return None, 'BAD'
        
        return values[0], 'GOOD'
    
    def detect_alarm_edges(
        self,
        address: int,
        current_value: int,
        bit_map: Dict[int, str]
    ) -> List[Dict]:
        """
        Detect alarm bit transitions (edges)
        
        Args:
            address: Register address
            current_value: Current register value
            bit_map: Mapping of bit number to alarm ID
        
        Returns:
            List of alarm transitions
            Each transition: {
                'bit': int,
                'alarm_id': str,
                'state': bool,
                'previous': int,
                'current': int
            }
        """
        register_key = f"HR{address}"
        previous_value = self.previous_values.get(register_key, 0)
        
        # XOR to find changed bits
        changed_bits = previous_value ^ current_value
        
        transitions = []
        
        # Check each bit
        for bit_num in range(16):  # 16-bit register
            bit_mask = 1 << bit_num
            
            # Only process if bit changed AND is in bit_map
            if (changed_bits & bit_mask) and (bit_num in bit_map):
                new_state = bool(current_value & bit_mask)
                
                transition = {
                    'bit': bit_num,
                    'alarm_id': bit_map[bit_num],
                    'state': new_state,
                    'previous': previous_value,
                    'current': current_value
                }
                transitions.append(transition)
                
                logger.debug(
                    f"{self.device_id} HR{address}.bit{bit_num} "
                    f"({bit_map[bit_num]}): "
                    f"{'0→1' if new_state else '1→0'}"
                )
        
        # Update previous value
        self.previous_values[register_key] = current_value
        
        return transitions
    
    def get_quality(self) -> str:
        """
        Get current connection quality
        
        Returns:
            'GOOD', 'BAD', or 'UNCERTAIN'
        """
        if not self.connected:
            return 'BAD'
        
        if self.last_error is not None:
            return 'UNCERTAIN'
        
        # Check if last good read was recent (within 10 seconds)
        if self.last_good_read:
            age_seconds = (datetime.utcnow() - self.last_good_read).total_seconds()
            if age_seconds > 10:
                return 'UNCERTAIN'
        
        return 'GOOD'
    
    def reset_edge_detection(self):
        """Reset edge detection state (clear previous values)"""
        self.previous_values.clear()
        logger.info(f"Edge detection reset for {self.device_id}")


class ModbusAlarmPoller:
    """High-level Modbus alarm polling with device mapping"""
    
    def __init__(
        self,
        device_id: str,
        host: str,
        port: int,
        unit_id: int,
        alarm_register: int,
        device_alarm_map: List[Dict],
        poll_interval_ms: int = 1000,
        timeout_ms: int = 3000
    ):
        """
        Initialize alarm poller
        
        Args:
            device_id: Device identifier
            host: Modbus host
            port: Modbus port
            unit_id: Unit ID
            alarm_register: Alarm word register address
            device_alarm_map: List of alarm bit mappings
            poll_interval_ms: Poll interval
            timeout_ms: Timeout
        """
        self.device_id = device_id
        self.alarm_register = alarm_register
        self.poll_interval_s = poll_interval_ms / 1000.0
        
        # Build bit map from device_alarm_map
        self.bit_map: Dict[int, Dict] = {}
        for mapping in device_alarm_map:
            if mapping['source_address'] == f"HR{alarm_register}":
                bit_num = mapping['bit_number']
                if bit_num is not None:
                    self.bit_map[bit_num] = {
                        'alarm_id': mapping['alarm_id'],
                        'alarm_name': mapping['alarm_name'],
                        'convert_to_isa': mapping['convert_to_isa'],
                        'isa_alarm_id': mapping['isa_alarm_id']
                    }
        
        logger.info(f"Alarm poller configured with {len(self.bit_map)} alarm bits")
        
        # Initialize Modbus client
        self.modbus = ModbusPoller(
            device_id=device_id,
            host=host,
            port=port,
            unit_id=unit_id,
            timeout_ms=timeout_ms
        )
        
        self.running = False
    
    def poll_once(self) -> Tuple[Optional[int], str, List[Dict]]:
        """
        Execute one poll cycle
        
        Returns:
            Tuple of (raw_value, quality, transitions)
        """
        # Read alarm register
        raw_value, quality = self.modbus.read_alarm_word(self.alarm_register)
        
        if raw_value is None:
            return None, quality, []
        
        # Detect edges
        transitions = self.modbus.detect_alarm_edges(
            address=self.alarm_register,
            current_value=raw_value,
            bit_map=self.bit_map
        )
        
        return raw_value, quality, transitions
    
    def connect(self) -> bool:
        """Connect to Modbus device"""
        return self.modbus.connect()
    
    def disconnect(self):
        """Disconnect from Modbus device"""
        self.modbus.disconnect()
    
    def get_alarm_info(self, bit_num: int) -> Optional[Dict]:
        """Get alarm information for bit number"""
        return self.bit_map.get(bit_num)
