#!/usr/bin/env python3
"""
CSV Import Script
Loads CSV templates into PostgreSQL database
"""

import sys
import os
import csv
import psycopg2
from psycopg2.extras import execute_values
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def get_db_connection():
    """Get database connection from environment variables"""
    return psycopg2.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        port=os.getenv('DB_PORT', '5432'),
        database=os.getenv('DB_NAME', 'alarm_manager'),
        user=os.getenv('DB_USER', 'postgres'),
        password=os.getenv('DB_PASSWORD', 'postgres')
    )


def import_device_alarm_map(csv_path, conn):
    """Import device_alarm_map.csv"""
    logger.info(f"Importing device alarm map from {csv_path}")
    
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        logger.warning("No data to import")
        return
    
    with conn.cursor() as cur:
        # Clear existing data (optional, comment out to append)
        cur.execute("DELETE FROM device_alarm_map")
        logger.info(f"Cleared existing device_alarm_map data")
        
        # Prepare insert
        columns = rows[0].keys()
        insert_query = f"""
            INSERT INTO device_alarm_map ({','.join(columns)})
            VALUES ({','.join(['%s'] * len(columns))})
        """
        
        # Convert rows to tuples
        values = [tuple(row[col] if row[col] != '' else None for col in columns) for row in rows]
        
        # Execute batch insert
        cur.executemany(insert_query, values)
        conn.commit()
        
        logger.info(f"✓ Imported {len(rows)} device alarm map entries")


def import_isa_alarm_definitions(csv_path, conn):
    """Import isa_alarm_definition_template.csv"""
    logger.info(f"Importing ISA alarm definitions from {csv_path}")
    
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        logger.warning("No data to import")
        return
    
    with conn.cursor() as cur:
        # Clear existing data (optional)
        cur.execute("DELETE FROM isa_alarm_definitions")
        logger.info(f"Cleared existing isa_alarm_definitions data")
        
        columns = rows[0].keys()
        insert_query = f"""
            INSERT INTO isa_alarm_definitions ({','.join(columns)})
            VALUES ({','.join(['%s'] * len(columns))})
        """
        
        # Convert rows and handle empty strings
        values = [tuple(row[col] if row[col] != '' else None for col in columns) for row in rows]
        
        cur.executemany(insert_query, values)
        conn.commit()
        
        logger.info(f"✓ Imported {len(rows)} ISA alarm definitions")


def import_cause_map(csv_path, conn):
    """Import isa_alarm_cause_map.csv"""
    logger.info(f"Importing alarm cause map from {csv_path}")
    
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        logger.warning("No data to import")
        return
    
    with conn.cursor() as cur:
        # Clear existing data (optional)
        cur.execute("DELETE FROM isa_alarm_cause_map")
        logger.info(f"Cleared existing isa_alarm_cause_map data")
        
        columns = rows[0].keys()
        insert_query = f"""
            INSERT INTO isa_alarm_cause_map ({','.join(columns)})
            VALUES ({','.join(['%s'] * len(columns))})
        """
        
        values = [tuple(row[col] if row[col] != '' else None for col in columns) for row in rows]
        
        cur.executemany(insert_query, values)
        conn.commit()
        
        logger.info(f"✓ Imported {len(rows)} cause map entries")


def import_suppression_matrix(csv_path, conn):
    """Import isa_alarm_suppression_matrix.csv"""
    logger.info(f"Importing suppression matrix from {csv_path}")
    
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        logger.warning("No data to import")
        return
    
    with conn.cursor() as cur:
        # Clear existing data (optional)
        cur.execute("DELETE FROM isa_alarm_suppression_matrix")
        logger.info(f"Cleared existing isa_alarm_suppression_matrix data")
        
        columns = rows[0].keys()
        insert_query = f"""
            INSERT INTO isa_alarm_suppression_matrix ({','.join(columns)})
            VALUES ({','.join(['%s'] * len(columns))})
        """
        
        values = [tuple(row[col] if row[col] != '' else None for col in columns) for row in rows]
        
        cur.executemany(insert_query, values)
        conn.commit()
        
        logger.info(f"✓ Imported {len(rows)} suppression rules")


def main():
    """Main import function"""
    logger.info("=" * 60)
    logger.info("CSV IMPORT SCRIPT")
    logger.info("=" * 60)
    
    # Get base directory (templates folder)
    base_dir = os.path.join(os.path.dirname(__file__), '../templates')
    
    # CSV file paths
    csv_files = {
        'device_alarm_map': os.path.join(base_dir, 'device_alarm_map.csv'),
        'isa_alarm_definitions': os.path.join(base_dir, 'isa_alarm_definition_template.csv'),
        'cause_map': os.path.join(base_dir, 'isa_alarm_cause_map.csv'),
        'suppression_matrix': os.path.join(base_dir, 'isa_alarm_suppression_matrix.csv')
    }
    
    # Check if files exist
    for name, path in csv_files.items():
        if not os.path.exists(path):
            logger.error(f"File not found: {path}")
            sys.exit(1)
    
    try:
        # Connect to database
        logger.info("Connecting to database...")
        conn = get_db_connection()
        logger.info("✓ Connected to database\n")
        
        # Import each CSV
        import_device_alarm_map(csv_files['device_alarm_map'], conn)
        import_isa_alarm_definitions(csv_files['isa_alarm_definitions'], conn)
        import_cause_map(csv_files['cause_map'], conn)
        import_suppression_matrix(csv_files['suppression_matrix'], conn)
        
        conn.close()
        
        logger.info("\n" + "=" * 60)
        logger.info("✓ ALL IMPORTS COMPLETED SUCCESSFULLY")
        logger.info("=" * 60)
        
    except psycopg2.Error as e:
        logger.error(f"Database error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
