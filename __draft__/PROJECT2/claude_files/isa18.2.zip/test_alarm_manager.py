#!/usr/bin/env python3
"""
Alarm Manager Test & Demo Script
Tests database connectivity, MQTT publishing, and alarm processing
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from config import load_config_from_yaml, load_config_from_env
from database import AlarmDatabase
from uns_publisher import UNSPublisher
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_database_connection(config):
    """Test database connection and basic queries"""
    logger.info("=" * 60)
    logger.info("Testing Database Connection")
    logger.info("=" * 60)
    
    try:
        db = AlarmDatabase(
            connection_string=config.database.connection_string,
            pool_size=2
        )
        
        # Test device alarm map loading
        logger.info("Loading device alarm map for PM5110_MTR01...")
        alarm_map = db.load_device_alarm_map('PM5110_MTR01')
        logger.info(f"✓ Loaded {len(alarm_map)} alarm mappings")
        
        # Test ISA alarm definitions loading
        logger.info("Loading ISA alarm definitions...")
        isa_alarms = db.load_isa_alarm_definitions(enabled_only=True)
        logger.info(f"✓ Loaded {len(isa_alarms)} ISA alarm definitions")
        
        # Test cause map loading
        logger.info("Loading cause map...")
        cause_map = db.load_cause_map('METER')
        logger.info(f"✓ Loaded {len(cause_map)} cause mappings")
        
        # Test suppression rules loading
        logger.info("Loading suppression rules...")
        suppression_rules = db.load_suppression_rules(enabled_only=True)
        logger.info(f"✓ Loaded {len(suppression_rules)} suppression rules")
        
        db.close()
        logger.info("✓ Database test PASSED\n")
        return True
        
    except Exception as e:
        logger.error(f"✗ Database test FAILED: {e}\n")
        return False


def test_mqtt_connection(config):
    """Test MQTT broker connection and publishing"""
    logger.info("=" * 60)
    logger.info("Testing MQTT/UNS Connection")
    logger.info("=" * 60)
    
    try:
        uns = UNSPublisher(
            broker_host=config.uns.broker_host,
            broker_port=config.uns.broker_port,
            site_id=config.uns.site_id,
            username=config.uns.username,
            password=config.uns.password
        )
        
        logger.info("Connecting to MQTT broker...")
        if not uns.connect():
            raise Exception("Failed to connect to MQTT broker")
        
        # Wait for connection
        import time
        time.sleep(2)
        
        if not uns.connected:
            raise Exception("MQTT connection failed")
        
        logger.info("✓ Connected to MQTT broker")
        
        # Test device alarm event publishing
        logger.info("Publishing test device alarm event...")
        success = uns.publish_device_alarm_event(
            device_id='PM5110_MTR01',
            alarm_id='test_alarm',
            state=True,
            alarm_source='HR40112.bit0',
            raw_value_hex='0x0001',
            quality='GOOD',
            ts_utc=datetime.utcnow()
        )
        
        if success:
            logger.info("✓ Device alarm event published")
        else:
            logger.warning("⚠ Device alarm event publish failed")
        
        # Test ISA alarm event publishing
        logger.info("Publishing test ISA alarm event...")
        success = uns.publish_isa_alarm_event(
            alarm_id='TEST_ALARM',
            event_type='ON',
            priority='MEDIUM',
            state=True,
            cause_device_id='PM5110_MTR01',
            cause_alarm_id='test_alarm',
            cause_text='Test alarm for verification',
            operator_message='This is a test alarm - please ignore',
            ts_utc=datetime.utcnow()
        )
        
        if success:
            logger.info("✓ ISA alarm event published")
        else:
            logger.warning("⚠ ISA alarm event publish failed")
        
        uns.disconnect()
        logger.info("✓ MQTT test PASSED\n")
        return True
        
    except Exception as e:
        logger.error(f"✗ MQTT test FAILED: {e}\n")
        return False


def test_alarm_storage(config):
    """Test alarm event storage"""
    logger.info("=" * 60)
    logger.info("Testing Alarm Event Storage")
    logger.info("=" * 60)
    
    try:
        db = AlarmDatabase(
            connection_string=config.database.connection_string,
            pool_size=2
        )
        
        # Store test device alarm event
        logger.info("Storing test device alarm event...")
        event_id = db.store_device_alarm_event(
            site_id=config.uns.site_id,
            device_id='PM5110_MTR01',
            alarm_source='HR40112.bit0',
            alarm_id='test_alarm',
            alarm_name='Test Alarm',
            state=True,
            raw_value_hex='0x0001',
            quality='GOOD'
        )
        logger.info(f"✓ Device alarm event stored (id={event_id})")
        
        # Store test ISA alarm event
        logger.info("Storing test ISA alarm event...")
        isa_event_id = db.store_isa_alarm_event(
            site_id=config.uns.site_id,
            alarm_id='TEST_ALARM',
            event_type='ON',
            priority='MEDIUM',
            state=True,
            cause_device_id='PM5110_MTR01',
            cause_alarm_id='test_alarm',
            cause_text='Test alarm'
        )
        logger.info(f"✓ ISA alarm event stored (id={isa_event_id})")
        
        # Query recent device alarms
        logger.info("Querying device alarm history...")
        history = db.get_device_alarm_history('PM5110_MTR01', hours=1)
        logger.info(f"✓ Found {len(history)} device alarm events in last hour")
        
        # Query active ISA alarms
        logger.info("Querying active ISA alarms...")
        active = db.get_active_isa_alarms()
        logger.info(f"✓ Found {len(active)} active ISA alarms")
        
        db.close()
        logger.info("✓ Storage test PASSED\n")
        return True
        
    except Exception as e:
        logger.error(f"✗ Storage test FAILED: {e}\n")
        return False


def main():
    """Run all tests"""
    logger.info("\n" + "=" * 60)
    logger.info("ALARM MANAGER TEST SUITE")
    logger.info("=" * 60 + "\n")
    
    # Load configuration
    try:
        config = load_config_from_yaml('../config/config.yaml')
        logger.info("✓ Configuration loaded from YAML\n")
    except FileNotFoundError:
        logger.info("No YAML config found, loading from environment variables\n")
        config = load_config_from_env()
    
    # Run tests
    results = []
    
    results.append(("Database Connection", test_database_connection(config)))
    results.append(("MQTT Connection", test_mqtt_connection(config)))
    results.append(("Alarm Storage", test_alarm_storage(config)))
    
    # Print summary
    logger.info("=" * 60)
    logger.info("TEST SUMMARY")
    logger.info("=" * 60)
    
    for test_name, passed in results:
        status = "✓ PASSED" if passed else "✗ FAILED"
        logger.info(f"{test_name:<30} {status}")
    
    total = len(results)
    passed = sum(1 for _, p in results if p)
    
    logger.info("-" * 60)
    logger.info(f"Total: {passed}/{total} tests passed")
    logger.info("=" * 60 + "\n")
    
    # Exit code
    sys.exit(0 if passed == total else 1)


if __name__ == '__main__':
    main()
