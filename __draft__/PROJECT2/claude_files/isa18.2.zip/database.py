"""
Database Storage Module
Handles all database operations for alarm events and configurations
"""

import psycopg2
from psycopg2.pool import SimpleConnectionPool
from psycopg2.extras import execute_values, RealDictCursor
from datetime import datetime
from typing import Optional, List, Dict, Any
import logging


logger = logging.getLogger(__name__)


class AlarmDatabase:
    """Database manager for alarm storage"""
    
    def __init__(self, connection_string: str, pool_size: int = 10):
        """Initialize database connection pool"""
        self.pool = SimpleConnectionPool(
            minconn=1,
            maxconn=pool_size,
            dsn=connection_string
        )
        logger.info(f"Database connection pool initialized (pool_size={pool_size})")
    
    def _get_conn(self):
        """Get connection from pool"""
        return self.pool.getconn()
    
    def _put_conn(self, conn):
        """Return connection to pool"""
        self.pool.putconn(conn)
    
    # =========================================================================
    # DEVICE ALARM EVENTS
    # =========================================================================
    
    def store_device_alarm_event(
        self,
        site_id: str,
        device_id: str,
        alarm_source: str,
        alarm_id: str,
        alarm_name: str,
        state: bool,
        raw_value_hex: str,
        quality: str = 'GOOD',
        ts_utc: Optional[datetime] = None,
        poll_cycle_ms: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Store device alarm state transition
        
        Args:
            site_id: Site identifier
            device_id: Device identifier
            alarm_source: Source (e.g., 'HR40112.bit0')
            alarm_id: Alarm ID (e.g., 'phase_loss')
            alarm_name: Human-readable name
            state: True=ON, False=OFF
            raw_value_hex: Raw register value
            quality: 'GOOD', 'BAD', 'UNCERTAIN'
            ts_utc: Timestamp (default: now)
            poll_cycle_ms: Poll interval
            metadata: Additional context
        
        Returns:
            Inserted record ID
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO device_alarm_events (
                        ts_utc, site_id, device_id, alarm_source, alarm_id, 
                        alarm_name, state, raw_value_hex, quality, 
                        poll_cycle_ms, metadata
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                """, (
                    ts_utc, site_id, device_id, alarm_source, alarm_id,
                    alarm_name, state, raw_value_hex, quality,
                    poll_cycle_ms, psycopg2.extras.Json(metadata) if metadata else None
                ))
                record_id = cur.fetchone()[0]
                conn.commit()
                
                logger.debug(
                    f"Device alarm event stored: {device_id}/{alarm_id} "
                    f"state={'ON' if state else 'OFF'} (id={record_id})"
                )
                return record_id
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to store device alarm event: {e}")
            raise
        finally:
            self._put_conn(conn)
    
    def store_device_diagnostic(
        self,
        site_id: str,
        device_id: str,
        diagnostic_type: str,
        fault_code: Optional[int] = None,
        fault_code_hex: Optional[str] = None,
        register_values: Optional[Dict] = None,
        process_context: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
        ts_utc: Optional[datetime] = None
    ) -> int:
        """Store device diagnostic snapshot"""
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO device_diagnostics (
                        ts_utc, site_id, device_id, diagnostic_type,
                        fault_code, fault_code_hex, register_values,
                        process_context, metadata
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                """, (
                    ts_utc, site_id, device_id, diagnostic_type,
                    fault_code, fault_code_hex,
                    psycopg2.extras.Json(register_values) if register_values else None,
                    psycopg2.extras.Json(process_context) if process_context else None,
                    psycopg2.extras.Json(metadata) if metadata else None
                ))
                record_id = cur.fetchone()[0]
                conn.commit()
                
                logger.debug(f"Device diagnostic stored: {device_id} (id={record_id})")
                return record_id
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to store device diagnostic: {e}")
            raise
        finally:
            self._put_conn(conn)
    
    # =========================================================================
    # ISA ALARM EVENTS
    # =========================================================================
    
    def store_isa_alarm_event(
        self,
        site_id: str,
        alarm_id: str,
        event_type: str,
        priority: str,
        state: Optional[bool] = None,
        cause_device_id: Optional[str] = None,
        cause_alarm_id: Optional[str] = None,
        cause_text: Optional[str] = None,
        ack_user: Optional[str] = None,
        ack_comment: Optional[str] = None,
        suppressed: bool = False,
        suppressed_by: Optional[str] = None,
        suppressed_reason: Optional[str] = None,
        ts_utc: Optional[datetime] = None,
        metadata: Optional[Dict] = None
    ) -> int:
        """
        Store ISA alarm lifecycle event
        
        Args:
            site_id: Site identifier
            alarm_id: ISA alarm ID
            event_type: 'ON', 'ACK', 'CLEAR', 'SHELVE', 'UNSHELVE'
            priority: 'HIGH', 'MEDIUM', 'LOW'
            state: True=active (for ON/CLEAR events)
            cause_device_id: Root cause device
            cause_alarm_id: Root cause alarm
            cause_text: Human-readable cause
            ack_user: Acknowledging user
            ack_comment: Ack comment
            suppressed: Is suppressed?
            suppressed_by: Parent alarm ID
            suppressed_reason: Suppression reason
            ts_utc: Timestamp
            metadata: Additional context
        
        Returns:
            Inserted record ID
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        ack_ts_utc = ts_utc if event_type == 'ACK' else None
        
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO isa_alarm_events (
                        ts_utc, site_id, alarm_id, event_type, priority, state,
                        cause_device_id, cause_alarm_id, cause_text,
                        ack_user, ack_ts_utc, ack_comment,
                        suppressed, suppressed_by, suppressed_reason,
                        metadata
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                """, (
                    ts_utc, site_id, alarm_id, event_type, priority, state,
                    cause_device_id, cause_alarm_id, cause_text,
                    ack_user, ack_ts_utc, ack_comment,
                    suppressed, suppressed_by, suppressed_reason,
                    psycopg2.extras.Json(metadata) if metadata else None
                ))
                record_id = cur.fetchone()[0]
                conn.commit()
                
                logger.info(
                    f"ISA alarm event stored: {alarm_id} {event_type} "
                    f"(suppressed={suppressed}, id={record_id})"
                )
                return record_id
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to store ISA alarm event: {e}")
            raise
        finally:
            self._put_conn(conn)
    
    # =========================================================================
    # CONFIGURATION LOADING
    # =========================================================================
    
    def load_device_alarm_map(self, device_id: str) -> List[Dict]:
        """Load device alarm bit/register mapping"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM device_alarm_map
                    WHERE device_id = %s
                    ORDER BY source_address, bit_number
                """, (device_id,))
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    def load_isa_alarm_definitions(self, enabled_only: bool = True) -> List[Dict]:
        """Load ISA alarm definitions"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                query = "SELECT * FROM isa_alarm_definitions"
                if enabled_only:
                    query += " WHERE enabled = TRUE"
                cur.execute(query)
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    def load_cause_map(self, device_type: str) -> List[Dict]:
        """Load alarm cause mapping for device type"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM isa_alarm_cause_map
                    WHERE device_type = %s OR device_type = 'DEFAULT'
                    ORDER BY 
                        CASE WHEN vendor IS NOT NULL THEN 1 ELSE 2 END,
                        CASE WHEN model IS NOT NULL THEN 1 ELSE 2 END
                """, (device_type,))
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    def load_suppression_rules(self, enabled_only: bool = True) -> List[Dict]:
        """Load alarm suppression rules"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                query = "SELECT * FROM isa_alarm_suppression_matrix"
                if enabled_only:
                    query += " WHERE enabled = TRUE"
                cur.execute(query)
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    # =========================================================================
    # QUERIES
    # =========================================================================
    
    def get_active_isa_alarms(self) -> List[Dict]:
        """Get currently active ISA alarms"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("SELECT * FROM active_isa_alarms")
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    def get_device_alarm_history(
        self, 
        device_id: str, 
        alarm_id: Optional[str] = None,
        hours: int = 24
    ) -> List[Dict]:
        """Get device alarm history"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                query = """
                    SELECT * FROM device_alarm_events
                    WHERE device_id = %s
                    AND ts_utc > NOW() - INTERVAL '%s hours'
                """
                params = [device_id, hours]
                
                if alarm_id:
                    query += " AND alarm_id = %s"
                    params.append(alarm_id)
                
                query += " ORDER BY ts_utc DESC"
                
                cur.execute(query, params)
                return cur.fetchall()
        finally:
            self._put_conn(conn)
    
    def close(self):
        """Close all database connections"""
        self.pool.closeall()
        logger.info("Database connection pool closed")
