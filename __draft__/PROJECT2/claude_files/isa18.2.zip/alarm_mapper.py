"""
Alarm Mapping Engine
Processes device alarms and generates ISA alarms with cause mapping and suppression
"""

from typing import Dict, List, Optional, Set
from datetime import datetime, timedelta
import logging


logger = logging.getLogger(__name__)


class AlarmMappingEngine:
    """Maps device alarms to ISA alarms with rationalization"""
    
    def __init__(
        self,
        isa_alarm_definitions: List[Dict],
        cause_map: List[Dict],
        suppression_rules: List[Dict]
    ):
        """
        Initialize alarm mapping engine
        
        Args:
            isa_alarm_definitions: ISA alarm configuration
            cause_map: Device code to cause text mapping
            suppression_rules: Alarm suppression rules
        """
        # Index ISA alarm definitions by ID
        self.isa_alarms: Dict[str, Dict] = {
            defn['isa_alarm_id']: defn 
            for defn in isa_alarm_definitions
        }
        
        # Index cause map by (device_type, source, code/bit)
        self.cause_map: List[Dict] = cause_map
        
        # Index suppression rules
        self.suppression_rules: List[Dict] = suppression_rules
        
        # Active ISA alarms state
        self.active_isa_alarms: Dict[str, Dict] = {}
        
        # Alarm state tracking (for delays)
        self.alarm_state_tracker: Dict[str, Dict] = {}
        
        logger.info(
            f"Alarm mapping engine initialized: "
            f"{len(self.isa_alarms)} ISA alarms, "
            f"{len(self.cause_map)} cause mappings, "
            f"{len(self.suppression_rules)} suppression rules"
        )
    
    def process_device_alarm_transition(
        self,
        device_id: str,
        alarm_id: str,
        state: bool,
        device_type: str = 'METER',
        fault_code: Optional[int] = None,
        alarm_bit: Optional[int] = None
    ) -> List[Dict]:
        """
        Process device alarm transition and generate ISA alarm events
        
        Args:
            device_id: Device identifier
            alarm_id: Device alarm ID
            state: Alarm state (True=ON, False=OFF)
            device_type: Device type for cause mapping
            fault_code: Fault code (if applicable)
            alarm_bit: Alarm bit (if bitmap)
        
        Returns:
            List of ISA alarm events to publish
        """
        isa_events = []
        
        # Find ISA alarm mapping
        isa_alarm_id = self._find_isa_alarm_for_device_alarm(
            device_id, alarm_id
        )
        
        if not isa_alarm_id:
            logger.debug(
                f"No ISA alarm mapping for {device_id}/{alarm_id} "
                f"(staying as device event)"
            )
            return []
        
        # Get ISA alarm definition
        isa_alarm_def = self.isa_alarms.get(isa_alarm_id)
        if not isa_alarm_def:
            logger.warning(f"ISA alarm {isa_alarm_id} not found in definitions")
            return []
        
        # Apply delays (on_delay_s, off_delay_s)
        if not self._check_delay(isa_alarm_id, state, isa_alarm_def):
            logger.debug(
                f"ISA alarm {isa_alarm_id} delayed "
                f"({'on' if state else 'off'}_delay)"
            )
            return []
        
        # Get cause mapping
        cause_info = self._get_cause_mapping(
            device_type=device_type,
            fault_code=fault_code,
            alarm_bit=alarm_bit,
            alarm_id=alarm_id
        )
        
        # Check suppression
        suppressed, suppressed_by, suppressed_reason = self._check_suppression(
            isa_alarm_id
        )
        
        # Generate ISA alarm event
        event = {
            'ts_utc': datetime.utcnow(),
            'alarm_id': isa_alarm_id,
            'event_type': 'ON' if state else 'CLEAR',
            'priority': isa_alarm_def['priority'],
            'state': state,
            'cause_device_id': device_id,
            'cause_alarm_id': alarm_id,
            'cause_text': cause_info.get('cause_text', 'Unknown cause'),
            'recommended_action': cause_info.get('recommended_action'),
            'recommended_steps': cause_info.get('recommended_action_steps'),
            'suppressed': suppressed,
            'suppressed_by': suppressed_by,
            'suppressed_reason': suppressed_reason,
            'operator_message': cause_info.get('operator_message_template', '').format(
                code_value=fault_code or 'N/A'
            )
        }
        
        # Update active alarms tracking
        if state:
            self.active_isa_alarms[isa_alarm_id] = event
        else:
            self.active_isa_alarms.pop(isa_alarm_id, None)
        
        isa_events.append(event)
        
        logger.info(
            f"ISA alarm {'activated' if state else 'cleared'}: {isa_alarm_id} "
            f"(suppressed={suppressed})"
        )
        
        return isa_events
    
    def _find_isa_alarm_for_device_alarm(
        self,
        device_id: str,
        alarm_id: str
    ) -> Optional[str]:
        """
        Find ISA alarm ID for device alarm
        
        This should be enhanced to use the device_alarm_map table
        For now, simple lookup by cause_source_asset and cause_source_point
        """
        for isa_alarm_id, defn in self.isa_alarms.items():
            if (defn.get('cause_source_asset') == device_id and
                defn.get('cause_source_point') == alarm_id):
                return isa_alarm_id
        return None
    
    def _check_delay(
        self,
        isa_alarm_id: str,
        state: bool,
        isa_alarm_def: Dict
    ) -> bool:
        """
        Check if alarm should activate based on delays
        
        Returns:
            True if delay satisfied, False if still waiting
        """
        now = datetime.utcnow()
        tracker_key = f"{isa_alarm_id}_{'on' if state else 'off'}"
        
        # Get delay threshold
        delay_s = (
            isa_alarm_def['on_delay_s'] if state 
            else isa_alarm_def['off_delay_s']
        )
        
        if delay_s == 0:
            return True  # No delay
        
        # Check if we've been tracking this state
        if tracker_key not in self.alarm_state_tracker:
            # Start tracking
            self.alarm_state_tracker[tracker_key] = {
                'start_time': now,
                'state': state
            }
            return False
        
        # Check if delay elapsed
        tracker = self.alarm_state_tracker[tracker_key]
        elapsed = (now - tracker['start_time']).total_seconds()
        
        if elapsed >= delay_s:
            # Delay satisfied, clear tracker
            del self.alarm_state_tracker[tracker_key]
            return True
        
        return False
    
    def _get_cause_mapping(
        self,
        device_type: str,
        fault_code: Optional[int] = None,
        alarm_bit: Optional[int] = None,
        alarm_id: Optional[str] = None
    ) -> Dict:
        """
        Find cause mapping for device alarm
        
        Returns cause information or default
        """
        # Priority matching: most specific to least specific
        for mapping in self.cause_map:
            # Skip if device type doesn't match
            if mapping['device_type'] != device_type:
                continue
            
            # Match by fault code (most specific)
            if fault_code is not None and mapping.get('code_value') == fault_code:
                return mapping
            
            # Match by alarm bit
            if alarm_bit is not None and mapping.get('alarm_bit') == alarm_bit:
                return mapping
            
            # Match by alarm ID
            if alarm_id and mapping.get('alarm_id') == alarm_id:
                return mapping
        
        # Default fallback
        return {
            'cause_text': 'Unknown cause',
            'recommended_action': 'Check device diagnostics',
            'recommended_action_steps': 'Contact maintenance',
            'operator_message_template': 'Device alarm: {alarm_id}'
        }
    
    def _check_suppression(
        self,
        isa_alarm_id: str
    ) -> tuple[bool, Optional[str], Optional[str]]:
        """
        Check if ISA alarm should be suppressed
        
        Returns:
            (suppressed: bool, suppressed_by: str, reason: str)
        """
        for rule in self.suppression_rules:
            if not rule.get('enabled', True):
                continue
            
            # Check if this rule applies to this alarm
            if rule['suppressed_alarm_id'] != isa_alarm_id:
                continue
            
            # Check if parent alarm is active
            parent_alarm_id = rule['parent_alarm_id']
            if parent_alarm_id in self.active_isa_alarms:
                return (
                    True,
                    parent_alarm_id,
                    rule['suppression_reason']
                )
        
        return False, None, None
    
    def acknowledge_alarm(
        self,
        isa_alarm_id: str,
        user: str,
        comment: Optional[str] = None
    ) -> Optional[Dict]:
        """
        Acknowledge an ISA alarm
        
        Returns:
            ACK event or None if alarm not active
        """
        if isa_alarm_id not in self.active_isa_alarms:
            logger.warning(f"Cannot ACK inactive alarm: {isa_alarm_id}")
            return None
        
        event = {
            'ts_utc': datetime.utcnow(),
            'alarm_id': isa_alarm_id,
            'event_type': 'ACK',
            'priority': self.isa_alarms[isa_alarm_id]['priority'],
            'ack_user': user,
            'ack_comment': comment
        }
        
        logger.info(f"ISA alarm acknowledged: {isa_alarm_id} by {user}")
        return event
    
    def get_active_alarms(self) -> List[Dict]:
        """Get list of active ISA alarms"""
        return list(self.active_isa_alarms.values())
    
    def get_suppressed_alarms(self) -> List[str]:
        """Get list of currently suppressed alarm IDs"""
        suppressed = []
        for alarm_id in self.isa_alarms.keys():
            is_suppressed, _, _ = self._check_suppression(alarm_id)
            if is_suppressed:
                suppressed.append(alarm_id)
        return suppressed
