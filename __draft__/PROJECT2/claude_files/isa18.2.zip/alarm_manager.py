"""
Alarm Manager Main Application
Orchestrates Modbus polling, alarm mapping, and UNS publishing
"""

import time
import signal
import sys
import logging
from typing import Optional
from datetime import datetime

from config import AlarmManagerConfig, load_config_from_yaml, load_config_from_env
from database import AlarmDatabase
from modbus_poller import ModbusAlarmPoller
from alarm_mapper import AlarmMappingEngine
from uns_publisher import UNSPublisher


logger = logging.getLogger(__name__)


class AlarmManager:
    """Main alarm manager application"""
    
    def __init__(self, config: AlarmManagerConfig):
        """
        Initialize alarm manager
        
        Args:
            config: Application configuration
        """
        self.config = config
        self.running = False
        
        # Initialize database
        logger.info("Initializing database connection...")
        self.db = AlarmDatabase(
            connection_string=config.database.connection_string,
            pool_size=config.database.pool_size
        )
        
        # Initialize UNS publisher
        logger.info("Initializing UNS publisher...")
        self.uns = UNSPublisher(
            broker_host=config.uns.broker_host,
            broker_port=config.uns.broker_port,
            site_id=config.uns.site_id,
            username=config.uns.username,
            password=config.uns.password,
            qos=config.uns.qos,
            retain=config.uns.retain
        )
        
        # Initialize Modbus pollers (one per device)
        logger.info("Initializing Modbus pollers...")
        self.pollers = {}
        for device_config in config.modbus_devices:
            # Load device alarm map from database
            device_alarm_map = self.db.load_device_alarm_map(device_config.device_id)
            
            if not device_alarm_map:
                logger.warning(
                    f"No alarm map found for {device_config.device_id}, "
                    f"loading from CSV..."
                )
                # In production, import from CSV if not in database
                continue
            
            poller = ModbusAlarmPoller(
                device_id=device_config.device_id,
                host=device_config.host,
                port=device_config.port,
                unit_id=device_config.unit_id,
                alarm_register=device_config.alarm_register,
                device_alarm_map=device_alarm_map,
                poll_interval_ms=device_config.poll_interval_ms,
                timeout_ms=device_config.timeout_ms
            )
            
            self.pollers[device_config.device_id] = poller
        
        # Initialize alarm mapping engine
        logger.info("Initializing alarm mapping engine...")
        isa_alarm_defs = self.db.load_isa_alarm_definitions(enabled_only=True)
        cause_map = self.db.load_cause_map(device_type='METER')  # Load for all types
        suppression_rules = self.db.load_suppression_rules(enabled_only=True)
        
        self.mapper = AlarmMappingEngine(
            isa_alarm_definitions=isa_alarm_defs,
            cause_map=cause_map,
            suppression_rules=suppression_rules
        )
        
        logger.info("Alarm Manager initialized successfully")
    
    def connect_all(self) -> bool:
        """Connect to all external systems"""
        success = True
        
        # Connect to UNS
        if not self.uns.connect():
            logger.error("Failed to connect to UNS broker")
            success = False
        
        # Connect to all Modbus devices
        for device_id, poller in self.pollers.items():
            if not poller.connect():
                logger.error(f"Failed to connect to Modbus device {device_id}")
                success = False
        
        return success
    
    def disconnect_all(self):
        """Disconnect from all external systems"""
        # Disconnect UNS
        self.uns.disconnect()
        
        # Disconnect Modbus devices
        for device_id, poller in self.pollers.items():
            poller.disconnect()
        
        # Close database
        self.db.close()
    
    def process_device_alarm_transition(
        self,
        device_id: str,
        transition: dict,
        raw_value: int,
        quality: str
    ):
        """
        Process a single device alarm transition
        
        Args:
            device_id: Device identifier
            transition: Transition info from edge detection
            raw_value: Raw register value
            quality: Connection quality
        """
        alarm_id = transition['alarm_id']
        state = transition['state']
        bit_num = transition['bit']
        
        # Get alarm info from poller
        poller = self.pollers[device_id]
        alarm_info = poller.get_alarm_info(bit_num)
        
        if not alarm_info:
            logger.warning(f"No alarm info for {device_id} bit {bit_num}")
            return
        
        alarm_name = alarm_info['alarm_name']
        alarm_source = f"HR{poller.alarm_register}.bit{bit_num}"
        raw_hex = f"0x{raw_value:04X}"
        
        # Store device alarm event
        try:
            self.db.store_device_alarm_event(
                site_id=self.config.uns.site_id,
                device_id=device_id,
                alarm_source=alarm_source,
                alarm_id=alarm_id,
                alarm_name=alarm_name,
                state=state,
                raw_value_hex=raw_hex,
                quality=quality,
                poll_cycle_ms=poller.poll_interval_s * 1000
            )
        except Exception as e:
            logger.error(f"Failed to store device alarm event: {e}")
        
        # Publish device alarm event to UNS
        try:
            self.uns.publish_device_alarm_event(
                device_id=device_id,
                alarm_id=alarm_id,
                state=state,
                alarm_source=alarm_source,
                raw_value_hex=raw_hex,
                quality=quality
            )
        except Exception as e:
            logger.error(f"Failed to publish device alarm event: {e}")
        
        # Process ISA alarm mapping (if applicable)
        if alarm_info['convert_to_isa'] == 'Y':
            try:
                isa_events = self.mapper.process_device_alarm_transition(
                    device_id=device_id,
                    alarm_id=alarm_id,
                    state=state,
                    device_type='METER',  # Should come from config
                    alarm_bit=bit_num
                )
                
                # Store and publish ISA alarm events
                for isa_event in isa_events:
                    # Store ISA alarm event
                    self.db.store_isa_alarm_event(
                        site_id=self.config.uns.site_id,
                        **isa_event
                    )
                    
                    # Publish ISA alarm event to UNS
                    self.uns.publish_isa_alarm_event(**isa_event)
                
            except Exception as e:
                logger.error(f"Failed to process ISA alarm mapping: {e}")
    
    def poll_cycle(self):
        """Execute one poll cycle for all devices"""
        for device_id, poller in self.pollers.items():
            try:
                # Poll device
                raw_value, quality, transitions = poller.poll_once()
                
                if raw_value is None:
                    logger.warning(f"Failed to poll {device_id}")
                    continue
                
                # Process each transition
                for transition in transitions:
                    self.process_device_alarm_transition(
                        device_id=device_id,
                        transition=transition,
                        raw_value=raw_value,
                        quality=quality
                    )
            
            except Exception as e:
                logger.error(f"Error polling {device_id}: {e}")
    
    def run(self):
        """Main run loop"""
        logger.info("Starting Alarm Manager...")
        
        # Connect to all systems
        if not self.connect_all():
            logger.error("Failed to connect to all systems")
            return
        
        self.running = True
        
        try:
            while self.running:
                # Execute poll cycle
                self.poll_cycle()
                
                # Sleep for poll interval (use shortest interval)
                # In production, use separate threads per device with different intervals
                min_interval = min(
                    poller.poll_interval_s 
                    for poller in self.pollers.values()
                )
                time.sleep(min_interval)
        
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt, shutting down...")
        
        finally:
            self.stop()
    
    def stop(self):
        """Stop alarm manager"""
        logger.info("Stopping Alarm Manager...")
        self.running = False
        self.disconnect_all()
        logger.info("Alarm Manager stopped")


def setup_logging(log_level: str, log_file: Optional[str] = None):
    """Setup logging configuration"""
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    handlers = [logging.StreamHandler(sys.stdout)]
    
    if log_file:
        handlers.append(logging.FileHandler(log_file))
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format=log_format,
        handlers=handlers
    )


def main():
    """Main entry point"""
    # Load configuration
    # Try YAML config first, fall back to environment variables
    try:
        config = load_config_from_yaml('config/config.yaml')
        logger.info("Configuration loaded from YAML file")
    except FileNotFoundError:
        logger.info("No YAML config found, loading from environment variables")
        config = load_config_from_env()
    
    # Setup logging
    setup_logging(config.log_level, config.log_file)
    
    # Create alarm manager
    manager = AlarmManager(config)
    
    # Setup signal handlers for graceful shutdown
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, initiating shutdown...")
        manager.stop()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run
    manager.run()


if __name__ == '__main__':
    main()
