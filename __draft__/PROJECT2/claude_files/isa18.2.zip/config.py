"""
Configuration Management Module
Handles loading configuration from environment variables and config files
"""

import os
from dataclasses import dataclass
from typing import Optional
import yaml


@dataclass
class DatabaseConfig:
    """Database configuration"""
    host: str
    port: int
    database: str
    user: str
    password: str
    pool_size: int = 10
    
    @property
    def connection_string(self) -> str:
        """Generate PostgreSQL connection string"""
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"


@dataclass
class ModbusConfig:
    """Modbus device configuration"""
    device_id: str
    host: str
    port: int
    unit_id: int
    poll_interval_ms: int
    timeout_ms: int
    
    # Register definitions
    alarm_register: int
    alarm_register_type: str  # 'holding' or 'input'
    
    # Optional
    fault_code_register: Optional[int] = None
    status_register: Optional[int] = None


@dataclass
class UNSConfig:
    """Unified Namespace (MQTT) configuration"""
    broker_host: str
    broker_port: int
    site_id: str
    username: Optional[str] = None
    password: Optional[str] = None
    qos: int = 1
    retain: bool = True
    
    # Topic templates
    device_alarm_state_topic_template: str = "UNS/{site}/devices/{device_id}/alarms/state"
    device_alarm_event_topic_template: str = "UNS/{site}/devices/{device_id}/alarms/events"
    device_diagnostic_topic_template: str = "UNS/{site}/devices/{device_id}/diagnostics"
    isa_alarm_state_topic_template: str = "UNS/{site}/scada/alarms/isa/state"
    isa_alarm_event_topic_template: str = "UNS/{site}/scada/alarms/isa/events"
    
    def get_device_alarm_event_topic(self, device_id: str) -> str:
        """Generate device alarm event topic"""
        return self.device_alarm_event_topic_template.format(
            site=self.site_id,
            device_id=device_id
        )
    
    def get_isa_alarm_event_topic(self) -> str:
        """Generate ISA alarm event topic"""
        return self.isa_alarm_event_topic_template.format(site=self.site_id)


@dataclass
class AlarmManagerConfig:
    """Main alarm manager configuration"""
    database: DatabaseConfig
    uns: UNSConfig
    modbus_devices: list[ModbusConfig]
    
    # Alarm processing
    edge_detection_enabled: bool = True
    suppression_enabled: bool = True
    cause_mapping_enabled: bool = True
    
    # CSV file paths
    alarm_definition_csv: str = "templates/isa_alarm_definition_template.csv"
    cause_map_csv: str = "templates/isa_alarm_cause_map.csv"
    suppression_matrix_csv: str = "templates/isa_alarm_suppression_matrix.csv"
    device_map_csv: str = "templates/device_alarm_map.csv"
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None


def load_config_from_yaml(config_path: str) -> AlarmManagerConfig:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config_data = yaml.safe_load(f)
    
    # Parse database config
    db_config = DatabaseConfig(**config_data['database'])
    
    # Parse UNS config
    uns_config = UNSConfig(**config_data['uns'])
    
    # Parse Modbus devices
    modbus_devices = [
        ModbusConfig(**device) for device in config_data['modbus_devices']
    ]
    
    # Parse alarm manager config
    alarm_config = AlarmManagerConfig(
        database=db_config,
        uns=uns_config,
        modbus_devices=modbus_devices,
        **config_data.get('alarm_processing', {})
    )
    
    return alarm_config


def load_config_from_env() -> AlarmManagerConfig:
    """Load configuration from environment variables"""
    
    # Database config from env
    db_config = DatabaseConfig(
        host=os.getenv('DB_HOST', 'localhost'),
        port=int(os.getenv('DB_PORT', '5432')),
        database=os.getenv('DB_NAME', 'alarm_manager'),
        user=os.getenv('DB_USER', 'postgres'),
        password=os.getenv('DB_PASSWORD', 'postgres'),
        pool_size=int(os.getenv('DB_POOL_SIZE', '10'))
    )
    
    # UNS config from env
    uns_config = UNSConfig(
        broker_host=os.getenv('MQTT_BROKER_HOST', 'localhost'),
        broker_port=int(os.getenv('MQTT_BROKER_PORT', '1883')),
        site_id=os.getenv('SITE_ID', 'EgyptPlant'),
        username=os.getenv('MQTT_USERNAME'),
        password=os.getenv('MQTT_PASSWORD'),
        qos=int(os.getenv('MQTT_QOS', '1')),
        retain=os.getenv('MQTT_RETAIN', 'true').lower() == 'true'
    )
    
    # Modbus devices - for now, single device from env
    # In production, load from YAML or database
    modbus_devices = [
        ModbusConfig(
            device_id=os.getenv('MODBUS_DEVICE_ID', 'PM5110_MTR01'),
            host=os.getenv('MODBUS_HOST', '192.168.1.100'),
            port=int(os.getenv('MODBUS_PORT', '502')),
            unit_id=int(os.getenv('MODBUS_UNIT_ID', '1')),
            poll_interval_ms=int(os.getenv('MODBUS_POLL_INTERVAL_MS', '1000')),
            timeout_ms=int(os.getenv('MODBUS_TIMEOUT_MS', '3000')),
            alarm_register=int(os.getenv('MODBUS_ALARM_REGISTER', '40112')),
            alarm_register_type=os.getenv('MODBUS_ALARM_REG_TYPE', 'holding')
        )
    ]
    
    return AlarmManagerConfig(
        database=db_config,
        uns=uns_config,
        modbus_devices=modbus_devices,
        log_level=os.getenv('LOG_LEVEL', 'INFO')
    )
