"""
UNS Publisher Module
Publishes alarm events to Unified Namespace (MQTT broker)
"""

import paho.mqtt.client as mqtt
import json
from typing import Dict, Any, Optional
from datetime import datetime
import logging


logger = logging.getLogger(__name__)


class UNSPublisher:
    """MQTT publisher for Unified Namespace"""
    
    def __init__(
        self,
        broker_host: str,
        broker_port: int = 1883,
        site_id: str = "EgyptPlant",
        username: Optional[str] = None,
        password: Optional[str] = None,
        qos: int = 1,
        retain: bool = True,
        client_id: Optional[str] = None
    ):
        """
        Initialize UNS publisher
        
        Args:
            broker_host: MQTT broker hostname
            broker_port: MQTT broker port
            site_id: Site identifier for topic structure
            username: MQTT username (optional)
            password: MQTT password (optional)
            qos: Quality of Service (0, 1, or 2)
            retain: Retain messages
            client_id: MQTT client ID (auto-generated if None)
        """
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.site_id = site_id
        self.qos = qos
        self.retain = retain
        
        # Create MQTT client
        self.client = mqtt.Client(
            client_id=client_id or f"alarm_manager_{datetime.utcnow().timestamp()}"
        )
        
        # Set credentials if provided
        if username and password:
            self.client.username_pw_set(username, password)
        
        # Set callbacks
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_publish = self._on_publish
        
        self.connected = False
        
        logger.info(f"UNS publisher initialized for {broker_host}:{broker_port}")
    
    def _on_connect(self, client, userdata, flags, rc):
        """MQTT connection callback"""
        if rc == 0:
            self.connected = True
            logger.info(f"Connected to MQTT broker at {self.broker_host}:{self.broker_port}")
        else:
            self.connected = False
            logger.error(f"MQTT connection failed with code {rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """MQTT disconnection callback"""
        self.connected = False
        if rc != 0:
            logger.warning(f"Unexpected MQTT disconnection (rc={rc})")
        else:
            logger.info("Disconnected from MQTT broker")
    
    def _on_publish(self, client, userdata, mid):
        """MQTT publish callback"""
        logger.debug(f"Message published (mid={mid})")
    
    def connect(self) -> bool:
        """Connect to MQTT broker"""
        try:
            self.client.connect(self.broker_host, self.broker_port, keepalive=60)
            self.client.loop_start()
            return True
        except Exception as e:
            logger.error(f"Failed to connect to MQTT broker: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from MQTT broker"""
        self.client.loop_stop()
        self.client.disconnect()
    
    def _publish(
        self,
        topic: str,
        payload: Dict[str, Any],
        qos: Optional[int] = None,
        retain: Optional[bool] = None
    ) -> bool:
        """
        Internal publish method
        
        Args:
            topic: MQTT topic
            payload: Payload dictionary
            qos: Quality of Service (override default)
            retain: Retain flag (override default)
        
        Returns:
            True if published successfully
        """
        if not self.connected:
            logger.warning(f"Cannot publish: not connected to MQTT broker")
            return False
        
        try:
            # Ensure timestamps are ISO format strings
            payload_copy = self._serialize_datetime(payload)
            
            # Convert to JSON
            payload_json = json.dumps(payload_copy, indent=None)
            
            # Publish
            result = self.client.publish(
                topic=topic,
                payload=payload_json,
                qos=qos if qos is not None else self.qos,
                retain=retain if retain is not None else self.retain
            )
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logger.debug(f"Published to {topic}: {len(payload_json)} bytes")
                return True
            else:
                logger.error(f"Publish failed to {topic}: rc={result.rc}")
                return False
        
        except Exception as e:
            logger.error(f"Error publishing to {topic}: {e}")
            return False
    
    def _serialize_datetime(self, obj: Any) -> Any:
        """Recursively convert datetime objects to ISO strings"""
        if isinstance(obj, datetime):
            return obj.isoformat() + 'Z'
        elif isinstance(obj, dict):
            return {k: self._serialize_datetime(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._serialize_datetime(item) for item in obj]
        else:
            return obj
    
    # =========================================================================
    # DEVICE ALARM PUBLISHING
    # =========================================================================
    
    def publish_device_alarm_event(
        self,
        device_id: str,
        alarm_id: str,
        state: bool,
        alarm_source: str,
        raw_value_hex: str,
        quality: str = 'GOOD',
        ts_utc: Optional[datetime] = None
    ) -> bool:
        """
        Publish device alarm transition event
        
        Args:
            device_id: Device identifier
            alarm_id: Alarm ID
            state: True=ON, False=OFF
            alarm_source: Source (e.g., 'HR40112.bit0')
            raw_value_hex: Raw register value
            quality: 'GOOD', 'BAD', 'UNCERTAIN'
            ts_utc: Timestamp
        
        Returns:
            True if published successfully
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        topic = f"UNS/{self.site_id}/devices/{device_id}/alarms/events"
        
        payload = {
            'ts': ts_utc,
            'event': 'ON' if state else 'OFF',
            'alarm': {'id': alarm_id},
            'source': {
                'register': alarm_source,
            },
            'raw': raw_value_hex,
            'quality': quality
        }
        
        return self._publish(topic, payload)
    
    def publish_device_alarm_state(
        self,
        device_id: str,
        active_alarms: list[Dict],
        quality: str = 'GOOD',
        ts_utc: Optional[datetime] = None
    ) -> bool:
        """
        Publish device alarm state snapshot
        
        Args:
            device_id: Device identifier
            active_alarms: List of active alarms
            quality: Overall quality
            ts_utc: Timestamp
        
        Returns:
            True if published successfully
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        topic = f"UNS/{self.site_id}/devices/{device_id}/alarms/state"
        
        payload = {
            'ts': ts_utc,
            'active': active_alarms,
            'quality': quality
        }
        
        return self._publish(topic, payload, retain=True)
    
    def publish_device_diagnostic(
        self,
        device_id: str,
        diagnostic_data: Dict,
        ts_utc: Optional[datetime] = None
    ) -> bool:
        """
        Publish device diagnostic data
        
        Args:
            device_id: Device identifier
            diagnostic_data: Diagnostic information
            ts_utc: Timestamp
        
        Returns:
            True if published successfully
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        topic = f"UNS/{self.site_id}/devices/{device_id}/diagnostics"
        
        payload = {
            'ts': ts_utc,
            **diagnostic_data
        }
        
        return self._publish(topic, payload)
    
    # =========================================================================
    # ISA ALARM PUBLISHING
    # =========================================================================
    
    def publish_isa_alarm_event(
        self,
        alarm_id: str,
        event_type: str,
        priority: str,
        state: Optional[bool] = None,
        cause_device_id: Optional[str] = None,
        cause_alarm_id: Optional[str] = None,
        cause_text: Optional[str] = None,
        operator_message: Optional[str] = None,
        recommended_action: Optional[str] = None,
        suppressed: bool = False,
        suppressed_by: Optional[str] = None,
        ack_user: Optional[str] = None,
        ack_comment: Optional[str] = None,
        ts_utc: Optional[datetime] = None
    ) -> bool:
        """
        Publish ISA alarm lifecycle event
        
        Args:
            alarm_id: ISA alarm ID
            event_type: 'ON', 'ACK', 'CLEAR'
            priority: 'HIGH', 'MEDIUM', 'LOW'
            state: Alarm state (for ON/CLEAR)
            cause_device_id: Root cause device
            cause_alarm_id: Root cause alarm
            cause_text: Human-readable cause
            operator_message: Message to operator
            recommended_action: Recommended action
            suppressed: Is suppressed?
            suppressed_by: Parent alarm ID
            ack_user: Acknowledging user
            ack_comment: Ack comment
            ts_utc: Timestamp
        
        Returns:
            True if published successfully
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        topic = f"UNS/{self.site_id}/scada/alarms/isa/events"
        
        payload = {
            'ts': ts_utc,
            'event': event_type,
            'alarm': {
                'id': alarm_id,
                'priority': priority,
            }
        }
        
        # Add optional fields
        if state is not None:
            payload['alarm']['state'] = state
        
        if operator_message:
            payload['alarm']['message'] = operator_message
        
        if recommended_action:
            payload['alarm']['guidance'] = recommended_action
        
        if cause_device_id or cause_alarm_id or cause_text:
            payload['cause'] = {}
            if cause_device_id:
                payload['cause']['device'] = cause_device_id
            if cause_alarm_id:
                payload['cause']['alarm'] = cause_alarm_id
            if cause_text:
                payload['cause']['text'] = cause_text
        
        if suppressed:
            payload['suppression'] = {
                'suppressed': True,
                'by': suppressed_by
            }
        
        if ack_user:
            payload['ack'] = {
                'user': ack_user,
                'comment': ack_comment
            }
        
        return self._publish(topic, payload)
    
    def publish_isa_alarm_state(
        self,
        active_alarms: list[Dict],
        ts_utc: Optional[datetime] = None
    ) -> bool:
        """
        Publish ISA alarm state snapshot
        
        Args:
            active_alarms: List of active ISA alarms
            ts_utc: Timestamp
        
        Returns:
            True if published successfully
        """
        if ts_utc is None:
            ts_utc = datetime.utcnow()
        
        topic = f"UNS/{self.site_id}/scada/alarms/isa/state"
        
        payload = {
            'ts': ts_utc,
            'active': active_alarms
        }
        
        return self._publish(topic, payload, retain=True)
