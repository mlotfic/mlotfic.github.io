# Alarm Manager Module - Complete Index

## Quick Navigation

**🚀 Want to get started quickly?**  
→ Read [QUICKSTART.md](../QUICKSTART.md)

**📖 Need full documentation?**  
→ Read [README.md](../README.md)

**🎯 Want implementation guidance?**  
→ Read [pm5110_alarm_mapping_guide.md](pm5110_alarm_mapping_guide.md)

**🔧 Need technical details?**  
→ Read [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md)

---

## Document Directory

### Getting Started

| Document | Purpose | Audience |
|----------|---------|----------|
| [QUICKSTART.md](../QUICKSTART.md) | 5-minute setup with Docker | Everyone |
| [README.md](../README.md) | Complete reference documentation | Developers, Engineers |

### Implementation Guides

| Document | Purpose | Audience |
|----------|---------|----------|
| [pm5110_alarm_mapping_guide.md](pm5110_alarm_mapping_guide.md) | Device→ISA alarm mapping theory | Control Engineers, Developers |
| [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) | Technical implementation details | Developers |

### Configuration Templates

| File | Purpose |
|------|---------|
| [templates/device_alarm_map.csv](../templates/device_alarm_map.csv) | Map device bits to alarm names |
| [templates/isa_alarm_definition_template.csv](../templates/isa_alarm_definition_template.csv) | Define ISA operator alarms |
| [templates/isa_alarm_cause_map.csv](../templates/isa_alarm_cause_map.csv) | Map fault codes to causes |
| [templates/isa_alarm_suppression_matrix.csv](../templates/isa_alarm_suppression_matrix.csv) | Define suppression rules |

### Code Modules

| Module | Purpose |
|--------|---------|
| [src/alarm_manager.py](../src/alarm_manager.py) | Main application orchestrator |
| [src/modbus_poller.py](../src/modbus_poller.py) | Modbus polling with edge detection |
| [src/alarm_mapper.py](../src/alarm_mapper.py) | ISA alarm mapping engine |
| [src/database.py](../src/database.py) | PostgreSQL storage |
| [src/uns_publisher.py](../src/uns_publisher.py) | MQTT/UNS publishing |
| [src/config.py](../src/config.py) | Configuration management |

### Database

| File | Purpose |
|------|---------|
| [migrations/001_create_alarm_tables.sql](../migrations/001_create_alarm_tables.sql) | Complete database schema |

### Deployment

| File | Purpose |
|------|---------|
| [docker-compose.yml](../docker-compose.yml) | Complete stack deployment |
| [Dockerfile](../Dockerfile) | Application container |
| [config/config.yaml](../config/config.yaml) | Application configuration |

### Utilities

| Script | Purpose |
|--------|---------|
| [tests/test_alarm_manager.py](../tests/test_alarm_manager.py) | Test database, MQTT, storage |
| [scripts/import_csv.py](../scripts/import_csv.py) | Import CSV templates to database |

---

## Common Tasks

### Task: Add a New Modbus Device

1. Edit `config/config.yaml` - add device configuration
2. Edit `templates/device_alarm_map.csv` - add alarm bit mappings
3. Run `python scripts/import_csv.py` - import to database
4. Restart alarm manager

**Reference:** [README.md - Adding a New Device](../README.md#adding-a-new-modbus-device)

### Task: Create a New ISA Alarm

1. Edit `templates/isa_alarm_definition_template.csv` - add alarm definition
2. Optionally edit `templates/isa_alarm_cause_map.csv` - add cause mapping
3. Run `python scripts/import_csv.py` - import to database
4. Restart alarm manager

**Reference:** [README.md - Creating New ISA Alarm](../README.md#creating-a-new-isa-alarm)

### Task: Add Suppression Rule

1. Edit `templates/isa_alarm_suppression_matrix.csv` - add rule
2. Run `python scripts/import_csv.py` - import to database
3. Restart alarm manager

**Reference:** [README.md - Adding Suppression Rules](../README.md#adding-suppression-rules)

### Task: View Active Alarms

**Database:**
```sql
SELECT * FROM active_isa_alarms;
```

**MQTT:**
Subscribe to: `UNS/EgyptPlant/scada/alarms/isa/state`

**Reference:** [README.md - Database Queries](../README.md#database-queries)

---

## Learning Path

### For Plant Engineers
1. Read [pm5110_alarm_mapping_guide.md](pm5110_alarm_mapping_guide.md) - understand device vs ISA alarms
2. Review CSV templates - see alarm rationalization
3. Read [QUICKSTART.md](../QUICKSTART.md) - deploy and test

### For SCADA Developers
1. Read [QUICKSTART.md](../QUICKSTART.md) - deploy the system
2. Review MQTT topics in [README.md](../README.md#mqttuns-topics)
3. Read [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) - understand architecture
4. Review [src/alarm_manager.py](../src/alarm_manager.py) - see main logic

### For Database Administrators
1. Read [migrations/001_create_alarm_tables.sql](../migrations/001_create_alarm_tables.sql) - see schema
2. Review [README.md - Database Queries](../README.md#database-queries)
3. Review [README.md - Performance Tuning](../README.md#performance-tuning)

### For Control System Integrators
1. Read [pm5110_alarm_mapping_guide.md](pm5110_alarm_mapping_guide.md) - theory
2. Read [README.md](../README.md) - full reference
3. Review CSV templates - configuration format
4. Read [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) - customization

---

## Module Structure Visual

```
alarm_manager/
│
├── 📄 README.md                    ← Start here for full docs
├── 📄 QUICKSTART.md                ← Start here for quick setup
│
├── config/                         ← Configuration
│   ├── config.yaml                 ← Main config file
│   ├── .env.example                ← Environment variables
│   └── mosquitto.conf              ← MQTT broker config
│
├── docs/                           ← Documentation
│   ├── INDEX.md                    ← This file
│   ├── pm5110_alarm_mapping_guide.md
│   └── IMPLEMENTATION_SUMMARY.md
│
├── migrations/                     ← Database
│   └── 001_create_alarm_tables.sql
│
├── src/                            ← Application code
│   ├── alarm_manager.py            ← Main application
│   ├── modbus_poller.py            ← Modbus polling
│   ├── alarm_mapper.py             ← ISA mapping engine
│   ├── database.py                 ← Storage
│   ├── uns_publisher.py            ← MQTT publishing
│   └── config.py                   ← Config management
│
├── templates/                      ← CSV configuration
│   ├── device_alarm_map.csv
│   ├── isa_alarm_definition_template.csv
│   ├── isa_alarm_cause_map.csv
│   └── isa_alarm_suppression_matrix.csv
│
├── tests/                          ← Testing
│   └── test_alarm_manager.py
│
├── scripts/                        ← Utilities
│   └── import_csv.py
│
├── docker-compose.yml              ← Full stack deployment
├── Dockerfile                      ← Application container
└── requirements.txt                ← Python dependencies
```

---

## Support & Troubleshooting

**Something not working?**

1. Check logs: `docker-compose logs -f alarm-manager`
2. Run tests: `docker-compose exec alarm-manager python /app/tests/test_alarm_manager.py`
3. Review [README.md - Troubleshooting](../README.md#troubleshooting)

**Need to customize?**

1. Review [IMPLEMENTATION_SUMMARY.md - Customization Guide](IMPLEMENTATION_SUMMARY.md#customization-guide)
2. Check CSV templates for configuration format
3. Review source code with inline comments

---

**Version:** 1.0  
**Last Updated:** 2026-02-02
