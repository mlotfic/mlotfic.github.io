# PM5110 → SCADA ISA Alarm Mapping Guide
**Implementation-Focused | Industry Best Practice | Version 1.0**

---

## 1. THE THREE LAYERS (Keep Separate)

```
┌─────────────────────────────────────────────────────────────────┐
│ DEVICE LAYER (PM5110)                                           │
│ • Raw alarms (phase loss, overvoltage, reverse power)          │
│ • Built-in vendor setpoints                                     │
│ • Diagnostic codes & registers                                  │
│ → PURPOSE: Equipment protection + maintenance diagnostics       │
└─────────────────────────────────────────────────────────────────┘
                              ↓ MAPPING LAYER
┌─────────────────────────────────────────────────────────────────┐
│ SCADA ISA-18.2 LAYER                                            │
│ • Operator alarms only (action required)                        │
│ • Plant-defined setpoints (HH/H/L/LL)                          │
│ • Priority, guidance, suppression, shelving                     │
│ → PURPOSE: Safe operation + timely operator response            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ HISTORIAN/LOG LAYER                                             │
│ • ALL device events (transitions)                               │
│ • ALL ISA alarm lifecycle (ON/ACK/OFF)                         │
│ • Operator actions, suppression events                          │
│ → PURPOSE: Forensics, trending, audit, KPIs                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. UNS TOPIC STRUCTURE (Simple & Real)

```
UNS/
  EgyptPlant/                          ← Your site
    devices/
      PM5110_MTR01/
        alarms/state                   ← Current active device alarms
        alarms/events                  ← Alarm transitions (ON/OFF only)
        diagnostics                    ← Fault codes, register snapshots
        telemetry                      ← Normal process values (V, I, kW)
    
    scada/
      alarms/isa/state                 ← Current ISA alarms (all assets)
      alarms/isa/events                ← ISA lifecycle (ON/ACK/CLEAR)
      alarms/isa/suppressed            ← Suppression tracking
      events/                          ← Derived events (trips, mode changes)
      diagnostics/                     ← Enriched device diagnostics
```

**Topic Naming Rules:**
- `/state` = snapshot (current state, retained)
- `/events` = transitions (timestamped, not retained)
- `/diagnostics` = detailed info (maintenance/engineering)

---

## 3. DECISION WORKFLOW (Device Alarm → ISA Alarm?)

```
┌─────────────────────────────────────┐
│ PM5110 Device Alarm Detected        │
│ (e.g., Phase Loss, Overvoltage)     │
└──────────────┬──────────────────────┘
               ↓
┌──────────────────────────────────────────────────────────────┐
│ QUESTION 1: Can operator take action?                        │
│ □ Yes → Continue                                             │
│ □ No → DEVICE EVENT ONLY (store in diagnostics)             │
└──────────────┬───────────────────────────────────────────────┘
               ↓
┌──────────────────────────────────────────────────────────────┐
│ QUESTION 2: Does it impact safety/production/quality/asset?  │
│ □ Yes → Continue                                             │
│ □ No → DEVICE EVENT ONLY                                     │
└──────────────┬───────────────────────────────────────────────┘
               ↓
┌──────────────────────────────────────────────────────────────┐
│ QUESTION 3: Will it cause alarm flood/chatter?               │
│ □ No → CREATE ISA ALARM                                      │
│ □ Yes → Add delay/deadband OR aggregate to parent alarm      │
└──────────────┬───────────────────────────────────────────────┘
               ↓
         ┌─────┴─────┐
         ↓           ↓
    ISA ALARM    DEVICE EVENT
```

---

## 4. PM5110 EXAMPLE MAPPING

### PM5110 Modbus Alarm Register: HR40112 (16-bit bitmap)

| Bit | Device Alarm Name | Operator Can Act? | Consequence? | ISA Alarm? | ISA Alarm ID | Priority |
|-----|-------------------|-------------------|--------------|------------|--------------|----------|
| 0   | Phase Loss        | YES               | YES (Safety) | **YES**    | PWR_PHASE_LOSS | HIGH |
| 1   | Reverse Power     | MAYBE             | Maybe ($$)   | **IF** export matters | PWR_REV_POWER | MED |
| 2   | Overcurrent       | YES               | YES (Asset)  | **YES**    | PWR_OVERCURRENT | HIGH |
| 3   | Overvoltage       | YES               | YES (Asset)  | **YES**    | PWR_OVERVOLTAGE | MED |
| 4   | CT Wiring Error   | NO (maint)        | NO (diagnostic) | **NO** | - | - |
| 5   | Internal Fault    | NO (vendor)       | NO (diagnostic) | **NO** | - | - |

**Result:**
- **3-4 ISA alarms** (operator layer)
- **6 device events** stored (diagnostic layer)
- **1 device** but multiple alarm sources

---

## 5. STORAGE SCHEMA (Recommended: PostgreSQL/TimescaleDB)

### Table 1: `device_alarm_events` (Raw Truth)

```sql
CREATE TABLE device_alarm_events (
  id              BIGSERIAL PRIMARY KEY,
  ts_utc          TIMESTAMPTZ NOT NULL,
  site_id         TEXT NOT NULL,
  device_id       TEXT NOT NULL,        -- 'PM5110_MTR01'
  alarm_source    TEXT NOT NULL,        -- 'HR40112.bit0'
  alarm_name      TEXT NOT NULL,        -- 'phase_loss'
  state           BOOLEAN NOT NULL,     -- TRUE=ON, FALSE=OFF
  raw_value_hex   TEXT,                 -- '0x0001' (full register)
  quality         TEXT NOT NULL,        -- 'GOOD', 'BAD', 'UNCERTAIN'
  
  INDEX idx_device_alarm_ts (device_id, ts_utc DESC)
);
```

**When to Insert:**
- Store only **transitions** (0→1 or 1→0)
- NOT every poll sample

---

### Table 2: `isa_alarm_events` (Operator Alarm Lifecycle)

```sql
CREATE TABLE isa_alarm_events (
  id              BIGSERIAL PRIMARY KEY,
  ts_utc          TIMESTAMPTZ NOT NULL,
  site_id         TEXT NOT NULL,
  alarm_id        TEXT NOT NULL,        -- 'PWR_PHASE_LOSS'
  event_type      TEXT NOT NULL,        -- 'ON', 'ACK', 'CLEAR'
  priority        TEXT NOT NULL,        -- 'HIGH', 'MEDIUM', 'LOW'
  state           BOOLEAN,              -- TRUE=active (for ON/CLEAR events)
  
  -- Cause mapping (from device layer)
  cause_device_id TEXT,                 -- 'PM5110_MTR01'
  cause_alarm_id  TEXT,                 -- 'phase_loss'
  cause_text      TEXT,                 -- 'Phase failure detected'
  
  -- Operator interaction
  ack_user        TEXT,
  ack_ts_utc      TIMESTAMPTZ,
  
  -- Suppression tracking
  suppressed      BOOLEAN DEFAULT FALSE,
  suppressed_by   TEXT,                 -- Parent alarm ID
  
  INDEX idx_isa_alarm_ts (alarm_id, ts_utc DESC)
);
```

**When to Insert:**
- Every ISA alarm state change (ON/ACK/CLEAR)
- Suppression events
- Shelving events

---

### Table 3: `device_diagnostics` (Snapshots)

```sql
CREATE TABLE device_diagnostics (
  id              BIGSERIAL PRIMARY KEY,
  ts_utc          TIMESTAMPTZ NOT NULL,
  device_id       TEXT NOT NULL,
  diagnostic_type TEXT NOT NULL,        -- 'fault_snapshot', 'register_dump'
  fault_code      INTEGER,
  register_values JSONB,                -- Full context at fault time
  context         JSONB,                -- Process vars (V, I, kW, PF)
  
  INDEX idx_device_diag_ts (device_id, ts_utc DESC)
);
```

**When to Insert:**
- On fault/trip occurrence
- Periodic snapshots (configurable)
- Manual diagnostic request

---

## 6. IMPLEMENTATION WORKFLOW (Step-by-Step)

### Step 1: Poll PM5110 Modbus
```python
# Poll HR40112 every 1-5 seconds
current_word = modbus_read(unit=1, register=40112)
```

### Step 2: Detect Transitions (Edge Detection)
```python
changed_bits = previous_word ^ current_word

for bit in range(16):
    if changed_bits & (1 << bit):
        state = bool(current_word & (1 << bit))
        
        # Store device event
        store_device_event(
            device_id='PM5110_MTR01',
            alarm_source=f'HR40112.bit{bit}',
            alarm_name=alarm_map[bit],
            state=state,
            raw_value=hex(current_word)
        )
        
        # Publish to UNS
        publish_uns(
            topic=f'UNS/EgyptPlant/devices/PM5110_MTR01/alarms/events',
            payload={
                'ts': now_utc(),
                'event': 'ON' if state else 'OFF',
                'alarm': {'id': alarm_map[bit]},
                'source': {'register': 'HR40112', 'bit': bit},
                'raw': hex(current_word)
            }
        )
```

### Step 3: Evaluate ISA Alarm Mapping
```python
# Check if this device alarm triggers ISA alarm
isa_alarm = isa_mapping_table.get(device_id, alarm_name)

if isa_alarm:
    # Apply delays/deadbands (from isa_alarm_definition)
    if evaluate_condition(isa_alarm):
        # Check suppression rules
        if not is_suppressed(isa_alarm.id):
            # Activate ISA alarm
            activate_isa_alarm(
                alarm_id=isa_alarm.id,
                cause_device=device_id,
                cause_alarm=alarm_name,
                cause_text=cause_map.get(alarm_name)
            )
```

### Step 4: Store & Publish ISA Alarm
```python
# Store in database
store_isa_event(
    alarm_id='PWR_PHASE_LOSS',
    event_type='ON',
    priority='HIGH',
    cause_device_id='PM5110_MTR01',
    cause_alarm_id='phase_loss',
    cause_text='Phase failure detected on L1'
)

# Publish to UNS
publish_uns(
    topic='UNS/EgyptPlant/scada/alarms/isa/events',
    payload={
        'ts': now_utc(),
        'event': 'ON',
        'alarm': {
            'id': 'PWR_PHASE_LOSS',
            'priority': 'HIGH',
            'guidance': 'Check MCC feeder. Verify phase sequence.'
        },
        'cause': {
            'device': 'PM5110_MTR01',
            'alarm': 'phase_loss'
        }
    }
)
```

---

## 7. SUPPRESSION RULES (Anti-Flood)

### Example: Network Segment Down

**Problem:** 
- Network switch fails
- 47 devices lose communication
- 47 "Comm Loss" alarms fire → ALARM FLOOD

**Solution:**
```
PARENT ISA ALARM:    NET_SEG_A_DOWN (HIGH priority)
SUPPRESSED ALARMS:   All device-level comm_loss alarms
SUPPRESSION LOGIC:   While NET_SEG_A_DOWN is active
```

**Result:**
- Operator sees **1 alarm**: "Network Segment A Down (47 devices affected)"
- Device comm events still logged (for diagnostics)
- When network recovers, segment alarm clears, device alarms can activate again

---

## 8. PAYLOAD EXAMPLES (One Per Layer)

### Device Alarm Event (UNS)
```json
{
  "ts": "2026-02-02T14:30:15.231Z",
  "event": "ON",
  "alarm": {"id": "phase_loss"},
  "source": {"register": "HR40112", "bit": 0},
  "raw": "0x0001",
  "quality": "GOOD"
}
```

### ISA Alarm Event (UNS)
```json
{
  "ts": "2026-02-02T14:30:15.350Z",
  "event": "ON",
  "alarm": {
    "id": "PWR_PHASE_LOSS",
    "priority": "HIGH",
    "guidance": "Check MCC feeder. Verify phase sequence."
  },
  "cause": {
    "device": "PM5110_MTR01",
    "alarm": "phase_loss",
    "text": "Phase failure detected on L1"
  }
}
```

### ISA Alarm ACK Event (UNS)
```json
{
  "ts": "2026-02-02T14:31:42.100Z",
  "event": "ACK",
  "alarm": {"id": "PWR_PHASE_LOSS"},
  "ack": {
    "user": "operator_3",
    "comment": "Contacted maintenance - Phase L1 breaker tripped"
  }
}
```

---

## 9. QUICK DECISION TABLES

### Device Alarm Classification
| If Alarm Is... | Store As | Show Operator? | Action |
|----------------|----------|----------------|--------|
| Trip/Fault causing equipment stop | ISA Alarm | YES | Immediate action required |
| Sensor failure affecting control | ISA Alarm | YES | Switch to manual/backup |
| Maintenance warning (fan fail, etc.) | Device Event | NO | Maintenance dashboard |
| Transient diagnostic | Device Event | NO | Log only |
| Communication loss (device level) | Device Event | NO | Log + segment-level ISA |

### Storage Decision
| Data Type | Store Where | Retention | Purpose |
|-----------|-------------|-----------|---------|
| Device alarm transitions | `device_alarm_events` | 2+ years | Forensics, RCA |
| ISA alarm lifecycle | `isa_alarm_events` | Permanent | Audit, KPIs |
| Device diagnostics snapshots | `device_diagnostics` | 1+ year | Troubleshooting |
| Process telemetry | Time-series DB | 1-5 years | Trending |

---

## 10. IMPLEMENTATION CHECKLIST

**Phase 1: Device Layer**
- [ ] Poll PM5110 Modbus registers (HR40112)
- [ ] Implement edge detection (XOR previous vs current)
- [ ] Store device events (transitions only)
- [ ] Publish to UNS `devices/PM5110_MTR01/alarms/events`

**Phase 2: Mapping Layer**
- [ ] Create `isa_alarm_definition` table (from CSV template)
- [ ] Create `isa_alarm_cause_map` table (fault code → guidance)
- [ ] Create `isa_alarm_suppression_matrix` table
- [ ] Implement mapping logic (device event → ISA alarm evaluation)

**Phase 3: ISA Alarm Layer**
- [ ] Implement alarm condition evaluation (delays, deadbands)
- [ ] Implement suppression engine
- [ ] Store ISA events (`isa_alarm_events` table)
- [ ] Publish to UNS `scada/alarms/isa/events`

**Phase 4: Operator Interface**
- [ ] SCADA alarm banner (subscribe to UNS ISA alarms)
- [ ] Alarm acknowledgement workflow
- [ ] Shelving UI (with time limits)
- [ ] Alarm history viewer

**Phase 5: Maintenance Interface**
- [ ] Device diagnostics dashboard
- [ ] Fault code lookup table
- [ ] Trending of device events
- [ ] Top 10 nuisance alarms report

---

## 11. GOLDEN RULES (Never Violate)

1. **Device Alarms ≠ ISA Alarms**
   - Don't blindly convert all device bits to operator alarms
   - Device alarms = evidence | ISA alarms = operator story

2. **Store Transitions, Not Polls**
   - Polling every 1s → 86,400 records/day (BLOAT)
   - Storing transitions → 5-50 records/day (CLEAN)

3. **One Consequence = One ISA Alarm**
   - Pump trip causes: VFD fault + flow low + pressure low
   - Create **1 ISA alarm** ("PUMP_01_TRIP"), suppress the rest

4. **Always Include Raw Evidence**
   - Store `raw_value_hex`, `register`, `bit`, `quality`
   - Vendor docs lie; raw data saves you

5. **Quality Matters**
   - If `quality=BAD` (comm loss), don't auto-clear alarms
   - Freeze state until confirmed

6. **Suppression Is Mandatory**
   - Trip must suppress consequence alarms
   - Network down must suppress device comm alarms

7. **Cause Mapping Is Your Secret Weapon**
   - Operator sees: "Pump trip"
   - Details show: "VFD fault code 11 = Overcurrent. Check motor cable."

---

## 12. COMMON MISTAKES TO AVOID

❌ **Mistake 1:** Dump all 16 bits of HR40112 as 16 ISA alarms
✅ **Fix:** Create 2-4 ISA alarms max, rest as diagnostics

❌ **Mistake 2:** Store every poll sample
✅ **Fix:** Store only transitions (XOR detection)

❌ **Mistake 3:** Per-device comm loss alarms
✅ **Fix:** Segment-level ISA alarm, device-level events only

❌ **Mistake 4:** No delays/deadbands
✅ **Fix:** Add 2-10s on-delay, 1-2% deadband for analog

❌ **Mistake 5:** Mix device setpoints with ISA setpoints
✅ **Fix:** Device setpoints = protection (vendor). ISA setpoints = operation (plant).

---

## 13. FINAL ARCHITECTURE DIAGRAM

```
┌────────────────────────────────────────────────────────────────────┐
│                         PM5110 DEVICE                               │
│  Modbus TCP: HR40112 = 0x0001 (Phase Loss bit ON)                  │
└───────────────────────────┬────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────┐
│                    MODBUS POLLING ENGINE                            │
│  • Read HR40112 every 1-5s                                          │
│  • XOR detect bit changes                                           │
│  • Publish device events to UNS                                     │
└───────────────────────────┬────────────────────────────────────────┘
                            ↓
         ┌──────────────────┴──────────────────┐
         ↓                                     ↓
┌─────────────────────┐              ┌─────────────────────┐
│  UNS Device Topic   │              │  device_alarm_      │
│  .../alarms/events  │──────────────│  events (DB)        │
│                     │              │  (Historian)        │
└─────────────────────┘              └─────────────────────┘
         ↓
┌────────────────────────────────────────────────────────────────────┐
│                  ALARM MAPPING ENGINE                               │
│  • Check isa_alarm_definition table                                 │
│  • Apply isa_alarm_cause_map (fault code → guidance)                │
│  • Apply isa_alarm_suppression_matrix                               │
│  • Evaluate delays/deadbands                                        │
└───────────────────────────┬────────────────────────────────────────┘
                            ↓
         ┌──────────────────┴──────────────────┐
         ↓                                     ↓
┌─────────────────────┐              ┌─────────────────────┐
│  UNS ISA Topic      │              │  isa_alarm_events   │
│  .../isa/events     │──────────────│  (DB)               │
│                     │              │  (Historian)        │
└─────────────────────┘              └─────────────────────┘
         ↓
┌────────────────────────────────────────────────────────────────────┐
│                   SCADA OPERATOR INTERFACE                          │
│  • Alarm banner (subscribe to UNS ISA alarms)                       │
│  • Acknowledgement workflow                                         │
│  • Shelving controls                                                │
│  • Cause/guidance display                                           │
└────────────────────────────────────────────────────────────────────┘
```

---

## REFERENCES

- **ISA-18.2**: Alarm Management Lifecycle Standard
- **UNS Best Practices**: Walker Reynolds (4.0 Solutions)
- **CSV Templates**: See separate files:
  - `isa_alarm_definition_template.csv`
  - `isa_alarm_cause_map.csv`
  - `isa_alarm_suppression_matrix.csv`

---

**Last Updated:** 2026-02-02  
**Maintained By:** SCADA Engineering Team  
**Version:** 1.0 (Production Ready)
