-- ============================================================================
-- ALARM MANAGER DATABASE SCHEMA
-- Version: 1.0
-- Purpose: ISA-18.2 compliant alarm management system
-- ============================================================================

-- ============================================================================
-- 1. DEVICE LAYER TABLES
-- ============================================================================

-- Table: device_alarm_events
-- Purpose: Store raw device alarm state transitions (ON/OFF)
-- Storage: Transitions only, not polls
CREATE TABLE IF NOT EXISTS device_alarm_events (
    id                  BIGSERIAL PRIMARY KEY,
    ts_utc              TIMESTAMPTZ NOT NULL,
    site_id             TEXT NOT NULL,
    device_id           TEXT NOT NULL,
    alarm_source        TEXT NOT NULL,          -- e.g., 'HR40112.bit0'
    alarm_id            TEXT NOT NULL,          -- e.g., 'phase_loss'
    alarm_name          TEXT NOT NULL,
    state               BOOLEAN NOT NULL,       -- TRUE=ON, FALSE=OFF
    raw_value_hex       TEXT,                   -- Full register value
    quality             TEXT NOT NULL,          -- 'GOOD', 'BAD', 'UNCERTAIN'
    poll_cycle_ms       INTEGER,
    sequence_num        BIGINT,                 -- Monotonic per device
    metadata            JSONB,                  -- Additional context
    
    CONSTRAINT chk_quality CHECK (quality IN ('GOOD', 'BAD', 'UNCERTAIN'))
);

-- Indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_device_alarm_device_ts 
    ON device_alarm_events(device_id, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_device_alarm_site_ts 
    ON device_alarm_events(site_id, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_device_alarm_alarm_id 
    ON device_alarm_events(alarm_id, ts_utc DESC);

-- Hypertable for TimescaleDB (optional, comment out if using plain Postgres)
-- SELECT create_hypertable('device_alarm_events', 'ts_utc', if_not_exists => TRUE);


-- Table: device_diagnostics
-- Purpose: Store device fault snapshots and diagnostic data
CREATE TABLE IF NOT EXISTS device_diagnostics (
    id                  BIGSERIAL PRIMARY KEY,
    ts_utc              TIMESTAMPTZ NOT NULL,
    site_id             TEXT NOT NULL,
    device_id           TEXT NOT NULL,
    diagnostic_type     TEXT NOT NULL,          -- 'fault_snapshot', 'register_dump'
    fault_code          INTEGER,
    fault_code_hex      TEXT,
    register_values     JSONB,                  -- Full context at fault time
    process_context     JSONB,                  -- Process variables (V, I, kW, etc.)
    metadata            JSONB,
    
    CONSTRAINT chk_diag_type CHECK (diagnostic_type IN (
        'fault_snapshot', 
        'register_dump', 
        'periodic_snapshot',
        'manual_request'
    ))
);

CREATE INDEX IF NOT EXISTS idx_device_diag_device_ts 
    ON device_diagnostics(device_id, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_device_diag_fault_code 
    ON device_diagnostics(fault_code) WHERE fault_code IS NOT NULL;


-- ============================================================================
-- 2. ISA ALARM LAYER TABLES
-- ============================================================================

-- Table: isa_alarm_definitions
-- Purpose: ISA-18.2 alarm configuration (rationalized alarms)
CREATE TABLE IF NOT EXISTS isa_alarm_definitions (
    id                          SERIAL PRIMARY KEY,
    isa_alarm_id                TEXT UNIQUE NOT NULL,
    alarm_name                  TEXT NOT NULL,
    asset_id                    TEXT NOT NULL,
    tag_or_point_id             TEXT NOT NULL,
    alarm_type                  TEXT NOT NULL,
    condition_expression        TEXT NOT NULL,
    engineering_units           TEXT,
    
    -- Setpoints
    limit_hh                    NUMERIC,
    limit_h                     NUMERIC,
    limit_l                     NUMERIC,
    limit_ll                    NUMERIC,
    
    -- Stability controls
    deadband_value              NUMERIC NOT NULL DEFAULT 0,
    deadband_type               TEXT NOT NULL DEFAULT 'ABS',
    on_delay_s                  INTEGER NOT NULL DEFAULT 0,
    off_delay_s                 INTEGER NOT NULL DEFAULT 0,
    latch_mode                  TEXT NOT NULL DEFAULT 'NONE',
    reset_condition             TEXT,
    
    -- ISA-18.2 fields
    priority                    TEXT NOT NULL,
    classification              TEXT NOT NULL,
    consequence                 TEXT NOT NULL,
    operator_action             TEXT NOT NULL,
    guidance_text               TEXT NOT NULL,
    response_time_minutes       INTEGER NOT NULL,
    requires_ack                BOOLEAN NOT NULL DEFAULT TRUE,
    ack_timeout_minutes         INTEGER,
    
    -- Shelving
    shelving_allowed            BOOLEAN NOT NULL DEFAULT FALSE,
    max_shelve_minutes          INTEGER,
    
    -- Suppression
    suppression_parent_alarm_id TEXT,
    suppression_condition       TEXT,
    
    -- Metadata
    alarm_group                 TEXT,
    cause_source_type           TEXT,
    cause_source_asset          TEXT,
    cause_source_point          TEXT,
    cause_mapping_rule          TEXT,
    notification_channels       TEXT,
    display_path                TEXT,
    enabled                     BOOLEAN NOT NULL DEFAULT TRUE,
    notes                       TEXT,
    
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_alarm_type CHECK (alarm_type IN ('ANALOG', 'DIGITAL', 'DERIVED', 'SYSTEM')),
    CONSTRAINT chk_deadband_type CHECK (deadband_type IN ('ABS', 'PCT')),
    CONSTRAINT chk_latch_mode CHECK (latch_mode IN ('NONE', 'LATCH_UNTIL_ACK', 'LATCH_UNTIL_RESET')),
    CONSTRAINT chk_priority CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW')),
    CONSTRAINT chk_classification CHECK (classification IN (
        'SAFETY', 'ENV', 'PRODUCTION', 'QUALITY', 'MAINT', 'SECURITY', 'SYSTEM'
    ))
);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_def_asset 
    ON isa_alarm_definitions(asset_id);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_def_enabled 
    ON isa_alarm_definitions(enabled) WHERE enabled = TRUE;


-- Table: isa_alarm_events
-- Purpose: ISA alarm lifecycle events (ON/ACK/CLEAR)
CREATE TABLE IF NOT EXISTS isa_alarm_events (
    id                      BIGSERIAL PRIMARY KEY,
    ts_utc                  TIMESTAMPTZ NOT NULL,
    site_id                 TEXT NOT NULL,
    alarm_id                TEXT NOT NULL,
    event_type              TEXT NOT NULL,
    priority                TEXT NOT NULL,
    state                   BOOLEAN,                -- For ON/CLEAR events
    
    -- Cause mapping
    cause_device_id         TEXT,
    cause_alarm_id          TEXT,
    cause_text              TEXT,
    
    -- Operator interaction
    ack_user                TEXT,
    ack_ts_utc              TIMESTAMPTZ,
    ack_comment             TEXT,
    
    -- Suppression tracking
    suppressed              BOOLEAN DEFAULT FALSE,
    suppressed_by           TEXT,
    suppressed_reason       TEXT,
    
    -- Shelving tracking
    shelved                 BOOLEAN DEFAULT FALSE,
    shelved_by              TEXT,
    shelved_until           TIMESTAMPTZ,
    shelve_reason           TEXT,
    
    -- Metadata
    metadata                JSONB,
    
    CONSTRAINT chk_event_type CHECK (event_type IN ('ON', 'ACK', 'CLEAR', 'SHELVE', 'UNSHELVE')),
    CONSTRAINT chk_isa_priority CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW'))
);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_event_alarm_ts 
    ON isa_alarm_events(alarm_id, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_event_site_ts 
    ON isa_alarm_events(site_id, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_event_type 
    ON isa_alarm_events(event_type, ts_utc DESC);

CREATE INDEX IF NOT EXISTS idx_isa_alarm_event_unack 
    ON isa_alarm_events(alarm_id, ts_utc DESC) 
    WHERE event_type = 'ON' AND ack_user IS NULL;

-- Hypertable for TimescaleDB (optional)
-- SELECT create_hypertable('isa_alarm_events', 'ts_utc', if_not_exists => TRUE);


-- Table: isa_alarm_cause_map
-- Purpose: Map device fault codes to cause text and guidance
CREATE TABLE IF NOT EXISTS isa_alarm_cause_map (
    id                          SERIAL PRIMARY KEY,
    cause_map_id                TEXT UNIQUE NOT NULL,
    device_type                 TEXT NOT NULL,
    vendor                      TEXT,
    model                       TEXT,
    source_asset_id             TEXT,
    source_point                TEXT NOT NULL,
    source_kind                 TEXT NOT NULL,
    code_type                   TEXT NOT NULL,
    code_value                  INTEGER,
    code_value_hex              TEXT,
    alarm_bit                   INTEGER,
    alarm_id                    TEXT,
    
    -- Outputs
    cause_text                  TEXT NOT NULL,
    recommended_action          TEXT NOT NULL,
    recommended_action_steps    TEXT NOT NULL,
    severity_hint               TEXT NOT NULL,
    isa_alarm_id                TEXT,
    operator_message_template   TEXT NOT NULL,
    maintenance_message_template TEXT NOT NULL,
    notes                       TEXT,
    
    CONSTRAINT chk_source_kind CHECK (source_kind IN ('FAULT_CODE', 'ALARM_WORD', 'EVENT_CODE')),
    CONSTRAINT chk_code_type CHECK (code_type IN ('UINT16', 'UINT32', 'ENUM', 'BITMAP')),
    CONSTRAINT chk_severity_hint CHECK (severity_hint IN ('TRIP', 'WARNING', 'MAINT', 'INFO'))
);

CREATE INDEX IF NOT EXISTS idx_cause_map_device_type 
    ON isa_alarm_cause_map(device_type, source_point);

CREATE INDEX IF NOT EXISTS idx_cause_map_code 
    ON isa_alarm_cause_map(code_value) WHERE code_value IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_cause_map_bit 
    ON isa_alarm_cause_map(alarm_bit) WHERE alarm_bit IS NOT NULL;


-- Table: isa_alarm_suppression_matrix
-- Purpose: Define parent-child alarm suppression rules
CREATE TABLE IF NOT EXISTS isa_alarm_suppression_matrix (
    id                              SERIAL PRIMARY KEY,
    rule_id                         TEXT UNIQUE NOT NULL,
    enabled                         BOOLEAN NOT NULL DEFAULT TRUE,
    site_id                         TEXT,
    area_id                         TEXT,
    unit_id                         TEXT,
    
    -- Parent → Suppressed
    parent_alarm_id                 TEXT NOT NULL,
    parent_alarm_name               TEXT NOT NULL,
    suppressed_alarm_id             TEXT NOT NULL,
    suppressed_alarm_name           TEXT NOT NULL,
    
    -- Suppression behavior
    suppression_type                TEXT NOT NULL,
    suppression_condition_expression TEXT NOT NULL,
    activation_delay_s              INTEGER NOT NULL DEFAULT 0,
    release_delay_s                 INTEGER NOT NULL DEFAULT 0,
    priority_override               TEXT,
    suppression_reason              TEXT NOT NULL,
    operator_message                TEXT NOT NULL,
    notes                           TEXT,
    
    CONSTRAINT chk_suppression_type CHECK (suppression_type IN (
        'STATE_BASED', 'TIME_BASED', 'MODE_BASED'
    ))
);

CREATE INDEX IF NOT EXISTS idx_suppression_parent 
    ON isa_alarm_suppression_matrix(parent_alarm_id) WHERE enabled = TRUE;

CREATE INDEX IF NOT EXISTS idx_suppression_suppressed 
    ON isa_alarm_suppression_matrix(suppressed_alarm_id) WHERE enabled = TRUE;


-- Table: device_alarm_map
-- Purpose: Map device registers/bits to alarm names
CREATE TABLE IF NOT EXISTS device_alarm_map (
    id                      SERIAL PRIMARY KEY,
    device_id               TEXT NOT NULL,
    device_type             TEXT NOT NULL,
    vendor                  TEXT,
    model                   TEXT,
    source_type             TEXT NOT NULL,
    source_address          TEXT NOT NULL,
    data_type               TEXT NOT NULL,
    bit_number              INTEGER,
    alarm_id                TEXT NOT NULL,
    alarm_name              TEXT NOT NULL,
    alarm_description       TEXT NOT NULL,
    convert_to_isa          TEXT NOT NULL,
    isa_alarm_id            TEXT,
    priority_hint           TEXT,
    category                TEXT NOT NULL,
    typical_cause           TEXT NOT NULL,
    notes                   TEXT,
    
    CONSTRAINT chk_source_type CHECK (source_type IN ('ALARM_WORD', 'FAULT_CODE', 'STATUS_WORD', 'EVENT_CODE')),
    CONSTRAINT chk_data_type CHECK (data_type IN ('UINT16', 'UINT32', 'BOOL')),
    CONSTRAINT chk_convert_to_isa CHECK (convert_to_isa IN ('Y', 'N', 'MAYBE')),
    CONSTRAINT chk_category CHECK (category IN ('SAFETY', 'PRODUCTION', 'MAINTENANCE', 'DIAGNOSTIC'))
);

CREATE INDEX IF NOT EXISTS idx_device_map_device 
    ON device_alarm_map(device_id, source_address);

CREATE UNIQUE INDEX IF NOT EXISTS idx_device_map_unique 
    ON device_alarm_map(device_id, source_address, bit_number) 
    WHERE bit_number IS NOT NULL;


-- ============================================================================
-- 3. VIEWS FOR COMMON QUERIES
-- ============================================================================

-- View: active_isa_alarms
-- Purpose: Current active ISA alarms (not acknowledged or not cleared)
CREATE OR REPLACE VIEW active_isa_alarms AS
SELECT DISTINCT ON (alarm_id)
    alarm_id,
    ts_utc,
    priority,
    cause_text,
    ack_user,
    ack_ts_utc,
    suppressed,
    suppressed_by
FROM isa_alarm_events
WHERE event_type IN ('ON', 'ACK')
    AND alarm_id NOT IN (
        SELECT alarm_id 
        FROM isa_alarm_events 
        WHERE event_type = 'CLEAR'
    )
ORDER BY alarm_id, ts_utc DESC;


-- View: active_device_alarms
-- Purpose: Current active device alarms
CREATE OR REPLACE VIEW active_device_alarms AS
SELECT DISTINCT ON (device_id, alarm_id)
    device_id,
    alarm_id,
    alarm_name,
    ts_utc,
    state,
    quality
FROM device_alarm_events
WHERE quality = 'GOOD'
ORDER BY device_id, alarm_id, ts_utc DESC;


-- View: alarm_performance_kpi
-- Purpose: Alarm KPIs for ISA-18.2 compliance monitoring
CREATE OR REPLACE VIEW alarm_performance_kpi AS
SELECT 
    DATE_TRUNC('day', ts_utc) AS day,
    COUNT(*) AS total_alarms,
    COUNT(CASE WHEN priority = 'HIGH' THEN 1 END) AS high_priority_count,
    COUNT(CASE WHEN priority = 'MEDIUM' THEN 1 END) AS medium_priority_count,
    COUNT(CASE WHEN priority = 'LOW' THEN 1 END) AS low_priority_count,
    AVG(EXTRACT(EPOCH FROM (ack_ts_utc - ts_utc))) AS avg_ack_time_seconds,
    COUNT(CASE WHEN suppressed THEN 1 END) AS suppressed_count
FROM isa_alarm_events
WHERE event_type = 'ON'
GROUP BY DATE_TRUNC('day', ts_utc)
ORDER BY day DESC;


-- ============================================================================
-- 4. TRIGGERS & FUNCTIONS
-- ============================================================================

-- Function: update_timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger: auto-update updated_at on isa_alarm_definitions
CREATE TRIGGER trg_isa_alarm_def_updated_at
    BEFORE UPDATE ON isa_alarm_definitions
    FOR EACH ROW
    EXECUTE FUNCTION update_timestamp();


-- ============================================================================
-- 5. SAMPLE DATA (for testing)
-- ============================================================================

-- Insert sample device alarm map entries
INSERT INTO device_alarm_map (device_id, device_type, vendor, model, source_type, source_address, data_type, bit_number, alarm_id, alarm_name, alarm_description, convert_to_isa, isa_alarm_id, priority_hint, category, typical_cause, notes)
VALUES 
    ('PM5110_MTR01', 'METER', 'Schneider', 'PM5110', 'ALARM_WORD', 'HR40112', 'UINT16', 0, 'phase_loss', 'Phase Loss', 'Phase loss or missing phase detected', 'Y', 'PWR_PHASE_LOSS', 'HIGH', 'SAFETY', 'Phase failure / fuse / contactor issue', 'Critical safety alarm'),
    ('PM5110_MTR01', 'METER', 'Schneider', 'PM5110', 'ALARM_WORD', 'HR40112', 'UINT16', 1, 'reverse_power', 'Reverse Power', 'Reverse power flow detected', 'MAYBE', 'PWR_REV_POWER', 'MEDIUM', 'PRODUCTION', 'CT polarity wrong or actual backfeed', 'Convert to ISA if billing critical'),
    ('PM5110_MTR01', 'METER', 'Schneider', 'PM5110', 'ALARM_WORD', 'HR40112', 'UINT16', 2, 'overcurrent', 'Overcurrent', 'Overcurrent condition detected', 'Y', 'PWR_OVERCURRENT', 'HIGH', 'PRODUCTION', 'Overload or short circuit', 'Asset protection'),
    ('PM5110_MTR01', 'METER', 'Schneider', 'PM5110', 'ALARM_WORD', 'HR40112', 'UINT16', 3, 'overvoltage', 'Overvoltage', 'Overvoltage condition detected', 'Y', 'PWR_OVERVOLTAGE', 'MEDIUM', 'PRODUCTION', 'Supply issue or transformer tap', 'Add delay to filter transients')
ON CONFLICT DO NOTHING;

COMMENT ON TABLE device_alarm_events IS 'Stores device alarm state transitions (ON/OFF only, not polls)';
COMMENT ON TABLE device_diagnostics IS 'Stores device fault snapshots and diagnostic data';
COMMENT ON TABLE isa_alarm_definitions IS 'ISA-18.2 alarm definitions (rationalized operator alarms)';
COMMENT ON TABLE isa_alarm_events IS 'ISA alarm lifecycle events (ON/ACK/CLEAR)';
COMMENT ON TABLE isa_alarm_cause_map IS 'Maps device fault codes to human-readable causes and actions';
COMMENT ON TABLE isa_alarm_suppression_matrix IS 'Defines parent-child alarm suppression rules';
COMMENT ON TABLE device_alarm_map IS 'Maps device registers/bits to alarm names';
