# Alarm Manager - ISA-18.2 Compliant Alarm System

A production-ready alarm management system that bridges device alarms (Modbus/BACnet) with ISA-18.2 operator alarms, publishing to a Unified Namespace (UNS) via MQTT.

## Features

✅ **Device Alarm Collection**: Poll Modbus devices for alarm registers
✅ **Edge Detection**: Store only alarm state transitions, not every poll
✅ **ISA-18.2 Compliance**: Rationalized operator alarms with priority, delays, suppression
✅ **Cause Mapping**: Map device fault codes to human-readable causes and actions
✅ **Alarm Suppression**: Prevent alarm floods with parent-child suppression rules
✅ **UNS Integration**: Publish to Unified Namespace (MQTT) for plant-wide visibility
✅ **PostgreSQL Storage**: Time-series optimized schema for alarm history
✅ **Configurable**: YAML or environment variable configuration

## Architecture

```
┌─────────────────┐
│  PM5110 Meter   │
│  Modbus TCP     │
└────────┬────────┘
         │ Poll (HR40112)
         ↓
┌─────────────────────────────┐
│  Modbus Poller              │
│  • Edge Detection           │
│  • Quality Tracking         │
└────────┬────────────────────┘
         │ Device Alarm Events
         ↓
┌─────────────────────────────┐
│  Alarm Mapping Engine       │
│  • ISA Rationalization      │
│  • Cause Mapping            │
│  • Suppression Logic        │
└────────┬────────────────────┘
         │ ISA Alarm Events
         ├──────────┬─────────┐
         ↓          ↓         ↓
┌────────────┐ ┌─────────┐ ┌─────────┐
│ PostgreSQL │ │  MQTT   │ │  SCADA  │
│  Historian │ │   UNS   │ │   HMI   │
└────────────┘ └─────────┘ └─────────┘
```

## Directory Structure

```
alarm_manager/
├── config/
│   ├── config.yaml              # Main configuration
│   └── .env.example             # Environment variables template
├── migrations/
│   └── 001_create_alarm_tables.sql  # Database schema
├── src/
│   ├── config.py                # Configuration management
│   ├── database.py              # Database operations
│   ├── modbus_poller.py         # Modbus polling with edge detection
│   ├── alarm_mapper.py          # ISA alarm mapping engine
│   ├── uns_publisher.py         # MQTT/UNS publisher
│   └── alarm_manager.py         # Main application
├── templates/
│   ├── isa_alarm_definition_template.csv
│   ├── isa_alarm_cause_map.csv
│   ├── isa_alarm_suppression_matrix.csv
│   └── device_alarm_map.csv
├── docs/
│   └── pm5110_alarm_mapping_guide.md
├── requirements.txt
├── docker-compose.yml
└── README.md
```

## Installation

### 1. Prerequisites

- Python 3.9+
- PostgreSQL 12+ (or TimescaleDB for time-series optimization)
- MQTT Broker (e.g., Mosquitto, EMQX)
- Access to Modbus TCP devices

### 2. Install Python Dependencies

```bash
cd alarm_manager
pip install -r requirements.txt
```

### 3. Setup Database

#### Create Database

```bash
psql -U postgres -c "CREATE DATABASE alarm_manager;"
```

#### Run Migrations

```bash
psql -U postgres -d alarm_manager -f migrations/001_create_alarm_tables.sql
```

#### Load Configuration from CSVs

```bash
# Import device alarm map
psql -U postgres -d alarm_manager -c "\COPY device_alarm_map FROM 'templates/device_alarm_map.csv' WITH (FORMAT csv, HEADER true);"

# Import ISA alarm definitions
psql -U postgres -d alarm_manager -c "\COPY isa_alarm_definitions FROM 'templates/isa_alarm_definition_template.csv' WITH (FORMAT csv, HEADER true);"

# Import cause map
psql -U postgres -d alarm_manager -c "\COPY isa_alarm_cause_map FROM 'templates/isa_alarm_cause_map.csv' WITH (FORMAT csv, HEADER true);"

# Import suppression matrix
psql -U postgres -d alarm_manager -c "\COPY isa_alarm_suppression_matrix FROM 'templates/isa_alarm_suppression_matrix.csv' WITH (FORMAT csv, HEADER true);"
```

### 4. Configure Application

**Option A: YAML Configuration (Recommended)**

```bash
cp config/config.yaml config/config.yaml.local
# Edit config/config.yaml.local with your settings
```

**Option B: Environment Variables**

```bash
cp config/.env.example .env
# Edit .env with your settings
```

### 5. Start MQTT Broker (if not already running)

```bash
# Using Docker
docker run -d -p 1883:1883 -p 9001:9001 eclipse-mosquitto

# Or install natively
sudo apt-get install mosquitto mosquitto-clients
sudo systemctl start mosquitto
```

## Usage

### Run the Alarm Manager

```bash
cd alarm_manager/src
python alarm_manager.py
```

### Run with Docker Compose

```bash
docker-compose up -d
```

### Monitor Logs

```bash
# If running natively
tail -f alarm_manager.log

# If using Docker
docker-compose logs -f alarm-manager
```

## Configuration Guide

### Adding a New Modbus Device

1. Add device configuration to `config/config.yaml`:

```yaml
modbus_devices:
  - device_id: PM5110_MTR02
    host: 192.168.1.101
    port: 502
    unit_id: 1
    poll_interval_ms: 1000
    timeout_ms: 3000
    alarm_register: 40112
    alarm_register_type: holding
```

2. Add device alarm map entries to `device_alarm_map.csv` (or database)

3. Restart alarm manager

### Creating a New ISA Alarm

1. Add entry to `isa_alarm_definition_template.csv`:

```csv
PWR_UNDERVOLT,Power Undervoltage,PM5110_MTR01,PM5110_MTR01.HR40112.bit5,DIGITAL,HR40112_bit5==1,...
```

2. Import to database or restart with CSV auto-import

3. Optionally add cause mapping in `isa_alarm_cause_map.csv`

### Adding Suppression Rules

1. Edit `isa_alarm_suppression_matrix.csv`:

```csv
SUP_0010,Y,PLANT_01,POWER,UNIT_D,PWR_PHASE_LOSS,Power Phase Loss,ALL_DOWNSTREAM_ALARMS,...
```

2. Import to database

## CSV Template Guide

### 1. device_alarm_map.csv

Maps device register bits to alarm names and determines ISA conversion.

**Key Columns:**
- `device_id`: Device identifier (e.g., PM5110_MTR01)
- `source_address`: Register address (e.g., HR40112)
- `bit_number`: Bit position (0-15)
- `alarm_id`: Internal alarm ID (e.g., phase_loss)
- `convert_to_isa`: Y/N/MAYBE - should this become ISA alarm?
- `isa_alarm_id`: Target ISA alarm ID (if converting)

### 2. isa_alarm_definition_template.csv

Defines operator ISA alarms with ISA-18.2 compliance fields.

**Key Columns:**
- `isa_alarm_id`: Unique alarm identifier
- `priority`: HIGH/MEDIUM/LOW
- `on_delay_s`: Delay before activating (anti-nuisance)
- `off_delay_s`: Delay before clearing
- `guidance_text`: Operator instructions
- `suppression_parent_alarm_id`: Parent for suppression

### 3. isa_alarm_cause_map.csv

Maps device fault codes to human-readable causes and actions.

**Key Columns:**
- `device_type`: VFD/METER/RELAY
- `code_value`: Fault code number (for fault codes)
- `alarm_bit`: Bit number (for alarm words)
- `cause_text`: Human-readable cause
- `recommended_action_steps`: Step-by-step guidance
- `operator_message_template`: Template for operator display

### 4. isa_alarm_suppression_matrix.csv

Defines parent-child alarm suppression rules.

**Key Columns:**
- `parent_alarm_id`: Alarm that triggers suppression
- `suppressed_alarm_id`: Alarm to suppress
- `suppression_type`: STATE_BASED/TIME_BASED/MODE_BASED
- `activation_delay_s`: Wait before suppressing
- `release_delay_s`: Keep suppressed after parent clears

## MQTT/UNS Topics

### Device Alarms

```
UNS/{site}/devices/{device_id}/alarms/events
UNS/{site}/devices/{device_id}/alarms/state
UNS/{site}/devices/{device_id}/diagnostics
```

### ISA Alarms

```
UNS/{site}/scada/alarms/isa/events
UNS/{site}/scada/alarms/isa/state
```

### Payload Examples

**Device Alarm Event:**
```json
{
  "ts": "2026-02-02T14:30:15.231Z",
  "event": "ON",
  "alarm": {"id": "phase_loss"},
  "source": {"register": "HR40112.bit0"},
  "raw": "0x0001",
  "quality": "GOOD"
}
```

**ISA Alarm Event:**
```json
{
  "ts": "2026-02-02T14:30:15.350Z",
  "event": "ON",
  "alarm": {
    "id": "PWR_PHASE_LOSS",
    "priority": "HIGH",
    "message": "Power issue: Phase loss detected",
    "guidance": "Check MCC feeder. Verify phase sequence."
  },
  "cause": {
    "device": "PM5110_MTR01",
    "alarm": "phase_loss",
    "text": "Phase failure detected on L1"
  },
  "suppression": {
    "suppressed": false
  }
}
```

## Database Queries

### Get Active ISA Alarms

```sql
SELECT * FROM active_isa_alarms;
```

### Get Device Alarm History

```sql
SELECT * FROM device_alarm_events
WHERE device_id = 'PM5110_MTR01'
  AND ts_utc > NOW() - INTERVAL '24 hours'
ORDER BY ts_utc DESC;
```

### Get Alarm Performance KPIs

```sql
SELECT * FROM alarm_performance_kpi
WHERE day > NOW() - INTERVAL '7 days'
ORDER BY day DESC;
```

## Best Practices

### Device Alarms
- ✅ Store only transitions (ON/OFF), not every poll
- ✅ Always include raw register value for debugging
- ✅ Track quality (GOOD/BAD/UNCERTAIN)
- ❌ Don't convert all device bits to ISA alarms

### ISA Alarms
- ✅ Add delays (on_delay_s) to prevent nuisance alarms
- ✅ Use suppression to prevent alarm floods
- ✅ Provide clear operator guidance
- ✅ Map device causes to meaningful messages
- ❌ Don't create ISA alarms for maintenance diagnostics

### Suppression
- ✅ Network down suppresses device comm loss
- ✅ Trip suppresses consequence alarms (flow low, pressure low)
- ✅ HH suppresses H (higher severity wins)
- ❌ Don't suppress safety alarms blindly

## Troubleshooting

### Modbus Connection Failed

```
Check:
- Device IP address and port
- Network connectivity (ping device)
- Firewall rules
- Modbus unit ID
```

### No Alarms Appearing in UNS

```
Check:
- MQTT broker connection (mosquitto_sub -t 'UNS/#' -v)
- Configuration: uns.broker_host, uns.site_id
- Database: verify device_alarm_map has convert_to_isa='Y'
```

### Database Connection Error

```
Check:
- PostgreSQL is running (sudo systemctl status postgresql)
- Database exists (psql -l)
- User credentials in config
- Connection string format
```

### Alarm Flood

```
Solutions:
- Add on_delay_s to alarm definitions
- Enable suppression rules
- Check for chattering sensors (add deadband)
- Aggregate per-device alarms to segment-level
```

## Performance Tuning

### For High-Volume Systems (100+ devices)

1. Use TimescaleDB instead of plain PostgreSQL
2. Adjust poll intervals (1-5s typical)
3. Use separate threads per device
4. Batch database inserts
5. Use MQTT QoS 0 for high-frequency telemetry

### Database Indexing

All critical indexes are created in the migration script. For additional optimization:

```sql
CREATE INDEX idx_device_alarm_ts_brin 
  ON device_alarm_events USING BRIN(ts_utc);
```

## Contributing

See implementation guide in `docs/pm5110_alarm_mapping_guide.md`

## License

MIT License - See LICENSE file

## Support

For issues, questions, or contributions, contact the SCADA engineering team.

---

**Version:** 1.0  
**Last Updated:** 2026-02-02  
**Maintained By:** SCADA Engineering Team
