-- =============================================================================
-- ISO 27001 Security Manager — Database Schema
-- PostgreSQL 15  |  TimescaleDB-ready (hypertable commands commented)
-- =============================================================================
-- Tables (14):  assets, threats, vulnerabilities, vulnerability_sla,
--               risks, security_controls, control_assessments,
--               security_events, correlation_rules, incidents,
--               incident_timeline, incident_events,
--               audit_findings, nonconformances
-- Views  (5):   active_incidents, vulnerability_sla_status,
--               risk_register_summary, control_gap_report, security_dashboard
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. ASSETS  — information-asset inventory (ISO 27001 clause 8.1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS assets (
    asset_id        TEXT PRIMARY KEY,
    asset_name      TEXT        NOT NULL,
    asset_type      TEXT        NOT NULL
                    CHECK (asset_type IN (
                        'SERVER','DATABASE','APPLICATION','NETWORK',
                        'ENDPOINT','CLOUD','PHYSICAL','DATA','API'
                    )),
    classification  TEXT        NOT NULL DEFAULT 'INTERNAL'
                    CHECK (classification IN ('PUBLIC','INTERNAL','CONFIDENTIAL','TOP_SECRET')),
    owner           TEXT,
    department      TEXT,
    location        TEXT,                          -- rack / datacenter / cloud-region
    ip_address      INET,
    criticality     TEXT        NOT NULL DEFAULT 'MEDIUM'
                    CHECK (criticality IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    active          BOOLEAN     DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_assets_type       ON assets (asset_type);
CREATE INDEX IF NOT EXISTS idx_assets_active     ON assets (active, criticality);

-- ---------------------------------------------------------------------------
-- 2. THREATS  — threat catalog / register
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS threats (
    threat_id           TEXT PRIMARY KEY,
    threat_name         TEXT        NOT NULL,
    threat_category     TEXT        NOT NULL
                        CHECK (threat_category IN (
                            'UNAUTHORIZED_ACCESS','MALWARE','PHISHING',
                            'INSIDER','PHYSICAL','AVAILABILITY',
                            'DATA_LEAK','SUPPLY_CHAIN','SOCIAL_ENGINEERING','OTHER'
                        )),
    description         TEXT,
    likelihood_default  INTEGER     CHECK (likelihood_default BETWEEN 1 AND 5) DEFAULT 3,
    impact_default      INTEGER     CHECK (impact_default BETWEEN 1 AND 5) DEFAULT 3,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- 3. VULNERABILITY SLA  — reference: max remediation days per severity
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vulnerability_sla (
    severity    TEXT    PRIMARY KEY CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    sla_days    INTEGER NOT NULL,
    description TEXT
);

-- ---------------------------------------------------------------------------
-- 4. VULNERABILITIES  — per-asset vulnerability lifecycle (clause 8.2)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vulnerabilities (
    vuln_id             SERIAL  PRIMARY KEY,
    asset_id            TEXT    REFERENCES assets(asset_id),
    cve_id              TEXT,                          -- NULL if non-CVE
    title               TEXT    NOT NULL,
    description         TEXT,
    severity            TEXT    NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    cvss_score          NUMERIC(4,1),
    source              TEXT,                          -- scanner name or 'manual'
    discovered_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sla_deadline        TIMESTAMPTZ,                   -- computed on insert from vulnerability_sla
    status              TEXT    NOT NULL DEFAULT 'OPEN'
                        CHECK (status IN ('OPEN','IN_PROGRESS','REMEDIATED','VERIFIED','FALSE_POSITIVE')),
    remediated_at       TIMESTAMPTZ,
    verified_at         TIMESTAMPTZ,
    remediation_notes   TEXT,
    assigned_to         TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vulns_asset    ON vulnerabilities (asset_id, status);
CREATE INDEX IF NOT EXISTS idx_vulns_status   ON vulnerabilities (status, severity);
CREATE INDEX IF NOT EXISTS idx_vulns_sla      ON vulnerabilities (sla_deadline) WHERE status IN ('OPEN','IN_PROGRESS');

-- ---------------------------------------------------------------------------
-- 5. RISKS  — risk register (ISO 27001 clause 6.1.2)
--            risk_score = likelihood × impact  (1-25)
--            risk_level derived from score
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS risks (
    risk_id                 TEXT        PRIMARY KEY,
    asset_id                TEXT        REFERENCES assets(asset_id),
    threat_id               TEXT        REFERENCES threats(threat_id),
    vuln_id                 INTEGER     REFERENCES vulnerabilities(vuln_id),
    description             TEXT        NOT NULL,
    likelihood              INTEGER     NOT NULL CHECK (likelihood BETWEEN 1 AND 5),
    impact                  INTEGER     NOT NULL CHECK (impact BETWEEN 1 AND 5),
    risk_score              INTEGER     GENERATED ALWAYS AS (likelihood * impact) STORED,
    risk_level              TEXT        GENERATED ALWAYS AS (
                                CASE
                                    WHEN likelihood * impact <= 4  THEN 'LOW'
                                    WHEN likelihood * impact <= 9  THEN 'MEDIUM'
                                    WHEN likelihood * impact <= 16 THEN 'HIGH'
                                    ELSE 'CRITICAL'
                                END
                            ) STORED,
    treatment_plan          TEXT        CHECK (treatment_plan IN ('AVOID','MITIGATE','TRANSFER','ACCEPT')),
    residual_likelihood     INTEGER     CHECK (residual_likelihood BETWEEN 1 AND 5),
    residual_impact         INTEGER     CHECK (residual_impact BETWEEN 1 AND 5),
    residual_risk_score     INTEGER     GENERATED ALWAYS AS (
                                COALESCE(residual_likelihood, likelihood) *
                                COALESCE(residual_impact, impact)
                            ) STORED,
    status                  TEXT        NOT NULL DEFAULT 'OPEN'
                            CHECK (status IN ('OPEN','UNDER_TREATMENT','TREATED','REVIEW')),
    owner                   TEXT,
    review_date             DATE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_risks_asset   ON risks (asset_id, status);
CREATE INDEX IF NOT EXISTS idx_risks_level   ON risks (risk_level, status);

-- ---------------------------------------------------------------------------
-- 6. SECURITY CONTROLS  — Annex A control register
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_controls (
    control_id      TEXT        PRIMARY KEY,
    annex_a_ref     TEXT        NOT NULL,              -- e.g. 'A.5.1', 'A.6.1.1'
    control_name    TEXT        NOT NULL,
    domain          TEXT        NOT NULL,              -- e.g. 'Information security policies'
    description     TEXT,
    control_type    TEXT        CHECK (control_type IN ('PREVENTIVE','DETECTIVE','CORRECTIVE','DIRECTIVE')),
    status          TEXT        NOT NULL DEFAULT 'PLANNED'
                    CHECK (status IN ('PLANNED','IMPLEMENTED','MONITORING','INEFFECTIVE','DECOMMISSIONED')),
    effectiveness   NUMERIC(5,2),                     -- 0.00 – 100.00
    last_assessed   TIMESTAMPTZ,
    next_assessment TIMESTAMPTZ,
    owner           TEXT,
    evidence_link   TEXT,                              -- URL / path to evidence artefact
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_controls_status ON security_controls (status);
CREATE INDEX IF NOT EXISTS idx_controls_annex  ON security_controls (annex_a_ref);

-- ---------------------------------------------------------------------------
-- 7. CONTROL ASSESSMENTS  — periodic effectiveness snapshots
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS control_assessments (
    assessment_id   SERIAL      PRIMARY KEY,
    control_id      TEXT        NOT NULL REFERENCES security_controls(control_id),
    assessed_at     TIMESTAMPTZ NOT NULL,
    assessor        TEXT,
    effectiveness   NUMERIC(5,2),
    status_at_time  TEXT,
    findings        TEXT,                              -- free-text notes
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_assessments_control ON control_assessments (control_id, assessed_at DESC);

-- ---------------------------------------------------------------------------
-- 8. CORRELATION RULES  — event-to-incident mapping rules
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS correlation_rules (
    rule_id                 TEXT        PRIMARY KEY,
    rule_name               TEXT        NOT NULL,
    description             TEXT,
    event_types             TEXT[]      NOT NULL,      -- array: {'FAILED_LOGIN','FAILED_LOGIN'}
    min_occurrences         INTEGER     NOT NULL DEFAULT 1,
    time_window_seconds     INTEGER     NOT NULL,
    group_by                TEXT        NOT NULL DEFAULT 'SOURCE_IP'
                            CHECK (group_by IN ('SOURCE_IP','ASSET','USER','NONE')),
    severity_filter         TEXT,                      -- only count events at or above this level
    incident_severity       TEXT        NOT NULL CHECK (incident_severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    incident_category       TEXT        NOT NULL,      -- free-form classification label
    cooldown_seconds        INTEGER     NOT NULL DEFAULT 3600, -- don't re-fire within this window
    enabled                 BOOLEAN     DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- 9. INCIDENTS  — security-incident lifecycle (clause 7.4 / Annex A.8.2)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incidents (
    incident_id         SERIAL      PRIMARY KEY,
    ts_detected         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ts_occurred         TIMESTAMPTZ,                   -- estimated actual occurrence (from first correlated event)
    title               TEXT        NOT NULL,
    description         TEXT,
    severity            TEXT        NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    classification      TEXT,                          -- e.g. 'Brute Force', 'Port Scan'
    status              TEXT        NOT NULL DEFAULT 'REPORTED'
                        CHECK (status IN ('REPORTED','INVESTIGATING','CONTAINED','RESOLVED','CLOSED')),
    correlation_rule_id TEXT        REFERENCES correlation_rules(rule_id),
    assigned_to         TEXT,
    affected_assets     TEXT[],                        -- array of asset_ids
    containment_notes   TEXT,
    resolution_notes    TEXT,
    lessons_learned     TEXT,
    ts_investigating    TIMESTAMPTZ,
    ts_contained        TIMESTAMPTZ,
    ts_resolved         TIMESTAMPTZ,
    ts_closed           TIMESTAMPTZ,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_incidents_status  ON incidents (status, severity);
CREATE INDEX IF NOT EXISTS idx_incidents_detect  ON incidents (ts_detected);

-- ---------------------------------------------------------------------------
-- 10. INCIDENT TIMELINE  — ordered action log per incident
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident_timeline (
    timeline_id     SERIAL      PRIMARY KEY,
    incident_id     INTEGER     NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    ts_utc          TIMESTAMPTZ NOT NULL,
    action          TEXT        NOT NULL,              -- e.g. 'DETECTED','ASSIGNED','CONTAINED'
    actor           TEXT,
    notes           TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_timeline_incident ON incident_timeline (incident_id, ts_utc);

-- ---------------------------------------------------------------------------
-- 11. SECURITY EVENTS  — raw event time-series (the high-volume table)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_events (
    event_id            BIGSERIAL   PRIMARY KEY,
    ts_utc              TIMESTAMPTZ NOT NULL,
    source_id           TEXT        NOT NULL,          -- collector / log-source name
    source_host         TEXT,
    event_type          TEXT        NOT NULL,          -- e.g. 'FAILED_LOGIN', 'PORT_SCAN', 'FILE_ACCESS'
    event_category      TEXT,                          -- maps to threats.threat_category
    severity            TEXT        CHECK (severity IN ('INFO','LOW','MEDIUM','HIGH','CRITICAL')),
    asset_id            TEXT        REFERENCES assets(asset_id),
    user_identity       TEXT,
    source_ip           INET,
    dest_ip             INET,
    details             JSONB,                         -- flexible payload
    raw_message         TEXT,
    incident_id         INTEGER     REFERENCES incidents(incident_id),
    quality             TEXT        CHECK (quality IN ('GOOD','BAD','UNCERTAIN')) DEFAULT 'GOOD',
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_events_ts         ON security_events (ts_utc DESC);
CREATE INDEX IF NOT EXISTS idx_events_type       ON security_events (event_type, ts_utc DESC);
CREATE INDEX IF NOT EXISTS idx_events_asset      ON security_events (asset_id, ts_utc DESC);
CREATE INDEX IF NOT EXISTS idx_events_srcip      ON security_events (source_ip, ts_utc DESC);
CREATE INDEX IF NOT EXISTS idx_events_incident   ON security_events (incident_id) WHERE incident_id IS NOT NULL;

-- TimescaleDB hypertable (uncomment after CREATE EXTENSION timescaledb):
-- SELECT create_hypertable('security_events', 'ts_utc', migrate_data => true);

-- ---------------------------------------------------------------------------
-- 12. AUDIT FINDINGS  — findings from internal / external audits
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_findings (
    finding_id          SERIAL      PRIMARY KEY,
    audit_ref           TEXT        NOT NULL,
    asset_id            TEXT        REFERENCES assets(asset_id),
    control_id          TEXT        REFERENCES security_controls(control_id),
    finding_type        TEXT        CHECK (finding_type IN ('OBSERVATION','RECOMMENDATION','NON_CONFORMANCE')),
    severity            TEXT        CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    description         TEXT        NOT NULL,
    status              TEXT        NOT NULL DEFAULT 'OPEN'
                        CHECK (status IN ('OPEN','IN_PROGRESS','CLOSED','DISPUTED')),
    owner               TEXT,
    corrective_action   TEXT,
    target_date         DATE,
    closed_at           TIMESTAMPTZ,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_findings_status ON audit_findings (status);

-- ---------------------------------------------------------------------------
-- 13. NONCONFORMANCES  — ISO 27001 clause 10.2
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS nonconformances (
    nc_id               SERIAL      PRIMARY KEY,
    asset_id            TEXT        REFERENCES assets(asset_id),
    control_id          TEXT        REFERENCES security_controls(control_id),
    incident_id         INTEGER     REFERENCES incidents(incident_id),
    finding_id          INTEGER     REFERENCES audit_findings(finding_id),
    description         TEXT        NOT NULL,
    severity            TEXT        CHECK (severity IN ('MINOR','MAJOR','CRITICAL')),
    root_cause          TEXT,
    corrective_action   TEXT,
    preventive_action   TEXT,
    owner               TEXT,
    status              TEXT        NOT NULL DEFAULT 'OPEN'
                        CHECK (status IN ('OPEN','IN_PROGRESS','CLOSED','VERIFIED')),
    target_date         DATE,
    closed_at           TIMESTAMPTZ,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- VIEWS
-- ---------------------------------------------------------------------------

-- V1: currently open incidents with age and MTTD
CREATE OR REPLACE VIEW active_incidents AS
SELECT
    i.incident_id,
    i.title,
    i.severity,
    i.classification,
    i.status,
    i.ts_detected,
    i.ts_occurred,
    i.affected_assets,
    i.assigned_to,
    EXTRACT(EPOCH FROM (NOW() - i.ts_detected)) / 3600.0        AS age_hours,
    CASE WHEN i.ts_occurred IS NOT NULL
        THEN EXTRACT(EPOCH FROM (i.ts_detected - i.ts_occurred)) / 3600.0
    END                                                           AS mttd_hours
FROM incidents i
WHERE i.status IN ('REPORTED','INVESTIGATING','CONTAINED')
ORDER BY i.severity DESC, i.ts_detected;

-- V2: open vulnerabilities with SLA countdown / breach flag
CREATE OR REPLACE VIEW vulnerability_sla_status AS
SELECT
    v.vuln_id,
    v.asset_id,
    a.asset_name,
    v.cve_id,
    v.title,
    v.severity,
    v.cvss_score,
    v.status,
    v.discovered_at,
    v.sla_deadline,
    v.assigned_to,
    s.sla_days,
    EXTRACT(EPOCH FROM (v.sla_deadline - NOW())) / 86400.0        AS sla_days_remaining,
    CASE WHEN NOW() > v.sla_deadline THEN TRUE ELSE FALSE END     AS sla_breached
FROM vulnerabilities v
JOIN assets          a ON a.asset_id = v.asset_id
LEFT JOIN vulnerability_sla s ON s.severity = v.severity
WHERE v.status IN ('OPEN','IN_PROGRESS')
ORDER BY v.sla_breached DESC, v.sla_days_remaining ASC;

-- V3: risk register summary — current residual risk landscape
CREATE OR REPLACE VIEW risk_register_summary AS
SELECT
    r.risk_id,
    r.asset_id,
    a.asset_name,
    r.threat_id,
    t.threat_name,
    r.description,
    r.likelihood,
    r.impact,
    r.risk_score,
    r.risk_level,
    r.treatment_plan,
    r.residual_risk_score,
    CASE
        WHEN r.residual_risk_score <= 4  THEN 'LOW'
        WHEN r.residual_risk_score <= 9  THEN 'MEDIUM'
        WHEN r.residual_risk_score <= 16 THEN 'HIGH'
        ELSE 'CRITICAL'
    END                                                           AS residual_risk_level,
    r.status,
    r.owner
FROM risks    r
JOIN assets   a ON a.asset_id   = r.asset_id
JOIN threats  t ON t.threat_id  = r.threat_id
WHERE r.status IN ('OPEN','UNDER_TREATMENT','REVIEW')
ORDER BY r.residual_risk_score DESC;

-- V4: controls that are planned / ineffective (gap report)
CREATE OR REPLACE VIEW control_gap_report AS
SELECT
    control_id,
    annex_a_ref,
    control_name,
    domain,
    control_type,
    status,
    effectiveness,
    owner,
    CASE
        WHEN status = 'PLANNED'      THEN 'NOT IMPLEMENTED'
        WHEN status = 'INEFFECTIVE'  THEN 'INEFFECTIVE'
        WHEN effectiveness < 70      THEN 'LOW EFFECTIVENESS'
        ELSE                              'REVIEW NEEDED'
    END                             AS gap_reason
FROM security_controls
WHERE status IN ('PLANNED','INEFFECTIVE')
   OR (status = 'MONITORING' AND effectiveness < 70)
ORDER BY gap_reason, annex_a_ref;

-- V5: security dashboard — latest snapshot of all key metrics
CREATE OR REPLACE VIEW security_dashboard AS
SELECT
    -- Incidents
    (SELECT COUNT(*) FROM incidents WHERE status IN ('REPORTED','INVESTIGATING'))::int  AS open_incidents,
    (SELECT COUNT(*) FROM incidents WHERE status = 'REPORTED' AND severity IN ('HIGH','CRITICAL'))::int AS critical_open_incidents,
    -- Vulnerabilities
    (SELECT COUNT(*) FROM vulnerabilities WHERE status IN ('OPEN','IN_PROGRESS'))::int   AS open_vulnerabilities,
    (SELECT COUNT(*) FROM vulnerabilities WHERE status IN ('OPEN','IN_PROGRESS') AND severity = 'CRITICAL')::int AS critical_open_vulns,
    (SELECT COUNT(*) FROM vulnerabilities v WHERE status IN ('OPEN','IN_PROGRESS') AND NOW() > v.sla_deadline)::int AS sla_breached_vulns,
    -- Risks
    (SELECT COUNT(*) FROM risks WHERE status IN ('OPEN','UNDER_TREATMENT') AND risk_level IN ('HIGH','CRITICAL'))::int AS high_critical_risks,
    -- Controls
    (SELECT COUNT(*) FROM security_controls WHERE status IN ('IMPLEMENTED','MONITORING'))::int AS implemented_controls,
    (SELECT COUNT(*) FROM security_controls WHERE status != 'DECOMMISSIONED')::int               AS total_controls,
    -- Recent events (last 24 h)
    (SELECT COUNT(*) FROM security_events WHERE ts_utc >= NOW() - INTERVAL '24 hours')::bigint AS events_24h,
    NOW()::TIMESTAMPTZ AS snapshot_at;
