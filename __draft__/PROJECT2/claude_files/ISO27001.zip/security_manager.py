# ---------------------------------------------------------------------------
# ISO 27001 Security Manager — Main orchestrator
# ---------------------------------------------------------------------------
# Entry-point.  Boots all subsystems, runs the main event-processing loop,
# and schedules periodic tasks (SLA scan, risk recalc, control assessment,
# KPI flush).
#
# Loop topology (mirrors energy_manager.py):
#
#   EventCollector                  ← syslog / file / API (background threads)
#       ↓  queue
#   Main loop:
#       1. Drain event queue  → store batch  → publish live
#       2. Feed each event    → CorrelationEngine.evaluate()
#              ↓ if incident fires
#       3. IncidentManager.create_incident()  → publish incident event
#              → link correlated events
#       4. [periodic] VulnerabilityTracker.scan_sla_breaches()
#       5. [periodic] RiskEngine.recalculate_from_incidents()
#       6. [periodic] ControlMonitor.assess_all()
#       7. [periodic] KPICalculator.compute_all()  → publish retained KPIs
#       8. [periodic] Publish retained state snapshots
#
# Periodic tasks use a simple "next_run epoch" pattern (no asyncio needed).
# ---------------------------------------------------------------------------
from __future__ import annotations
import os, sys, signal, time, logging
from datetime import datetime, timezone
from typing import Dict, List

# ── stdlib path fix so `import config` works inside /app/src ─────────────
sys.path.insert(0, os.path.dirname(__file__))

from config import (
    SecurityManagerConfig, load_config_from_yaml, load_config_from_env
)
from database            import SecurityDatabase
from uns_publisher       import UNSPublisher
from event_collector     import EventCollectorManager
from incident_detector   import CorrelationEngine, IncidentManager
from vulnerability_tracker import VulnerabilityTracker
from risk_engine         import RiskEngine
from control_monitor     import ControlMonitor
from kpi_calculator      import SecurityKPICalculator

# ── logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(name)-40s %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger("security_manager")


# =============================================================================
# SecurityManager — top-level orchestrator
# =============================================================================
class SecurityManager:
    def __init__(self, cfg: SecurityManagerConfig):
        self.cfg = cfg
        self.running = False

        # ── database ───────────────────────────────────────────────────
        logger.info("Connecting to database …")
        self.db = SecurityDatabase(cfg.database.connection_string())

        # ── MQTT / UNS ─────────────────────────────────────────────────
        if cfg.features.enable_uns_publishing:
            logger.info("Connecting to MQTT broker …")
            self.uns: UNSPublisher | None = UNSPublisher(
                cfg.uns.host, cfg.uns.port, cfg.uns.site
            )
        else:
            self.uns = None

        # ── event collector ────────────────────────────────────────────
        self.collector = EventCollectorManager(cfg.event_sources)

        # ── subsystems ─────────────────────────────────────────────────
        self.vuln_tracker  = VulnerabilityTracker(self.db)
        self.risk_engine   = RiskEngine(self.db)
        self.control_mon   = ControlMonitor(self.db)
        self.kpi_calc      = SecurityKPICalculator(self.db)

        # Correlation engine — rules loaded from DB after schema is ready
        self.correlation_engine: CorrelationEngine | None = None
        self.incident_mgr = IncidentManager(self.db)

        # ── periodic task next-run epochs ──────────────────────────────
        now = time.time()
        self._next_sla_check      = now + cfg.intervals.sla_check
        self._next_risk_recalc    = now + cfg.intervals.risk_recalculation
        self._next_control_assess = now + cfg.intervals.control_assessment
        self._next_kpi_flush      = now + cfg.intervals.kpi_computation
        self._next_state_pub      = now + 60   # retained state every 60 s

    # ── lifecycle ────────────────────────────────────────────────────────
    def start(self):
        logger.info("Loading reference data …")
        self.vuln_tracker.load_sla_config(self.cfg.vulnerability_sla)

        # Load correlation rules from DB (populated via import_csv.py)
        rules = self.db.load_correlation_rules()
        self.correlation_engine = CorrelationEngine(
            rules,
            buffer_window_seconds=self.cfg.correlation.buffer_window_seconds
        )
        logger.info("Loaded %d correlation rules", len(rules))

        logger.info("Starting event collectors …")
        self.collector.start()

        self.running = True
        logger.info("Security Manager is RUNNING")

    def stop(self):
        logger.info("Stopping …")
        self.running = False
        self.collector.stop()
        if self.uns:
            self.uns.close()
        self.db.close()
        logger.info("Security Manager STOPPED")

    # ── main loop ────────────────────────────────────────────────────────
    def run_loop(self):
        """Blocking main loop.  Call start() first."""
        while self.running:
            # ── 1. Drain event queue (non-blocking batch) ──────────────
            events = self._drain_queue()
            if events:
                self._process_events(events)

            # ── 2. Periodic tasks ───────────────────────────────────────
            now = time.time()

            if now >= self._next_sla_check and self.cfg.features.enable_sla_monitoring:
                self._run_sla_check()
                self._next_sla_check = now + self.cfg.intervals.sla_check

            if now >= self._next_risk_recalc:
                self._run_risk_recalc()
                self._next_risk_recalc = now + self.cfg.intervals.risk_recalculation

            if now >= self._next_control_assess:
                self._run_control_assess()
                self._next_control_assess = now + self.cfg.intervals.control_assessment

            if now >= self._next_kpi_flush and self.cfg.features.enable_kpi_calculation:
                self._run_kpi_flush()
                self._next_kpi_flush = now + self.cfg.intervals.kpi_computation

            if now >= self._next_state_pub and self.uns:
                self._publish_state_snapshots()
                self._next_state_pub = now + 60

            time.sleep(0.5)   # yield CPU; events arrive via background threads

    # ── event processing ─────────────────────────────────────────────────
    def _drain_queue(self) -> List[dict]:
        """Pull up to 500 events without blocking."""
        batch = []
        q = self.collector.queue
        while not q.empty() and len(batch) < 500:
            batch.append(q.get_nowait())
        return batch

    def _process_events(self, events: List[dict]):
        # a) Persist
        self.db.store_events_batch(events)

        # b) Publish live
        if self.uns:
            self.uns.publish_events_batch(events)

        # c) Feed correlation engine
        if self.correlation_engine and self.cfg.features.enable_incident_detection:
            for ev in events:
                incident_spec = self.correlation_engine.evaluate(ev)
                if incident_spec:
                    self._handle_new_incident(incident_spec)

    def _handle_new_incident(self, spec: dict):
        incident_id = self.incident_mgr.create_incident(spec)

        # Link correlated events (best-effort; events may not have IDs yet)
        # For simplicity we link by updating the most recent N events
        # matching the event_types in the correlation rule.

        if self.uns:
            pub_spec = {k: v for k, v in spec.items() if not k.startswith("_")}
            pub_spec["incident_id"] = incident_id
            self.uns.publish_incident_event(pub_spec, "REPORTED")

    # ── periodic tasks ───────────────────────────────────────────────────
    def _run_sla_check(self):
        breached = self.vuln_tracker.scan_sla_breaches()
        if breached and self.uns:
            for v in breached:
                self.uns.publish_vulnerability_event(v, "SLA_BREACHED")

    def _run_risk_recalc(self):
        # Build threat→asset map from active incidents
        active = self.incident_mgr.get_active_incidents()
        threat_asset_map: Dict[str, list] = {}
        for inc in active:
            cat    = inc.get("classification", "OTHER")
            assets = inc.get("affected_assets") or []
            threat_asset_map.setdefault(cat, []).extend(assets)

        self.risk_engine.recalculate_from_incidents(active, threat_asset_map)

        # Reload rules (in case operator added new rules)
        rules = self.db.load_correlation_rules()
        if self.correlation_engine:
            self.correlation_engine.reload_rules(rules)

    def _run_control_assess(self):
        result = self.control_mon.assess_all()
        if self.uns:
            self.uns.publish_controls_state(result["controls"], result["gaps"])

    def _run_kpi_flush(self):
        kpis = self.kpi_calc.compute_all()
        if self.uns:
            self.uns.publish_kpis(kpis)

    def _publish_state_snapshots(self):
        """Retained topics: incidents, vulnerabilities, risks."""
        if not self.uns:
            return
        self.uns.publish_incidents_state(self.incident_mgr.get_active_incidents())
        self.uns.publish_vulnerabilities_state(self.vuln_tracker.get_open_vulnerabilities())
        self.uns.publish_risks_state(self.risk_engine.get_risk_register())


# =============================================================================
# Entry point
# =============================================================================
def main():
    config_path = os.getenv("CONFIG_PATH", "/app/config/config.yaml")
    if not os.path.exists(config_path):
        # Fallback for local dev
        config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config.yaml")

    logger.info("Loading config from %s", config_path)
    cfg = load_config_from_env(load_config_from_yaml(config_path))

    manager = SecurityManager(cfg)

    # ── graceful shutdown signals ────────────────────────────────────
    def _sighandler(signum, frame):
        logger.info("Signal %d received — shutting down", signum)
        manager.stop()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _sighandler)
    signal.signal(signal.SIGINT,  _sighandler)

    manager.start()
    manager.run_loop()


if __name__ == "__main__":
    main()
