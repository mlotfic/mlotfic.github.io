"""
Statistical Process Control (SPC) Detection Module

Implements Western Electric and Nelson rules for detecting out-of-control conditions:

Western Electric Rules (1956):
1. One point beyond 3σ from center line
2. Nine consecutive points on same side of center line
3. Six consecutive points steadily increasing or decreasing
4. Fourteen consecutive points alternating up and down

Nelson Rules (1984) - additional:
5. Two out of three consecutive points beyond 2σ
6. Four out of five consecutive points beyond 1σ
7. Fifteen consecutive points within 1σ (over-control)
8. Eight consecutive points beyond 1σ on either side (stratification)

Creates nonconformances when rules are violated.
"""

import logging
import statistics
from collections import deque
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class ControlChart:
    """
    Statistical process control chart with control limits.
    
    Supports:
    - X-bar chart (subgroup averages)
    - R chart (subgroup ranges)
    - I-MR chart (individuals and moving range)
    """
    
    def __init__(
        self,
        cqc_id: str,
        chart_type: str = 'individuals',  # individuals, xbar, range
        center_line: Optional[float] = None,
        ucl: Optional[float] = None,
        lcl: Optional[float] = None,
        samples: Optional[List[float]] = None
    ):
        self.cqc_id = cqc_id
        self.chart_type = chart_type
        self.center_line = center_line
        self.ucl = ucl
        self.lcl = lcl
        
        # Calculate limits if not provided
        if samples and (center_line is None or ucl is None or lcl is None):
            self._calculate_limits(samples)
    
    def _calculate_limits(self, samples: List[float]):
        """
        Calculate 3-sigma control limits from data.
        
        For individuals chart (I-MR):
        - Center line = mean
        - UCL = mean + 3 * (moving range / 1.128)
        - LCL = mean - 3 * (moving range / 1.128)
        """
        if len(samples) < 20:
            logger.warning(f"Only {len(samples)} samples for {self.cqc_id}, need >=20 for reliable limits")
        
        self.center_line = statistics.mean(samples)
        
        if self.chart_type == 'individuals':
            # Calculate average moving range
            moving_ranges = [abs(samples[i+1] - samples[i]) for i in range(len(samples)-1)]
            avg_moving_range = statistics.mean(moving_ranges)
            
            # 3-sigma limits using d2 constant (1.128 for moving range of 2)
            sigma_estimate = avg_moving_range / 1.128
            self.ucl = self.center_line + (3 * sigma_estimate)
            self.lcl = self.center_line - (3 * sigma_estimate)
        
        elif self.chart_type == 'xbar':
            # X-bar chart: need subgroup data (simplified for now)
            stdev = statistics.stdev(samples)
            # Assuming subgroup size n=5, A2=0.577
            A2 = 0.577
            self.ucl = self.center_line + (A2 * stdev)
            self.lcl = self.center_line - (A2 * stdev)
        
        logger.info(f"Calculated limits for {self.cqc_id}: CL={self.center_line:.3f}, UCL={self.ucl:.3f}, LCL={self.lcl:.3f}")
    
    def get_sigma_zone(self, value: float) -> int:
        """
        Determine which sigma zone a value falls in.
        
        Returns:
        - 0: Within 1σ
        - 1: Between 1σ and 2σ
        - 2: Between 2σ and 3σ
        - 3: Beyond 3σ
        """
        if self.ucl is None or self.lcl is None:
            return 0
        
        # Calculate sigma distance
        sigma = (self.ucl - self.center_line) / 3
        distance_from_center = abs(value - self.center_line)
        
        if distance_from_center > 3 * sigma:
            return 3
        elif distance_from_center > 2 * sigma:
            return 2
        elif distance_from_center > 1 * sigma:
            return 1
        else:
            return 0


class SPCDetector:
    """
    Detect out-of-control conditions using Western Electric and Nelson rules.
    
    Maintains rolling buffer of recent measurements per CQC.
    Evaluates all rules on each new measurement.
    Creates nonconformance when rule is violated.
    """
    
    def __init__(self, db, buffer_size: int = 100):
        self.db = db
        self.buffer_size = buffer_size
        self.buffers: Dict[str, deque] = {}  # cqc_id -> deque of (timestamp, value)
        self.control_charts: Dict[str, ControlChart] = {}
        self.last_violation_time: Dict[Tuple[str, int], float] = {}  # (cqc_id, rule_num) -> epoch
        self.cooldown_seconds = 3600  # Don't fire same rule for same CQC within 1 hour
    
    def evaluate(self, measurement: Dict) -> Optional[Dict]:
        """
        Evaluate SPC rules on a new measurement.
        
        Returns:
        - None if no violation
        - Dict with NC details if violation detected
        """
        cqc_id = measurement['cqc_id']
        value = measurement['measured_value']
        ts = measurement['ts_utc']
        
        # Initialize buffer if needed
        if cqc_id not in self.buffers:
            self.buffers[cqc_id] = deque(maxlen=self.buffer_size)
            self._load_control_chart(cqc_id)
        
        # Add to buffer
        self.buffers[cqc_id].append((ts, value))
        
        # Get control chart
        chart = self.control_charts.get(cqc_id)
        if not chart or chart.ucl is None:
            logger.debug(f"No control chart for {cqc_id}, skipping SPC evaluation")
            return None
        
        # Evaluate all rules
        buffer_values = [v for _, v in self.buffers[cqc_id]]
        
        violations = []
        
        # Rule 1: One point beyond 3σ
        if self._rule_1_beyond_3sigma(value, chart):
            violations.append((1, "One point beyond 3σ from center line"))
        
        # Rule 2: Nine consecutive on same side
        if len(buffer_values) >= 9:
            if self._rule_2_nine_same_side(buffer_values[-9:], chart):
                violations.append((2, "Nine consecutive points on same side of center line"))
        
        # Rule 3: Six consecutive trending
        if len(buffer_values) >= 6:
            if self._rule_3_six_trending(buffer_values[-6:]):
                violations.append((3, "Six consecutive points steadily increasing or decreasing"))
        
        # Rule 4: Fourteen consecutive alternating
        if len(buffer_values) >= 14:
            if self._rule_4_fourteen_alternating(buffer_values[-14:]):
                violations.append((4, "Fourteen consecutive points alternating up and down"))
        
        # Rule 5: Two of three beyond 2σ
        if len(buffer_values) >= 3:
            if self._rule_5_two_of_three_beyond_2sigma(buffer_values[-3:], chart):
                violations.append((5, "Two out of three consecutive points beyond 2σ"))
        
        # Rule 6: Four of five beyond 1σ
        if len(buffer_values) >= 5:
            if self._rule_6_four_of_five_beyond_1sigma(buffer_values[-5:], chart):
                violations.append((6, "Four out of five consecutive points beyond 1σ"))
        
        # Rule 7: Fifteen within 1σ (over-control)
        if len(buffer_values) >= 15:
            if self._rule_7_fifteen_within_1sigma(buffer_values[-15:], chart):
                violations.append((7, "Fifteen consecutive points within 1σ (over-control)"))
        
        # Rule 8: Eight beyond 1σ on either side
        if len(buffer_values) >= 8:
            if self._rule_8_eight_beyond_1sigma(buffer_values[-8:], chart):
                violations.append((8, "Eight consecutive points beyond 1σ on either side"))
        
        # Fire NC if violations detected (with cooldown)
        if violations:
            rule_num, rule_desc = violations[0]  # Take first violation
            
            # Check cooldown
            key = (cqc_id, rule_num)
            now = datetime.now(timezone.utc).timestamp()
            last_fire = self.last_violation_time.get(key, 0)
            
            if now - last_fire < self.cooldown_seconds:
                logger.debug(f"SPC rule {rule_num} for {cqc_id} in cooldown, suppressing")
                return None
            
            # Fire NC
            self.last_violation_time[key] = now
            
            nc_data = {
                'title': f"SPC Violation: {rule_desc}",
                'description': f"CQC {cqc_id} violated SPC Rule {rule_num}: {rule_desc}. Measured value: {value:.3f}",
                'severity': 'MAJOR' if rule_num <= 4 else 'MINOR',
                'nc_type': 'PROCESS_OUT_OF_CONTROL',
                'cqc_id': cqc_id,
                'measured_value': value,
                'ts_occurred': ts,
                'spc_rule': rule_num,
                'spc_rule_description': rule_desc
            }
            
            logger.warning(f"SPC violation detected: CQC {cqc_id}, Rule {rule_num}")
            return nc_data
        
        return None
    
    def _load_control_chart(self, cqc_id: str):
        """Load or calculate control chart for CQC"""
        # Try to load existing limits from database
        limits = self.db.get_control_limits(cqc_id)
        
        if limits:
            self.control_charts[cqc_id] = ControlChart(
                cqc_id=cqc_id,
                chart_type='individuals',
                center_line=limits['center_line'],
                ucl=limits['ucl'],
                lcl=limits['lcl']
            )
            logger.info(f"Loaded control chart for {cqc_id} from database")
        else:
            # Calculate from recent data
            recent_samples = self.db.get_recent_measurements(cqc_id, limit=100)
            if len(recent_samples) >= 20:
                self.control_charts[cqc_id] = ControlChart(
                    cqc_id=cqc_id,
                    chart_type='individuals',
                    samples=recent_samples
                )
                # Store limits
                chart = self.control_charts[cqc_id]
                self.db.store_control_limits(cqc_id, chart.center_line, chart.ucl, chart.lcl)
                logger.info(f"Calculated control chart for {cqc_id}")
            else:
                # Not enough data
                logger.warning(f"Insufficient data for {cqc_id} control chart ({len(recent_samples)} samples)")
                self.control_charts[cqc_id] = ControlChart(cqc_id=cqc_id, chart_type='individuals')
    
    def _rule_1_beyond_3sigma(self, value: float, chart: ControlChart) -> bool:
        """Rule 1: One point beyond 3σ"""
        return value > chart.ucl or value < chart.lcl
    
    def _rule_2_nine_same_side(self, values: List[float], chart: ControlChart) -> bool:
        """Rule 2: Nine consecutive points on same side of center line"""
        sides = [1 if v > chart.center_line else -1 for v in values]
        return all(s == sides[0] for s in sides)
    
    def _rule_3_six_trending(self, values: List[float]) -> bool:
        """Rule 3: Six consecutive points steadily increasing or decreasing"""
        increasing = all(values[i+1] > values[i] for i in range(len(values)-1))
        decreasing = all(values[i+1] < values[i] for i in range(len(values)-1))
        return increasing or decreasing
    
    def _rule_4_fourteen_alternating(self, values: List[float]) -> bool:
        """Rule 4: Fourteen consecutive points alternating up and down"""
        for i in range(len(values) - 2):
            expected_direction = 1 if i % 2 == 0 else -1
            actual_direction = 1 if values[i+1] > values[i] else -1
            if actual_direction != expected_direction:
                return False
        return True
    
    def _rule_5_two_of_three_beyond_2sigma(self, values: List[float], chart: ControlChart) -> bool:
        """Rule 5: Two of three consecutive points beyond 2σ"""
        sigma = (chart.ucl - chart.center_line) / 3
        sigma_2_upper = chart.center_line + (2 * sigma)
        sigma_2_lower = chart.center_line - (2 * sigma)
        
        count = sum(1 for v in values if v > sigma_2_upper or v < sigma_2_lower)
        return count >= 2
    
    def _rule_6_four_of_five_beyond_1sigma(self, values: List[float], chart: ControlChart) -> bool:
        """Rule 6: Four of five consecutive points beyond 1σ"""
        sigma = (chart.ucl - chart.center_line) / 3
        sigma_1_upper = chart.center_line + sigma
        sigma_1_lower = chart.center_line - sigma
        
        count = sum(1 for v in values if v > sigma_1_upper or v < sigma_1_lower)
        return count >= 4
    
    def _rule_7_fifteen_within_1sigma(self, values: List[float], chart: ControlChart) -> bool:
        """Rule 7: Fifteen consecutive points within 1σ (indicates over-control)"""
        sigma = (chart.ucl - chart.center_line) / 3
        sigma_1_upper = chart.center_line + sigma
        sigma_1_lower = chart.center_line - sigma
        
        return all(sigma_1_lower <= v <= sigma_1_upper for v in values)
    
    def _rule_8_eight_beyond_1sigma(self, values: List[float], chart: ControlChart) -> bool:
        """Rule 8: Eight consecutive points beyond 1σ on either side"""
        sigma = (chart.ucl - chart.center_line) / 3
        sigma_1_upper = chart.center_line + sigma
        sigma_1_lower = chart.center_line - sigma
        
        return all(v > sigma_1_upper or v < sigma_1_lower for v in values)
