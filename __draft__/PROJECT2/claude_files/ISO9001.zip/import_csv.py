#!/usr/bin/env python3
"""
CSV Import Script for ISO 9001 Quality Management System

Imports reference data from CSV templates:
- Products
- Processes
- CQCs (Critical Quality Characteristics)
- QMS Controls (ISO 9001:2015 clauses)
- SPC correlation rules (optional)

Usage:
    python import_csv.py [--clear]
    
    --clear: Truncate tables before import (use with caution)
"""

import argparse
import csv
import logging
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from config import load_config_from_yaml
from database import QualityDatabase

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def import_products(db: QualityDatabase, csv_path: Path):
    """Import products from CSV"""
    logger.info(f"Importing products from {csv_path}...")
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        products = list(reader)
    
    for product in products:
        db.store_product({
            'product_id': product['product_id'],
            'product_name': product['product_name'],
            'product_family': product.get('product_family'),
            'description': product.get('description'),
            'specifications': product.get('specifications'),
            'active': product.get('active', 'true').lower() == 'true'
        })
    
    logger.info(f"Imported {len(products)} products")


def import_processes(db: QualityDatabase, csv_path: Path):
    """Import processes from CSV"""
    logger.info(f"Importing processes from {csv_path}...")
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        processes = list(reader)
    
    for process in processes:
        db.store_process({
            'process_id': process['process_id'],
            'process_name': process['process_name'],
            'process_type': process.get('process_type'),
            'description': process.get('description'),
            'owner': process.get('owner'),
            'target_fpy': float(process['target_fpy']) if process.get('target_fpy') else None,
            'target_cycle_time': float(process['target_cycle_time']) if process.get('target_cycle_time') else None,
            'active': process.get('active', 'true').lower() == 'true'
        })
    
    logger.info(f"Imported {len(processes)} processes")


def import_cqcs(db: QualityDatabase, csv_path: Path):
    """Import Critical Quality Characteristics from CSV"""
    logger.info(f"Importing CQCs from {csv_path}...")
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        cqcs = list(reader)
    
    for cqc in cqcs:
        db.store_cqc({
            'cqc_id': cqc['cqc_id'],
            'cqc_name': cqc['cqc_name'],
            'product_id': cqc.get('product_id'),
            'process_id': cqc.get('process_id'),
            'measurement_type': cqc.get('measurement_type'),
            'measurement_unit': cqc.get('measurement_unit'),
            'target_value': float(cqc['target_value']) if cqc.get('target_value') else None,
            'upper_spec_limit': float(cqc['upper_spec_limit']) if cqc.get('upper_spec_limit') else None,
            'lower_spec_limit': float(cqc['lower_spec_limit']) if cqc.get('lower_spec_limit') else None,
            'criticality': cqc.get('criticality', 'MEDIUM'),
            'active': cqc.get('active', 'true').lower() == 'true'
        })
    
    logger.info(f"Imported {len(cqcs)} CQCs")


def import_qms_controls(db: QualityDatabase, csv_path: Path):
    """Import QMS controls from CSV"""
    logger.info(f"Importing QMS controls from {csv_path}...")
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        controls = list(reader)
    
    for control in controls:
        db.store_qms_control({
            'control_id': control['control_id'],
            'clause': control['clause'],
            'control_name': control['control_name'],
            'control_type': control.get('control_type'),
            'description': control.get('description'),
            'owner': control.get('owner'),
            'status': control.get('status', 'IMPLEMENTED'),
            'effectiveness': float(control['effectiveness']) if control.get('effectiveness') else None,
            'evidence_location': control.get('evidence_location')
        })
    
    logger.info(f"Imported {len(controls)} QMS controls")


def clear_tables(db: QualityDatabase):
    """Clear all reference tables (WARNING: destructive)"""
    logger.warning("Clearing reference tables...")
    
    tables = [
        'qms_controls',
        'cqcs',
        'processes',
        'products'
    ]
    
    for table in tables:
        db.execute_sql(f"TRUNCATE TABLE {table} CASCADE")
        logger.info(f"Cleared table: {table}")


def main():
    parser = argparse.ArgumentParser(description='Import CSV data into Quality Management System')
    parser.add_argument('--clear', action='store_true', help='Clear tables before import')
    parser.add_argument('--config', default='/app/config/config.yaml', help='Config file path')
    args = parser.parse_args()
    
    # Load config
    config = load_config_from_yaml(args.config)
    
    # Connect to database
    db = QualityDatabase(config.database)
    
    # Clear tables if requested
    if args.clear:
        confirm = input("WARNING: This will delete all reference data. Type 'yes' to continue: ")
        if confirm.lower() == 'yes':
            clear_tables(db)
        else:
            logger.info("Clear cancelled")
            return
    
    # Import CSVs
    templates_dir = Path('/app/templates')
    
    try:
        if (templates_dir / 'products.csv').exists():
            import_products(db, templates_dir / 'products.csv')
        
        if (templates_dir / 'processes.csv').exists():
            import_processes(db, templates_dir / 'processes.csv')
        
        if (templates_dir / 'cqcs.csv').exists():
            import_cqcs(db, templates_dir / 'cqcs.csv')
        
        if (templates_dir / 'qms_controls.csv').exists():
            import_qms_controls(db, templates_dir / 'qms_controls.csv')
        
        logger.info("CSV import completed successfully")
    
    except Exception as e:
        logger.error(f"Import failed: {e}", exc_info=True)
        sys.exit(1)
    
    finally:
        db.close()


if __name__ == '__main__':
    main()
