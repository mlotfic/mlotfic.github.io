"""
Process Capability Monitoring Module

Calculates process capability indices per CQC:
- Cp: Process potential (based on short-term variation)
- Cpk: Process performance (accounts for centering)
- Pp: Process performance (based on overall variation)
- Ppk: Process performance index (long-term)

Capability levels:
- CAPABLE: Cpk >= 1.33 (6-sigma process, 3.4 DPMO)
- WARNING: 1.0 <= Cpk < 1.33 (meets spec but marginal)
- CRITICAL: Cpk < 1.0 (not meeting specification)

Creates CAPA for CRITICAL capability.
"""

import logging
import statistics
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class ProcessCapabilityCalculator:
    """
    Calculate process capability indices.
    
    Requires:
    - Specification limits (USL, LSL)
    - Measurement data (minimum 30 samples for reliability)
    """
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
        
        # Capability thresholds
        self.target_cpk = 1.33  # Target for capable process
        self.warning_cpk = 1.0  # Warning threshold
        self.critical_cpk = 0.67  # Critical threshold
    
    def evaluate_all_cqcs(self):
        """
        Evaluate capability for all active CQCs.
        
        Called periodically (e.g., every hour).
        """
        logger.info("Evaluating process capability for all CQCs...")
        
        cqcs = self.db.get_active_cqcs()
        
        for cqc in cqcs:
            try:
                self.evaluate_cqc(cqc['cqc_id'])
            except Exception as e:
                logger.error(f"Error evaluating capability for {cqc['cqc_id']}: {e}")
    
    def evaluate_cqc(self, cqc_id: str) -> Optional[Dict]:
        """
        Evaluate capability for a single CQC.
        
        Returns capability result dict or None if insufficient data.
        """
        # Get CQC spec limits
        cqc = self.db.get_cqc(cqc_id)
        if not cqc:
            logger.warning(f"CQC {cqc_id} not found")
            return None
        
        usl = cqc.get('upper_spec_limit')
        lsl = cqc.get('lower_spec_limit')
        target = cqc.get('target_value')
        
        if usl is None and lsl is None:
            logger.debug(f"CQC {cqc_id} has no spec limits, skipping capability")
            return None
        
        # Get recent measurements (last 100 samples or last 30 days)
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        samples = self.db.get_measurements_since(cqc_id, cutoff, limit=100)
        
        if len(samples) < 30:
            logger.warning(f"Insufficient data for {cqc_id} capability ({len(samples)} samples, need >=30)")
            return None
        
        # Calculate statistics
        mean = statistics.mean(samples)
        stdev = statistics.stdev(samples)
        
        # Short-term variation (within subgroups) - simplified as overall stdev
        # In practice, should use R-bar / d2 or S-bar / c4
        sigma_short_term = stdev
        
        # Long-term variation (overall)
        sigma_long_term = stdev
        
        # Calculate indices
        result = {
            'cqc_id': cqc_id,
            'sample_count': len(samples),
            'mean': mean,
            'stdev': stdev,
            'usl': usl,
            'lsl': lsl,
            'target': target,
            'cp': None,
            'cpk': None,
            'pp': None,
            'ppk': None,
            'capability_status': 'UNKNOWN',
            'defect_rate_ppm': None,
            'ts_calculated': datetime.now(timezone.utc)
        }
        
        # Cp: Process potential
        if usl is not None and lsl is not None:
            result['cp'] = (usl - lsl) / (6 * sigma_short_term)
        
        # Cpk: Process performance (accounts for centering)
        if usl is not None and lsl is not None:
            cpu = (usl - mean) / (3 * sigma_short_term)
            cpl = (mean - lsl) / (3 * sigma_short_term)
            result['cpk'] = min(cpu, cpl)
        elif usl is not None:
            # One-sided spec (upper only)
            result['cpk'] = (usl - mean) / (3 * sigma_short_term)
        elif lsl is not None:
            # One-sided spec (lower only)
            result['cpk'] = (mean - lsl) / (3 * sigma_short_term)
        
        # Pp: Long-term potential
        if usl is not None and lsl is not None:
            result['pp'] = (usl - lsl) / (6 * sigma_long_term)
        
        # Ppk: Long-term performance
        if usl is not None and lsl is not None:
            ppu = (usl - mean) / (3 * sigma_long_term)
            ppl = (mean - lsl) / (3 * sigma_long_term)
            result['ppk'] = min(ppu, ppl)
        elif usl is not None:
            result['ppk'] = (usl - mean) / (3 * sigma_long_term)
        elif lsl is not None:
            result['ppk'] = (mean - lsl) / (3 * sigma_long_term)
        
        # Determine capability status based on Cpk
        cpk = result.get('cpk')
        if cpk is not None:
            if cpk >= self.target_cpk:
                result['capability_status'] = 'CAPABLE'
            elif cpk >= self.warning_cpk:
                result['capability_status'] = 'WARNING'
            else:
                result['capability_status'] = 'CRITICAL'
        
        # Estimate defect rate (PPM) from Cpk
        # Simplified: use Z-score approximation
        if cpk is not None:
            z_score = cpk * 3
            # Very rough approximation (proper calculation requires normal CDF)
            if z_score >= 6:
                result['defect_rate_ppm'] = 3.4  # 6-sigma
            elif z_score >= 4.5:
                result['defect_rate_ppm'] = 1350  # 4.5-sigma
            elif z_score >= 3:
                result['defect_rate_ppm'] = 2700  # 3-sigma
            else:
                result['defect_rate_ppm'] = 66800  # <3-sigma
        
        # Store result
        self.db.store_capability_result(result)
        
        # Publish event
        self.uns.publish_capability_event(result)
        
        # Create CAPA if critical
        if result['capability_status'] == 'CRITICAL':
            self._create_capability_capa(cqc_id, result)
        
        logger.info(
            f"Capability for {cqc_id}: Cp={result.get('cp', 0):.2f}, "
            f"Cpk={result.get('cpk', 0):.2f}, Status={result['capability_status']}"
        )
        
        return result
    
    def _create_capability_capa(self, cqc_id: str, capability_result: Dict):
        """
        Create CAPA for critical process capability.
        """
        # Check if recent CAPA already exists for this CQC
        recent_capas = self.db.get_recent_capas_for_cqc(cqc_id, days=30)
        if recent_capas:
            logger.info(f"Recent CAPA exists for {cqc_id}, skipping duplicate")
            return
        
        capa_data = {
            'title': f"Critical Process Capability: {cqc_id}",
            'description': (
                f"CQC {cqc_id} has critical process capability (Cpk={capability_result.get('cpk', 0):.2f}). "
                f"Process is not consistently meeting specification limits. "
                f"Mean: {capability_result['mean']:.3f}, Stdev: {capability_result['stdev']:.3f}, "
                f"USL: {capability_result['usl']}, LSL: {capability_result['lsl']}"
            ),
            'severity': 'MAJOR',
            'capa_type': 'CORRECTIVE',
            'cqc_id': cqc_id,
            'root_cause': None,
            'corrective_action': None,
            'ts_due': datetime.now(timezone.utc) + timedelta(days=14)  # 14 days for MAJOR
        }
        
        capa_id = self.db.create_capa(capa_data)
        logger.warning(f"Created CAPA CAPA-{capa_id:05d} for critical capability on {cqc_id}")
        
        # Publish event
        self.uns.publish_capa_event({
            'event': 'CREATED',
            'capa_id': capa_id,
            'reason': 'Critical process capability',
            **capa_data
        })


class ProcessPerformanceMonitor:
    """
    Monitor overall process performance metrics.
    
    Tracks:
    - Yield (FPY, RTY)
    - Defect rate (DPMO, PPM)
    - Scrap rate
    - Rework rate
    """
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
        self.capability_calculator = ProcessCapabilityCalculator(db, uns, site_name)
    
    def evaluate_all_processes(self):
        """
        Evaluate all process performance metrics.
        
        Called periodically.
        """
        logger.info("Evaluating process performance...")
        
        # Capability analysis
        self.capability_calculator.evaluate_all_cqcs()
        
        # Process-level metrics
        processes = self.db.get_active_processes()
        for process in processes:
            try:
                self.evaluate_process(process['process_id'])
            except Exception as e:
                logger.error(f"Error evaluating process {process['process_id']}: {e}")
    
    def evaluate_process(self, process_id: str):
        """
        Evaluate performance metrics for a specific process.
        """
        # Get recent production data
        cutoff = datetime.now(timezone.utc) - timedelta(days=1)
        stats = self.db.get_process_stats(process_id, since=cutoff)
        
        if not stats:
            return
        
        # Calculate FPY (First Pass Yield)
        total = stats['total_units']
        passed = stats['passed_units']
        fpy = (passed / total * 100) if total > 0 else 0
        
        # Calculate DPMO (Defects Per Million Opportunities)
        defects = stats['defect_count']
        opportunities = stats['opportunities']
        dpmo = (defects / opportunities * 1_000_000) if opportunities > 0 else 0
        
        result = {
            'process_id': process_id,
            'period_start': cutoff,
            'period_end': datetime.now(timezone.utc),
            'total_units': total,
            'passed_units': passed,
            'failed_units': total - passed,
            'fpy_percent': fpy,
            'defect_count': defects,
            'dpmo': dpmo,
            'scrap_rate_percent': stats.get('scrap_rate', 0),
            'rework_rate_percent': stats.get('rework_rate', 0)
        }
        
        # Store
        self.db.store_process_performance(result)
        
        # Publish
        self.uns.publish_process_performance(result)
        
        logger.info(f"Process {process_id}: FPY={fpy:.1f}%, DPMO={dpmo:.0f}")
