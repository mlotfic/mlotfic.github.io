"""
ISO 9001 Quality Management System - Database Layer

PostgreSQL data access layer with connection pooling.
Handles all quality data: products, processes, CQCs, measurements,
capability results, nonconformances, CAPAs, audits, and KPIs.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional
import psycopg2
from psycopg2 import pool
from psycopg2.extras import execute_values, RealDictCursor

from config import DatabaseConfig

logger = logging.getLogger(__name__)


class QualityDatabase:
    """PostgreSQL database interface with connection pooling"""
    
    def __init__(self, config: DatabaseConfig):
        self.config = config
        self.pool: Optional[pool.ThreadedConnectionPool] = None
    
    def connect(self):
        """Initialize connection pool"""
        try:
            self.pool = pool.ThreadedConnectionPool(
                minconn=2,
                maxconn=self.config.pool_size,
                host=self.config.host,
                port=self.config.port,
                database=self.config.name,
                user=self.config.user,
                password=self.config.password
            )
            logger.info(
                f"Connected to database: {self.config.host}:{self.config.port}/"
                f"{self.config.name}"
            )
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    def close(self):
        """Close all connections"""
        if self.pool:
            self.pool.closeall()
            logger.info("Database connections closed")
    
    def _get_conn(self):
        """Get connection from pool"""
        return self.pool.getconn()
    
    def _put_conn(self, conn):
        """Return connection to pool"""
        self.pool.putconn(conn)
    
    # ==================== Products & Processes ====================
    
    def store_product(self, product_id: str, product_name: str, **kwargs):
        """Store or update product"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO products 
                    (product_id, product_name, product_family, part_number, 
                     revision, customer, active)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (product_id) DO UPDATE SET
                        product_name = EXCLUDED.product_name,
                        product_family = EXCLUDED.product_family,
                        part_number = EXCLUDED.part_number,
                        revision = EXCLUDED.revision,
                        customer = EXCLUDED.customer,
                        active = EXCLUDED.active
                """, (
                    product_id, product_name, kwargs.get('product_family'),
                    kwargs.get('part_number'), kwargs.get('revision'),
                    kwargs.get('customer'), kwargs.get('active', True)
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def store_process(self, process_id: str, process_name: str, **kwargs):
        """Store or update process"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO processes 
                    (process_id, process_name, process_type, department, 
                     owner, description, active)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (process_id) DO UPDATE SET
                        process_name = EXCLUDED.process_name,
                        process_type = EXCLUDED.process_type,
                        department = EXCLUDED.department,
                        owner = EXCLUDED.owner,
                        description = EXCLUDED.description,
                        active = EXCLUDED.active
                """, (
                    process_id, process_name, kwargs.get('process_type'),
                    kwargs.get('department'), kwargs.get('owner'),
                    kwargs.get('description'), kwargs.get('active', True)
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    # ==================== Critical Quality Characteristics ====================
    
    def store_cqc(self, cqc_id: str, cqc_name: str, **kwargs):
        """Store or update CQC"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO critical_quality_characteristics 
                    (cqc_id, cqc_name, product_id, process_id, characteristic_type,
                     measurement_unit, lower_spec_limit, upper_spec_limit, 
                     target_value, target_cpk, warning_cpk, critical_cpk, 
                     sample_size, control_method, active)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (cqc_id) DO UPDATE SET
                        cqc_name = EXCLUDED.cqc_name,
                        lower_spec_limit = EXCLUDED.lower_spec_limit,
                        upper_spec_limit = EXCLUDED.upper_spec_limit,
                        target_value = EXCLUDED.target_value,
                        target_cpk = EXCLUDED.target_cpk,
                        warning_cpk = EXCLUDED.warning_cpk,
                        critical_cpk = EXCLUDED.critical_cpk,
                        sample_size = EXCLUDED.sample_size,
                        active = EXCLUDED.active
                """, (
                    cqc_id, cqc_name, kwargs.get('product_id'), 
                    kwargs.get('process_id'), kwargs.get('characteristic_type', 'DIMENSION'),
                    kwargs.get('measurement_unit'), kwargs.get('lower_spec_limit'),
                    kwargs.get('upper_spec_limit'), kwargs.get('target_value'),
                    kwargs.get('target_cpk', 1.33), kwargs.get('warning_cpk', 1.0),
                    kwargs.get('critical_cpk', 0.67), kwargs.get('sample_size', 30),
                    kwargs.get('control_method', 'SPC'), kwargs.get('active', True)
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def get_active_cqcs(self) -> List[Dict[str, Any]]:
        """Get all active CQCs"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM critical_quality_characteristics 
                    WHERE active = true
                    ORDER BY cqc_id
                """)
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== Quality Measurements ====================
    
    def store_measurements_batch(self, measurements: List[Dict[str, Any]]):
        """Store batch of quality measurements"""
        if not measurements:
            return
        
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                values = [
                    (
                        m.get('ts_utc'), m.get('source_id'), m.get('cqc_id'),
                        m.get('product_id'), m.get('process_id'), m.get('lot_number'),
                        m.get('serial_number'), m.get('measured_value'),
                        m.get('measurement_unit'), m.get('operator'),
                        m.get('equipment_id'), m.get('pass_fail'),
                        m.get('details', {}), m.get('quality')
                    )
                    for m in measurements
                ]
                execute_values(cur, """
                    INSERT INTO quality_measurements 
                    (ts_utc, source_id, cqc_id, product_id, process_id, lot_number,
                     serial_number, measured_value, measurement_unit, operator,
                     equipment_id, pass_fail, details, quality)
                    VALUES %s
                    RETURNING measurement_id
                """, values)
                ids = [row[0] for row in cur.fetchall()]
                
                # Store IDs back into measurement dicts
                for m, mid in zip(measurements, ids):
                    m['measurement_id'] = mid
            
            conn.commit()
            logger.debug(f"Stored {len(measurements)} measurements")
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to store measurements: {e}")
            raise
        finally:
            self._put_conn(conn)
    
    def get_measurements_for_cqc(
        self, 
        cqc_id: str, 
        hours: int = 24, 
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """Get recent measurements for a CQC"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
                cur.execute("""
                    SELECT * FROM quality_measurements
                    WHERE cqc_id = %s AND ts_utc >= %s
                    ORDER BY ts_utc DESC
                    LIMIT %s
                """, (cqc_id, cutoff, limit))
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== SPC Control Limits ====================
    
    def store_control_limits(
        self, 
        cqc_id: str, 
        center_line: float,
        ucl: float,
        lcl: float,
        **kwargs
    ):
        """Store or update SPC control limits"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO spc_control_limits
                    (cqc_id, ts_calculated, center_line, ucl, lcl, 
                     usl, lsl, sample_size, sigma)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (cqc_id) DO UPDATE SET
                        ts_calculated = EXCLUDED.ts_calculated,
                        center_line = EXCLUDED.center_line,
                        ucl = EXCLUDED.ucl,
                        lcl = EXCLUDED.lcl,
                        usl = EXCLUDED.usl,
                        lsl = EXCLUDED.lsl,
                        sample_size = EXCLUDED.sample_size,
                        sigma = EXCLUDED.sigma
                """, (
                    cqc_id, datetime.now(timezone.utc), center_line,
                    ucl, lcl, kwargs.get('usl'), kwargs.get('lsl'),
                    kwargs.get('sample_size'), kwargs.get('sigma')
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def get_control_limits(self, cqc_id: str) -> Optional[Dict[str, Any]]:
        """Get current control limits for a CQC"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM spc_control_limits 
                    WHERE cqc_id = %s
                """, (cqc_id,))
                row = cur.fetchone()
                return dict(row) if row else None
        finally:
            self._put_conn(conn)
    
    # ==================== Process Capability ====================
    
    def store_capability_result(
        self, 
        cqc_id: str, 
        cp: float, 
        cpk: float,
        **kwargs
    ):
        """Store process capability result"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO capability_results
                    (cqc_id, ts_calculated, cp, cpk, pp, ppk, mean_value, 
                     std_dev, sample_size, capability_status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    cqc_id, datetime.now(timezone.utc), cp, cpk,
                    kwargs.get('pp'), kwargs.get('ppk'), kwargs.get('mean_value'),
                    kwargs.get('std_dev'), kwargs.get('sample_size'),
                    kwargs.get('capability_status')
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def get_latest_capability(self, cqc_id: str) -> Optional[Dict[str, Any]]:
        """Get latest capability result for a CQC"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM capability_results 
                    WHERE cqc_id = %s 
                    ORDER BY ts_calculated DESC 
                    LIMIT 1
                """, (cqc_id,))
                row = cur.fetchone()
                return dict(row) if row else None
        finally:
            self._put_conn(conn)
    
    # ==================== Nonconformances ====================
    
    def create_nonconformance(
        self, 
        title: str, 
        description: str,
        severity: str,
        **kwargs
    ) -> str:
        """Create new nonconformance"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO nonconformances
                    (ts_detected, title, description, severity, nc_type,
                     product_id, process_id, cqc_id, lot_number, quantity_affected,
                     detected_by, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING nc_id
                """, (
                    datetime.now(timezone.utc), title, description, severity,
                    kwargs.get('nc_type', 'PRODUCT'), kwargs.get('product_id'),
                    kwargs.get('process_id'), kwargs.get('cqc_id'),
                    kwargs.get('lot_number'), kwargs.get('quantity_affected'),
                    kwargs.get('detected_by'), 'OPEN'
                ))
                nc_id = cur.fetchone()[0]
                
                # Add timeline entry
                cur.execute("""
                    INSERT INTO nonconformance_timeline
                    (nc_id, ts_utc, action, actor, notes)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    nc_id, datetime.now(timezone.utc), 'CREATED',
                    kwargs.get('detected_by', 'SYSTEM'),
                    f"Nonconformance created: {title}"
                ))
            conn.commit()
            logger.info(f"Created nonconformance {nc_id}: {title}")
            return nc_id
        finally:
            self._put_conn(conn)
    
    def update_nc_status(
        self, 
        nc_id: int, 
        new_status: str, 
        actor: str,
        notes: str = None
    ):
        """Update nonconformance status"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                # Update status with timestamp
                status_field = f"ts_{new_status.lower()}"
                if status_field in ['ts_contained', 'ts_investigated', 'ts_resolved', 'ts_closed']:
                    cur.execute(f"""
                        UPDATE nonconformances 
                        SET status = %s, {status_field} = %s
                        WHERE nc_id = %s
                    """, (new_status, datetime.now(timezone.utc), nc_id))
                else:
                    cur.execute("""
                        UPDATE nonconformances 
                        SET status = %s 
                        WHERE nc_id = %s
                    """, (new_status, nc_id))
                
                # Add timeline entry
                cur.execute("""
                    INSERT INTO nonconformance_timeline
                    (nc_id, ts_utc, action, actor, notes)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    nc_id, datetime.now(timezone.utc),
                    f"STATUS_CHANGED_{new_status}", actor, notes
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def get_active_nonconformances(self) -> List[Dict[str, Any]]:
        """Get all active (non-closed) nonconformances"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM active_nonconformances
                    ORDER BY severity DESC, ts_detected ASC
                """)
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== CAPAs ====================
    
    def create_capa(
        self, 
        title: str, 
        description: str,
        capa_type: str,
        severity: str,
        **kwargs
    ) -> str:
        """Create new CAPA"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                # Calculate SLA deadline
                sla_days = kwargs.get('sla_days', 30)
                ts_target = datetime.now(timezone.utc) + timedelta(days=sla_days)
                
                cur.execute("""
                    INSERT INTO capas
                    (ts_created, title, description, capa_type, severity,
                     nc_id, root_cause, corrective_action, preventive_action,
                     assigned_to, ts_target, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING capa_id
                """, (
                    datetime.now(timezone.utc), title, description, capa_type,
                    severity, kwargs.get('nc_id'), kwargs.get('root_cause'),
                    kwargs.get('corrective_action'), kwargs.get('preventive_action'),
                    kwargs.get('assigned_to'), ts_target, 'OPEN'
                ))
                capa_id = cur.fetchone()[0]
            conn.commit()
            logger.info(f"Created CAPA {capa_id}: {title}")
            return capa_id
        finally:
            self._put_conn(conn)
    
    def update_capa_status(self, capa_id: int, new_status: str, **kwargs):
        """Update CAPA status"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                # Update status with timestamp
                status_field = f"ts_{new_status.lower()}"
                if status_field in ['ts_implementing', 'ts_verifying', 'ts_effective', 'ts_closed']:
                    cur.execute(f"""
                        UPDATE capas 
                        SET status = %s, {status_field} = %s
                        WHERE capa_id = %s
                    """, (new_status, datetime.now(timezone.utc), capa_id))
                else:
                    cur.execute("""
                        UPDATE capas 
                        SET status = %s 
                        WHERE capa_id = %s
                    """, (new_status, capa_id))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    def get_open_capas(self) -> List[Dict[str, Any]]:
        """Get all open CAPAs"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM capas 
                    WHERE status NOT IN ('CLOSED', 'CANCELLED')
                    ORDER BY severity DESC, ts_created ASC
                """)
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    def get_overdue_capas(self) -> List[Dict[str, Any]]:
        """Get CAPAs past their SLA deadline"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM capas 
                    WHERE status NOT IN ('CLOSED', 'CANCELLED')
                    AND ts_target < %s
                    ORDER BY ts_target ASC
                """, (datetime.now(timezone.utc),))
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== Customer Complaints ====================
    
    def create_customer_complaint(
        self, 
        complaint_number: str,
        customer_name: str,
        description: str,
        severity: str,
        **kwargs
    ) -> int:
        """Create customer complaint"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO customer_complaints
                    (ts_received, complaint_number, customer_name, description,
                     severity, product_id, quantity_affected, root_cause,
                     containment_action, corrective_action, customer_notification,
                     status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING complaint_id
                """, (
                    datetime.now(timezone.utc), complaint_number, customer_name,
                    description, severity, kwargs.get('product_id'),
                    kwargs.get('quantity_affected'), kwargs.get('root_cause'),
                    kwargs.get('containment_action'), kwargs.get('corrective_action'),
                    kwargs.get('customer_notification'), 'RECEIVED'
                ))
                complaint_id = cur.fetchone()[0]
            conn.commit()
            logger.info(f"Created customer complaint {complaint_id}: {complaint_number}")
            return complaint_id
        finally:
            self._put_conn(conn)
    
    def get_open_complaints(self) -> List[Dict[str, Any]]:
        """Get open customer complaints"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM customer_complaints 
                    WHERE status NOT IN ('CLOSED')
                    ORDER BY severity DESC, ts_received ASC
                """)
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== Audit Findings ====================
    
    def create_audit_finding(
        self, 
        audit_ref: str,
        finding_type: str,
        description: str,
        severity: str,
        **kwargs
    ) -> int:
        """Create audit finding"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                target_date = datetime.now(timezone.utc) + timedelta(
                    days=kwargs.get('target_days', 30)
                )
                cur.execute("""
                    INSERT INTO audit_findings
                    (audit_ref, finding_type, description, severity, clause_ref,
                     process_id, owner, corrective_action, target_date, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING finding_id
                """, (
                    audit_ref, finding_type, description, severity,
                    kwargs.get('clause_ref'), kwargs.get('process_id'),
                    kwargs.get('owner'), kwargs.get('corrective_action'),
                    target_date, 'OPEN'
                ))
                finding_id = cur.fetchone()[0]
            conn.commit()
            return finding_id
        finally:
            self._put_conn(conn)
    
    def get_open_audit_findings(self) -> List[Dict[str, Any]]:
        """Get open audit findings"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT * FROM audit_findings 
                    WHERE status NOT IN ('CLOSED', 'VERIFIED')
                    ORDER BY severity DESC
                """)
                return [dict(row) for row in cur.fetchall()]
        finally:
            self._put_conn(conn)
    
    # ==================== Quality KPIs ====================
    
    def store_kpis(self, kpis: Dict[str, Any]):
        """Store quality KPIs snapshot"""
        conn = self._get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO quality_kpis
                    (ts_utc, period_start, period_end, period_hours,
                     defect_rate_ppm, first_pass_yield, rework_rate_pct,
                     scrap_rate_pct, avg_cpk, open_nonconformances,
                     open_capas, overdue_capas, customer_complaints,
                     audit_findings, on_time_delivery_pct)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    datetime.now(timezone.utc), kpis.get('period_start'),
                    kpis.get('period_end'), kpis.get('period_hours'),
                    kpis.get('defect_rate_ppm'), kpis.get('first_pass_yield'),
                    kpis.get('rework_rate_pct'), kpis.get('scrap_rate_pct'),
                    kpis.get('avg_cpk'), kpis.get('open_nonconformances'),
                    kpis.get('open_capas'), kpis.get('overdue_capas'),
                    kpis.get('customer_complaints'), kpis.get('audit_findings'),
                    kpis.get('on_time_delivery_pct')
                ))
            conn.commit()
        finally:
            self._put_conn(conn)
    
    # ==================== Dashboard ====================
    
    def get_quality_dashboard(self) -> Dict[str, Any]:
        """Get quality dashboard snapshot"""
        conn = self._get_conn()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("SELECT * FROM quality_dashboard LIMIT 1")
                row = cur.fetchone()
                return dict(row) if row else {}
        finally:
            self._put_conn(conn)
