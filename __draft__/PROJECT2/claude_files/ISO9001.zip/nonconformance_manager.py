"""
Nonconformance (NC) Management Module

Manages lifecycle of quality nonconformances:
DETECTED → CONTAINED → INVESTIGATING → RESOLVED → CLOSED

NC types:
- PRODUCT_DEFECT: Product does not meet specification
- PROCESS_OUT_OF_CONTROL: SPC violation
- AUDIT_FINDING: Internal/external audit issue
- CUSTOMER_COMPLAINT: Customer-reported problem
- SUPPLIER_DEFECT: Incoming material issue
"""

import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class NonconformanceManager:
    """
    Manage nonconformance lifecycle and timeline.
    """
    
    VALID_STATES = ['DETECTED', 'CONTAINED', 'INVESTIGATING', 'RESOLVED', 'CLOSED']
    
    VALID_TRANSITIONS = {
        'DETECTED': ['CONTAINED', 'INVESTIGATING'],
        'CONTAINED': ['INVESTIGATING', 'RESOLVED'],
        'INVESTIGATING': ['RESOLVED', 'CONTAINED'],
        'RESOLVED': ['CLOSED', 'INVESTIGATING'],
        'CLOSED': []
    }
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
    
    def create_nonconformance(
        self,
        title: str,
        description: str,
        severity: str,  # CRITICAL, MAJOR, MINOR, OBSERVATION
        nc_type: str,
        correlation_rule_id: Optional[str] = None,
        cqc_id: Optional[str] = None,
        product_id: Optional[str] = None,
        process_id: Optional[str] = None,
        lot_number: Optional[str] = None,
        ts_occurred: Optional[datetime] = None,
        affected_processes: Optional[List[str]] = None
    ) -> int:
        """
        Create new nonconformance.
        
        Returns NC ID.
        """
        nc_data = {
            'title': title,
            'description': description,
            'severity': severity,
            'nc_type': nc_type,
            'status': 'DETECTED',
            'correlation_rule_id': correlation_rule_id,
            'cqc_id': cqc_id,
            'product_id': product_id,
            'process_id': process_id,
            'lot_number': lot_number,
            'ts_detected': datetime.now(timezone.utc),
            'ts_occurred': ts_occurred or datetime.now(timezone.utc),
            'affected_processes': affected_processes or [],
            'assigned_to': None,
            'containment_action': None,
            'root_cause': None,
            'corrective_action': None
        }
        
        # Store in database
        nc_id = self.db.store_nonconformance(nc_data)
        
        # Add timeline entry
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action='CREATED',
            actor='SYSTEM',
            notes=f"NC created: {title}"
        )
        
        # Publish event
        self.uns.publish_nonconformance_event({
            'event': 'CREATED',
            'ts': datetime.now(timezone.utc),
            'nc_id': nc_id,
            **nc_data
        })
        
        logger.info(f"Created nonconformance NC-{nc_id:05d}: {title}")
        
        return nc_id
    
    def update_status(
        self,
        nc_id: int,
        new_status: str,
        actor: str = 'SYSTEM',
        notes: Optional[str] = None
    ) -> bool:
        """
        Update NC status with validation.
        
        Returns True if successful, False if invalid transition.
        """
        # Get current status
        nc = self.db.get_nonconformance(nc_id)
        if not nc:
            logger.error(f"NC {nc_id} not found")
            return False
        
        current_status = nc['status']
        
        # Validate transition
        if new_status not in self.VALID_TRANSITIONS.get(current_status, []):
            logger.error(
                f"Invalid status transition for NC-{nc_id}: "
                f"{current_status} -> {new_status}"
            )
            return False
        
        # Update status
        self.db.update_nonconformance_status(nc_id, new_status)
        
        # Add timeline entry
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action=f'STATUS_CHANGED_TO_{new_status}',
            actor=actor,
            notes=notes or f'Status changed to {new_status}'
        )
        
        # Publish event
        self.uns.publish_nonconformance_event({
            'event': 'STATUS_CHANGED',
            'ts': datetime.now(timezone.utc),
            'nc_id': nc_id,
            'old_status': current_status,
            'new_status': new_status,
            'actor': actor
        })
        
        logger.info(f"NC-{nc_id:05d} status: {current_status} -> {new_status}")
        
        return True
    
    def add_containment_action(
        self,
        nc_id: int,
        action: str,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Add containment action to NC.
        """
        self.db.update_nonconformance_field(nc_id, 'containment_action', action)
        
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action='CONTAINMENT_ACTION',
            actor=actor,
            notes=notes or action
        )
        
        logger.info(f"NC-{nc_id:05d} containment action recorded")
        return True
    
    def add_root_cause(
        self,
        nc_id: int,
        root_cause: str,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Add root cause analysis to NC.
        """
        self.db.update_nonconformance_field(nc_id, 'root_cause', root_cause)
        
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action='ROOT_CAUSE_IDENTIFIED',
            actor=actor,
            notes=notes or root_cause
        )
        
        logger.info(f"NC-{nc_id:05d} root cause identified")
        return True
    
    def add_corrective_action(
        self,
        nc_id: int,
        action: str,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Add corrective action to NC.
        """
        self.db.update_nonconformance_field(nc_id, 'corrective_action', action)
        
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action='CORRECTIVE_ACTION',
            actor=actor,
            notes=notes or action
        )
        
        logger.info(f"NC-{nc_id:05d} corrective action recorded")
        return True
    
    def assign_to(
        self,
        nc_id: int,
        assignee: str,
        actor: str = 'SYSTEM'
    ) -> bool:
        """
        Assign NC to person.
        """
        self.db.update_nonconformance_field(nc_id, 'assigned_to', assignee)
        
        self.db.add_nc_timeline(
            nc_id=nc_id,
            action='ASSIGNED',
            actor=actor,
            notes=f'Assigned to {assignee}'
        )
        
        logger.info(f"NC-{nc_id:05d} assigned to {assignee}")
        return True
    
    def get_active_nonconformances(self) -> List[Dict]:
        """
        Get all active (not closed) nonconformances.
        """
        return self.db.get_active_nonconformances()
    
    def get_nc_timeline(self, nc_id: int) -> List[Dict]:
        """
        Get timeline for NC.
        """
        return self.db.get_nc_timeline(nc_id)
