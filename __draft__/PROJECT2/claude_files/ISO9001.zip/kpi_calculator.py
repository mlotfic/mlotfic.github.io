"""
Quality KPI Calculator Module

Computes quality performance indicators:
- DPMO (Defects Per Million Opportunities)
- PPM (Parts Per Million)
- FPY (First Pass Yield)
- RTY (Rolled Throughput Yield)
- Avg Cpk (Process Capability Index)
- NC rate
- CAPA cycle time
- Customer satisfaction
- On-time delivery (OTD)
- Scrap rate
- Rework rate

Publishes to UNS for dashboards and analytics.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class QualityKPICalculator:
    """
    Calculate quality KPIs from live data.
    """
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
        
        # KPI computation window (default 1 hour)
        self.window_hours = 1
    
    def compute_all(self):
        """
        Compute all quality KPIs and publish.
        
        Called periodically (e.g., every hour).
        """
        logger.info("Computing quality KPIs...")
        
        now = datetime.now(timezone.utc)
        period_start = now - timedelta(hours=self.window_hours)
        
        kpis = {
            'period_start': period_start,
            'period_end': now,
            'period_hours': self.window_hours,
            'ts_computed': now
        }
        
        # Production metrics
        kpis.update(self._compute_production_kpis(period_start, now))
        
        # Quality metrics
        kpis.update(self._compute_quality_kpis(period_start, now))
        
        # Process capability
        kpis.update(self._compute_capability_kpis(period_start, now))
        
        # Nonconformance metrics
        kpis.update(self._compute_nc_kpis(period_start, now))
        
        # CAPA metrics
        kpis.update(self._compute_capa_kpis(period_start, now))
        
        # Customer metrics
        kpis.update(self._compute_customer_kpis(period_start, now))
        
        # Store KPIs
        self.db.store_quality_kpis(kpis)
        
        # Publish to UNS
        self.uns.publish_quality_kpis(kpis)
        
        logger.info(
            f"KPIs computed: DPMO={kpis.get('dpmo', 0):.0f}, "
            f"FPY={kpis.get('fpy_percent', 0):.1f}%, "
            f"Avg Cpk={kpis.get('avg_cpk', 0):.2f}"
        )
    
    def _compute_production_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute production-related KPIs.
        """
        stats = self.db.get_production_stats(start, end)
        
        total_units = stats.get('total_units', 0)
        passed_units = stats.get('passed_units', 0)
        failed_units = stats.get('failed_units', 0)
        
        # First Pass Yield (FPY)
        fpy_percent = (passed_units / total_units * 100) if total_units > 0 else 0
        
        # Rolled Throughput Yield (RTY) - product of FPY across all processes
        process_yields = stats.get('process_yields', [])
        rty_percent = 1.0
        for yield_val in process_yields:
            rty_percent *= (yield_val / 100)
        rty_percent *= 100
        
        # Scrap rate
        scrap_units = stats.get('scrap_units', 0)
        scrap_rate_percent = (scrap_units / total_units * 100) if total_units > 0 else 0
        
        # Rework rate
        rework_units = stats.get('rework_units', 0)
        rework_rate_percent = (rework_units / total_units * 100) if total_units > 0 else 0
        
        return {
            'total_units_produced': total_units,
            'passed_units': passed_units,
            'failed_units': failed_units,
            'fpy_percent': fpy_percent,
            'rty_percent': rty_percent,
            'scrap_units': scrap_units,
            'scrap_rate_percent': scrap_rate_percent,
            'rework_units': rework_units,
            'rework_rate_percent': rework_rate_percent
        }
    
    def _compute_quality_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute quality defect metrics.
        """
        stats = self.db.get_quality_stats(start, end)
        
        defect_count = stats.get('defect_count', 0)
        opportunities = stats.get('opportunities', 0)
        
        # DPMO (Defects Per Million Opportunities)
        dpmo = (defect_count / opportunities * 1_000_000) if opportunities > 0 else 0
        
        # PPM (Parts Per Million) - defective parts
        total_units = stats.get('total_units', 0)
        defective_units = stats.get('defective_units', 0)
        ppm = (defective_units / total_units * 1_000_000) if total_units > 0 else 0
        
        # Defect density (defects per unit)
        defect_density = (defect_count / total_units) if total_units > 0 else 0
        
        # Sigma level (approximation from DPMO)
        sigma_level = self._dpmo_to_sigma(dpmo)
        
        return {
            'defect_count': defect_count,
            'defective_units': defective_units,
            'opportunities': opportunities,
            'dpmo': dpmo,
            'ppm': ppm,
            'defect_density': defect_density,
            'sigma_level': sigma_level
        }
    
    def _compute_capability_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute process capability metrics.
        """
        # Get capability results for all CQCs
        capability_results = self.db.get_recent_capability_results(since=start)
        
        if not capability_results:
            return {
                'avg_cpk': None,
                'min_cpk': None,
                'capable_cqcs': 0,
                'warning_cqcs': 0,
                'critical_cqcs': 0,
                'total_cqcs': 0
            }
        
        cpk_values = [r['cpk'] for r in capability_results if r.get('cpk') is not None]
        
        capable = sum(1 for r in capability_results if r.get('capability_status') == 'CAPABLE')
        warning = sum(1 for r in capability_results if r.get('capability_status') == 'WARNING')
        critical = sum(1 for r in capability_results if r.get('capability_status') == 'CRITICAL')
        
        return {
            'avg_cpk': sum(cpk_values) / len(cpk_values) if cpk_values else None,
            'min_cpk': min(cpk_values) if cpk_values else None,
            'capable_cqcs': capable,
            'warning_cqcs': warning,
            'critical_cqcs': critical,
            'total_cqcs': len(capability_results)
        }
    
    def _compute_nc_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute nonconformance metrics.
        """
        # NC count by severity
        nc_stats = self.db.get_nc_stats(start, end)
        
        total_ncs = nc_stats.get('total', 0)
        critical_ncs = nc_stats.get('critical', 0)
        major_ncs = nc_stats.get('major', 0)
        minor_ncs = nc_stats.get('minor', 0)
        
        # NC rate (per 1000 units)
        total_units = self.db.count_produced_units(since=start)
        nc_rate_per_1000 = (total_ncs / total_units * 1000) if total_units > 0 else 0
        
        # Time to containment (average hours)
        containment_times = self.db.get_nc_containment_times(start, end)
        avg_containment_hours = (
            sum(containment_times) / len(containment_times)
        ) if containment_times else None
        
        # Time to resolution (average hours)
        resolution_times = self.db.get_nc_resolution_times(start, end)
        avg_resolution_hours = (
            sum(resolution_times) / len(resolution_times)
        ) if resolution_times else None
        
        return {
            'total_ncs': total_ncs,
            'critical_ncs': critical_ncs,
            'major_ncs': major_ncs,
            'minor_ncs': minor_ncs,
            'nc_rate_per_1000': nc_rate_per_1000,
            'avg_containment_hours': avg_containment_hours,
            'avg_resolution_hours': avg_resolution_hours,
            'open_ncs': self.db.count_open_nonconformances()
        }
    
    def _compute_capa_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute CAPA metrics.
        """
        capa_stats = self.db.get_capa_stats(start, end)
        
        total_capas = capa_stats.get('total', 0)
        open_capas = capa_stats.get('open', 0)
        overdue_capas = capa_stats.get('overdue', 0)
        
        # CAPA cycle time (open to closed, average days)
        cycle_times = self.db.get_capa_cycle_times(start, end)
        avg_cycle_days = (
            sum(cycle_times) / len(cycle_times)
        ) if cycle_times else None
        
        # CAPA effectiveness rate
        closed_capas = capa_stats.get('closed', 0)
        effective_capas = capa_stats.get('effective', 0)
        effectiveness_rate = (
            (effective_capas / closed_capas * 100)
        ) if closed_capas > 0 else None
        
        # SLA compliance rate
        sla_compliant = capa_stats.get('sla_compliant', 0)
        sla_compliance_rate = (
            (sla_compliant / total_capas * 100)
        ) if total_capas > 0 else None
        
        return {
            'total_capas': total_capas,
            'open_capas': open_capas,
            'overdue_capas': overdue_capas,
            'avg_capa_cycle_days': avg_cycle_days,
            'capa_effectiveness_rate_percent': effectiveness_rate,
            'capa_sla_compliance_rate_percent': sla_compliance_rate
        }
    
    def _compute_customer_kpis(self, start: datetime, end: datetime) -> Dict:
        """
        Compute customer-related metrics.
        """
        # Customer satisfaction score
        avg_satisfaction = self.db.get_avg_customer_satisfaction(since=start)
        
        # Customer complaints
        complaint_count = self.db.count_customer_complaints(start, end)
        
        # On-time delivery (OTD)
        delivery_stats = self.db.get_delivery_stats(start, end)
        total_deliveries = delivery_stats.get('total', 0)
        on_time_deliveries = delivery_stats.get('on_time', 0)
        otd_percent = (
            (on_time_deliveries / total_deliveries * 100)
        ) if total_deliveries > 0 else None
        
        # Customer returns
        return_count = self.db.count_customer_returns(start, end)
        total_shipped = delivery_stats.get('total', 0)
        return_rate_percent = (
            (return_count / total_shipped * 100)
        ) if total_shipped > 0 else None
        
        return {
            'avg_customer_satisfaction': avg_satisfaction,
            'customer_complaint_count': complaint_count,
            'otd_percent': otd_percent,
            'customer_return_count': return_count,
            'customer_return_rate_percent': return_rate_percent
        }
    
    def _dpmo_to_sigma(self, dpmo: float) -> Optional[float]:
        """
        Convert DPMO to approximate sigma level.
        
        Simplified lookup table.
        """
        if dpmo <= 3.4:
            return 6.0
        elif dpmo <= 233:
            return 5.0
        elif dpmo <= 6210:
            return 4.0
        elif dpmo <= 66807:
            return 3.0
        elif dpmo <= 308537:
            return 2.0
        else:
            return 1.0
