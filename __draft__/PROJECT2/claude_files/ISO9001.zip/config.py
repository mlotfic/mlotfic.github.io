"""
ISO 9001 Quality Management System - Configuration Management

Configuration for quality management following ISO 9001:2015.
"""

import os
import yaml
from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class DatabaseConfig:
    """Database connection configuration"""
    host: str = 'localhost'
    port: int = 5432
    name: str = 'quality_db'
    user: str = 'quality_user'
    password: str = 'quality_pass'
    pool_size: int = 10


@dataclass
class UNSConfig:
    """UNS/MQTT configuration"""
    mqtt_host: str = 'localhost'
    mqtt_port: int = 1883
    mqtt_username: Optional[str] = None
    mqtt_password: Optional[str] = None
    uns_site: str = 'Plant01'
    qos_events: int = 1  # Events are important
    qos_data: int = 0    # Measurements are high volume
    qos_state: int = 0   # State is retained


@dataclass
class InspectionSourceConfig:
    """Configuration for an inspection data source"""
    source_id: str
    source_type: str  # 'modbus_tcp', 'opcua', 'file', 'http_api', 'database'
    enabled: bool = True
    poll_interval_seconds: int = 60
    # Modbus TCP
    modbus_host: Optional[str] = None
    modbus_port: int = 502
    modbus_registers: Optional[List[Dict]] = None
    # OPC UA
    opcua_endpoint: Optional[str] = None
    opcua_nodes: Optional[List[str]] = None
    # File
    file_path: Optional[str] = None
    file_format: str = 'csv'  # 'csv', 'json', 'xml'
    # HTTP API
    api_url: Optional[str] = None
    api_method: str = 'GET'
    api_headers: Optional[Dict[str, str]] = None
    api_json_path: Optional[str] = None
    # Database
    db_connection_string: Optional[str] = None
    db_query: Optional[str] = None


@dataclass
class SPCConfig:
    """Statistical Process Control configuration"""
    # Western Electric / Nelson rules
    enable_rule_1: bool = True   # 1 point > 3σ
    enable_rule_2: bool = True   # 9 points on same side of center
    enable_rule_3: bool = True   # 6 points trending up or down
    enable_rule_4: bool = True   # 14 points alternating up/down
    enable_rule_5: bool = True   # 2 of 3 points > 2σ
    enable_rule_6: bool = True   # 4 of 5 points > 1σ
    enable_rule_7: bool = True   # 15 points within 1σ (over-control)
    enable_rule_8: bool = True   # 8 points beyond 1σ (stratification)
    
    # Control chart parameters
    default_sample_size: int = 30
    min_samples_for_limits: int = 20
    sigma_multiplier: float = 3.0
    moving_range_constant: float = 1.128  # d2 for n=2


@dataclass
class CapabilityConfig:
    """Process capability configuration"""
    target_cpk: float = 1.33   # Industry standard
    warning_cpk: float = 1.0   # Marginally capable
    critical_cpk: float = 0.67 # Incapable
    min_samples: int = 30      # Minimum for reliable Cpk


@dataclass
class CAPAConfig:
    """CAPA configuration"""
    default_sla_days: int = 30
    sla_by_severity: Dict[str, int] = field(default_factory=lambda: {
        'CRITICAL': 7,
        'MAJOR': 14,
        'MINOR': 30,
        'OBSERVATION': 90
    })


@dataclass
class IntervalsConfig:
    """Periodic task intervals in seconds"""
    spc_check_seconds: int = 300          # 5 min
    capability_calc_seconds: int = 3600   # 1 hour
    capa_sla_check_seconds: int = 300     # 5 min
    customer_feedback_check_seconds: int = 600  # 10 min
    audit_check_seconds: int = 3600       # 1 hour
    kpi_computation_seconds: int = 3600   # 1 hour


@dataclass
class FeaturesConfig:
    """Feature flags"""
    measurement_collection: bool = True
    spc_detection: bool = True
    capability_monitoring: bool = True
    nonconformance_management: bool = True
    capa_tracking: bool = True
    customer_management: bool = True
    audit_management: bool = True
    kpi_calculation: bool = True
    uns_publishing: bool = True


@dataclass
class QualityManagerConfig:
    """Main configuration"""
    database: DatabaseConfig
    uns: UNSConfig
    inspection_sources: List[InspectionSourceConfig]
    spc: SPCConfig
    capability: CapabilityConfig
    capa: CAPAConfig
    intervals: IntervalsConfig
    features: FeaturesConfig


def load_config_from_yaml(path: str = '/app/config/config.yaml') -> QualityManagerConfig:
    """Load configuration from YAML file"""
    with open(path, 'r') as f:
        data = yaml.safe_load(f)
    
    return QualityManagerConfig(
        database=DatabaseConfig(**data.get('database', {})),
        uns=UNSConfig(**data.get('uns', {})),
        inspection_sources=[
            InspectionSourceConfig(**src) 
            for src in data.get('inspection_sources', [])
        ],
        spc=SPCConfig(**data.get('spc', {})),
        capability=CapabilityConfig(**data.get('capability', {})),
        capa=CAPAConfig(**data.get('capa', {})),
        intervals=IntervalsConfig(**data.get('intervals', {})),
        features=FeaturesConfig(**data.get('features', {}))
    )


def load_config_from_env() -> QualityManagerConfig:
    """Load configuration from environment variables"""
    return QualityManagerConfig(
        database=DatabaseConfig(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', '5432')),
            name=os.getenv('DB_NAME', 'quality_db'),
            user=os.getenv('DB_USER', 'quality_user'),
            password=os.getenv('DB_PASSWORD', 'quality_pass'),
            pool_size=int(os.getenv('DB_POOL_SIZE', '10'))
        ),
        uns=UNSConfig(
            mqtt_host=os.getenv('MQTT_HOST', 'localhost'),
            mqtt_port=int(os.getenv('MQTT_PORT', '1883')),
            mqtt_username=os.getenv('MQTT_USERNAME'),
            mqtt_password=os.getenv('MQTT_PASSWORD'),
            uns_site=os.getenv('UNS_SITE', 'Plant01')
        ),
        inspection_sources=[],  # Must be configured via YAML
        spc=SPCConfig(),
        capability=CapabilityConfig(),
        capa=CAPAConfig(),
        intervals=IntervalsConfig(),
        features=FeaturesConfig()
    )
