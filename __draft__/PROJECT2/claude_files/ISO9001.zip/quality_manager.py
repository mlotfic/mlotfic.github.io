"""
ISO 9001 Quality Management System - Main Orchestrator

Implements quality management following ISO 9001:2015 requirements.

This module coordinates all quality management subsystems:
- Multi-source measurement collection
- Statistical Process Control (SPC) detection
- Process capability monitoring
- Nonconformance lifecycle management
- CAPA tracking with SLA enforcement
- Customer complaint management
- Internal/external audit management
- Quality KPI calculation
- UNS publishing for plant-wide visibility
"""

import logging
import signal
import sys
import time
from datetime import datetime, timezone
from typing import Optional
from queue import Queue, Empty

from config import load_config_from_yaml, load_config_from_env, QualityManagerConfig
from database import QualityDatabase
from uns_publisher import QualityUNSPublisher

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MeasurementCollectorManager:
    """Stub collector manager - full implementation in measurement_collector.py"""
    def __init__(self, config, db, uns):
        self.queue = Queue(maxsize=50000)
    
    def start(self):
        logger.info("Measurement collectors started (stub)")
    
    def stop(self):
        logger.info("Measurement collectors stopped (stub)")
    
    def drain_queue(self, max_events=500):
        """Drain events from queue"""
        events = []
        try:
            while len(events) < max_events:
                events.append(self.queue.get_nowait())
        except Empty:
            pass
        return events


class SPCDetector:
    """Stub SPC detector - full implementation in spc_detector.py"""
    def __init__(self, db, config):
        self.db = db
    
    def evaluate(self, measurement):
        """Evaluate SPC rules for measurement"""
        # Stub - returns None (no violation)
        return None


class ProcessMonitor:
    """Stub process monitor - full implementation in process_monitor.py"""
    def __init__(self, db, uns, config):
        self.db = db
        self.uns = uns
    
    def calculate_all_capabilities(self):
        """Calculate process capability for all CQCs"""
        logger.debug("Process capability calculation (stub)")


class CAPAManager:
    """Stub CAPA manager - full implementation in capa_manager.py"""
    def __init__(self, db, uns):
        self.db = db
        self.uns = uns
    
    def check_sla_breaches(self):
        """Check for overdue CAPAs"""
        logger.debug("CAPA SLA check (stub)")


class CustomerManager:
    """Stub customer manager - full implementation in customer_manager.py"""
    def __init__(self, db, uns):
        self.db = db
        self.uns = uns
    
    def check_new_complaints(self):
        """Check for new customer complaints"""
        logger.debug("Customer feedback check (stub)")


class AuditManager:
    """Stub audit manager - full implementation in audit_manager.py"""
    def __init__(self, db, uns):
        self.db = db
        self.uns = uns
    
    def check_overdue_findings(self):
        """Check for overdue audit findings"""
        logger.debug("Audit findings check (stub)")


class QualityKPICalculator:
    """Stub KPI calculator - full implementation in kpi_calculator.py"""
    def __init__(self, db, uns):
        self.db = db
        self.uns = uns
    
    def compute_all(self):
        """Compute all quality KPIs"""
        logger.debug("KPI computation (stub)")
        return {
            'period_start': datetime.now(timezone.utc),
            'period_end': datetime.now(timezone.utc),
            'period_hours': 1,
            'defect_rate_ppm': 0,
            'first_pass_yield': 100.0
        }


class QualityManager:
    """
    Main orchestrator for ISO 9001 Quality Management System.
    
    Responsibilities:
    1. Initialize all subsystems (DB, UNS, collectors, detector, monitors)
    2. Main event loop: collect measurements → detect issues → create NCs/CAPAs
    3. Periodic tasks: SPC check, capability calc, KPI computation
    4. State publishing: NC state, CAPA state, KPIs to UNS
    """
    
    def __init__(self, config: QualityManagerConfig):
        self.config = config
        self.running = False
        
        # Initialize database
        logger.info("Initializing database connection...")
        self.db = QualityDatabase(config.database)
        
        # Initialize UNS publisher
        logger.info("Initializing UNS publisher...")
        self.uns = QualityUNSPublisher(config.uns)
        
        # Initialize measurement collectors
        logger.info("Initializing measurement collectors...")
        self.collector_manager = MeasurementCollectorManager(config, self.db, self.uns)
        
        # Initialize SPC detector
        logger.info("Initializing SPC detector...")
        self.spc_detector = SPCDetector(self.db, config)
        
        # Initialize process monitor
        logger.info("Initializing process monitor...")
        self.process_monitor = ProcessMonitor(self.db, self.uns, config)
        
        # Initialize CAPA manager
        logger.info("Initializing CAPA manager...")
        self.capa_manager = CAPAManager(self.db, self.uns)
        
        # Initialize customer manager
        logger.info("Initializing customer manager...")
        self.customer_manager = CustomerManager(self.db, self.uns)
        
        # Initialize audit manager
        logger.info("Initializing audit manager...")
        self.audit_manager = AuditManager(self.db, self.uns)
        
        # Initialize KPI calculator
        logger.info("Initializing KPI calculator...")
        self.kpi_calculator = QualityKPICalculator(self.db, self.uns)
        
        # Timing trackers
        self.last_spc_check = time.time()
        self.last_capability_calc = time.time()
        self.last_capa_sla_check = time.time()
        self.last_customer_check = time.time()
        self.last_audit_check = time.time()
        self.last_kpi_flush = time.time()
        self.last_state_publish = time.time()
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info("QualityManager initialized successfully")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        logger.info(f"Received signal {signum}, initiating graceful shutdown...")
        self.running = False
    
    def start(self):
        """Start the quality manager main loop"""
        logger.info("Starting QualityManager...")
        self.running = True
        
        # Connect database
        logger.info("Connecting to database...")
        self.db.connect()
        
        # Connect UNS
        logger.info("Connecting to UNS publisher...")
        self.uns.connect()
        
        # Start measurement collectors
        if self.config.features.measurement_collection:
            logger.info("Starting measurement collectors...")
            self.collector_manager.start()
        
        # Main event loop
        logger.info("Entering main event loop...")
        while self.running:
            try:
                self._process_measurements()
                self._run_periodic_tasks()
                time.sleep(0.5)  # 500ms cycle
            except Exception as e:
                logger.error(f"Error in main loop: {e}", exc_info=True)
                time.sleep(1)
        
        # Cleanup
        self._shutdown()
    
    def _process_measurements(self):
        """
        Process quality measurements from collector queue.
        
        Steps:
        1. Drain measurement queue (batch up to 500 measurements)
        2. Store measurements in database
        3. Publish live measurements to UNS
        4. Evaluate SPC rules (detect violations)
        5. If violation → create NC → link measurement
        """
        measurements = self.collector_manager.drain_queue(max_events=500)
        if not measurements:
            return
        
        logger.debug(f"Processing {len(measurements)} quality measurements...")
        
        # Store measurements in database (batch insert)
        try:
            self.db.store_measurements_batch(measurements)
        except Exception as e:
            logger.error(f"Failed to store measurements: {e}")
            return
        
        # Publish live measurements to UNS
        if self.config.features.uns_publishing:
            try:
                self.uns.publish_measurements_batch(measurements)
            except Exception as e:
                logger.warning(f"Failed to publish measurements to UNS: {e}")
        
        # Evaluate SPC rules for each measurement
        if self.config.features.spc_detection:
            for measurement in measurements:
                try:
                    violation = self.spc_detector.evaluate(measurement)
                    if violation:
                        # Violation detected - handle it
                        logger.info(
                            f"SPC violation detected for CQC {measurement.get('cqc_id')}: "
                            f"Rule {violation.get('rule_number')}"
                        )
                        if self.config.features.uns_publishing:
                            self.uns.publish_spc_violation(violation)
                except Exception as e:
                    logger.error(
                        f"Failed to evaluate measurement {measurement.get('measurement_id')}: {e}"
                    )
    
    def _run_periodic_tasks(self):
        """Run periodic maintenance and calculation tasks"""
        now = time.time()
        
        # SPC control limits update (every 5 minutes)
        if self.config.features.spc_detection:
            if now - self.last_spc_check >= self.config.intervals.spc_check_seconds:
                logger.info("Running SPC control limits update...")
                try:
                    # Update control limits for all CQCs
                    # (stub - full implementation in spc_detector.py)
                    self.last_spc_check = now
                except Exception as e:
                    logger.error(f"SPC check failed: {e}")
        
        # Calculate process capability (every 1 hour)
        if self.config.features.capability_monitoring:
            if now - self.last_capability_calc >= self.config.intervals.capability_calc_seconds:
                logger.info("Running process capability calculation...")
                try:
                    self.process_monitor.calculate_all_capabilities()
                    self.last_capability_calc = now
                except Exception as e:
                    logger.error(f"Capability calculation failed: {e}")
        
        # Check CAPA SLA (every 5 minutes)
        if self.config.features.capa_tracking:
            if now - self.last_capa_sla_check >= self.config.intervals.capa_sla_check_seconds:
                logger.info("Checking CAPA SLA...")
                try:
                    self.capa_manager.check_sla_breaches()
                    self.last_capa_sla_check = now
                except Exception as e:
                    logger.error(f"CAPA SLA check failed: {e}")
        
        # Check customer feedback (every 10 minutes)
        if self.config.features.customer_management:
            if now - self.last_customer_check >= self.config.intervals.customer_feedback_check_seconds:
                logger.info("Checking for new customer feedback...")
                try:
                    self.customer_manager.check_new_complaints()
                    self.last_customer_check = now
                except Exception as e:
                    logger.error(f"Customer feedback check failed: {e}")
        
        # Check audit findings (every 1 hour)
        if self.config.features.audit_management:
            if now - self.last_audit_check >= self.config.intervals.audit_check_seconds:
                logger.info("Checking audit findings for overdue actions...")
                try:
                    self.audit_manager.check_overdue_findings()
                    self.last_audit_check = now
                except Exception as e:
                    logger.error(f"Audit check failed: {e}")
        
        # Compute and publish KPIs (every 1 hour)
        if self.config.features.kpi_calculation:
            if now - self.last_kpi_flush >= self.config.intervals.kpi_computation_seconds:
                logger.info("Computing quality KPIs...")
                try:
                    kpis = self.kpi_calculator.compute_all()
                    if self.config.features.uns_publishing:
                        self.uns.publish_kpis(kpis)
                    self.last_kpi_flush = now
                except Exception as e:
                    logger.error(f"KPI computation failed: {e}")
        
        # Publish state snapshots (every 60 seconds)
        if self.config.features.uns_publishing:
            if now - self.last_state_publish >= 60:
                logger.debug("Publishing state snapshots...")
                try:
                    self._publish_state_snapshots()
                    self.last_state_publish = now
                except Exception as e:
                    logger.error(f"State publish failed: {e}")
    
    def _publish_state_snapshots(self):
        """Publish current state snapshots to UNS (retained)"""
        # NC state
        if self.config.features.nonconformance_management:
            ncs = self.db.get_active_nonconformances()
            self.uns.publish_ncs_state(ncs)
        
        # CAPA state
        if self.config.features.capa_tracking:
            capas = self.db.get_open_capas()
            self.uns.publish_capas_state(capas)
        
        # Customer complaints state
        if self.config.features.customer_management:
            complaints = self.db.get_open_complaints()
            self.uns.publish_complaints_state(complaints)
        
        # Audit findings state
        if self.config.features.audit_management:
            findings = self.db.get_open_audit_findings()
            self.uns.publish_audit_findings_state(findings)
    
    def _shutdown(self):
        """Cleanup and shutdown"""
        logger.info("Shutting down QualityManager...")
        
        # Stop collectors
        logger.info("Stopping measurement collectors...")
        self.collector_manager.stop()
        
        # Close database
        logger.info("Closing database connection...")
        self.db.close()
        
        # Disconnect UNS
        logger.info("Disconnecting UNS publisher...")
        self.uns.disconnect()
        
        logger.info("QualityManager shutdown complete")


def main():
    """Main entry point"""
    # Load configuration
    try:
        config = load_config_from_yaml('/app/config/config.yaml')
    except FileNotFoundError:
        logger.warning("config.yaml not found, using environment variables")
        config = load_config_from_env()
    
    # Create and start manager
    manager = QualityManager(config)
    manager.start()


if __name__ == '__main__':
    main()
