"""
ISO 9001 Quality Management System - UNS Publisher

MQTT/UNS publishing for quality events and state.
Publishes to standardized UNS topic structure.
"""

import logging
import json
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
import paho.mqtt.client as mqtt

from config import UNSConfig

logger = logging.getLogger(__name__)


class QualityUNSPublisher:
    """MQTT/UNS publisher for quality management data"""
    
    def __init__(self, config: UNSConfig):
        self.config = config
        self.client: Optional[mqtt.Client] = None
        self.connected = False
    
    def connect(self):
        """Connect to MQTT broker"""
        self.client = mqtt.Client()
        
        # Set callbacks
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        
        # Authentication
        if self.config.mqtt_username:
            self.client.username_pw_set(
                self.config.mqtt_username,
                self.config.mqtt_password
            )
        
        try:
            self.client.connect(
                self.config.mqtt_host,
                self.config.mqtt_port,
                keepalive=60
            )
            self.client.loop_start()
            logger.info(
                f"Connecting to MQTT broker: "
                f"{self.config.mqtt_host}:{self.config.mqtt_port}"
            )
        except Exception as e:
            logger.error(f"Failed to connect to MQTT broker: {e}")
            raise
    
    def disconnect(self):
        """Disconnect from MQTT broker"""
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
            logger.info("Disconnected from MQTT broker")
    
    def _on_connect(self, client, userdata, flags, rc):
        """Callback when connected to broker"""
        if rc == 0:
            self.connected = True
            logger.info("Connected to MQTT broker successfully")
        else:
            logger.error(f"Failed to connect to MQTT broker, code: {rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """Callback when disconnected from broker"""
        self.connected = False
        if rc != 0:
            logger.warning(f"Unexpected disconnect from MQTT broker, code: {rc}")
    
    def _publish(self, topic: str, payload: Dict[str, Any], qos: int, retain: bool = False):
        """Publish message to MQTT"""
        if not self.connected:
            logger.warning("Not connected to MQTT broker, skipping publish")
            return
        
        try:
            payload_json = json.dumps(payload, default=str)
            result = self.client.publish(topic, payload_json, qos=qos, retain=retain)
            
            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                logger.error(f"Failed to publish to {topic}, rc={result.rc}")
        except Exception as e:
            logger.error(f"Error publishing to {topic}: {e}")
    
    # ==================== Measurements ====================
    
    def publish_measurement(self, measurement: Dict[str, Any]):
        """
        Publish single measurement to live topic.
        Topic: UNS/{site}/quality/measurements/{cqc_id}/live
        QoS: 0 (high volume data)
        """
        cqc_id = measurement.get('cqc_id')
        topic = f"UNS/{self.config.uns_site}/quality/measurements/{cqc_id}/live"
        
        payload = {
            'ts_utc': measurement.get('ts_utc'),
            'source_id': measurement.get('source_id'),
            'cqc_id': cqc_id,
            'product_id': measurement.get('product_id'),
            'lot_number': measurement.get('lot_number'),
            'measured_value': measurement.get('measured_value'),
            'measurement_unit': measurement.get('measurement_unit'),
            'pass_fail': measurement.get('pass_fail'),
            'quality': measurement.get('quality')
        }
        
        self._publish(topic, payload, qos=self.config.qos_data)
    
    def publish_measurements_batch(self, measurements: List[Dict[str, Any]]):
        """Publish batch of measurements"""
        for m in measurements:
            self.publish_measurement(m)
    
    # ==================== SPC ====================
    
    def publish_spc_violation(self, violation: Dict[str, Any]):
        """
        Publish SPC rule violation event.
        Topic: UNS/{site}/quality/spc/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/spc/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': 'SPC_VIOLATION',
            'violation': {
                'cqc_id': violation.get('cqc_id'),
                'rule_number': violation.get('rule_number'),
                'rule_description': violation.get('rule_description'),
                'severity': violation.get('severity'),
                'measured_value': violation.get('measured_value'),
                'ucl': violation.get('ucl'),
                'lcl': violation.get('lcl'),
                'nc_created': violation.get('nc_created', False),
                'nc_id': violation.get('nc_id')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    # ==================== Process Capability ====================
    
    def publish_capability_result(self, result: Dict[str, Any]):
        """
        Publish process capability calculation result.
        Topic: UNS/{site}/quality/capability/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/capability/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': 'CAPABILITY_CALCULATED',
            'capability': {
                'cqc_id': result.get('cqc_id'),
                'cp': result.get('cp'),
                'cpk': result.get('cpk'),
                'pp': result.get('pp'),
                'ppk': result.get('ppk'),
                'mean': result.get('mean_value'),
                'std_dev': result.get('std_dev'),
                'capability_status': result.get('capability_status'),
                'sample_size': result.get('sample_size')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    # ==================== Nonconformances ====================
    
    def publish_nc_event(self, event_type: str, nc: Dict[str, Any]):
        """
        Publish nonconformance event.
        Topic: UNS/{site}/quality/nonconformances/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/nonconformances/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': event_type,  # NC_CREATED, STATUS_CHANGED, etc.
            'nonconformance': {
                'nc_id': nc.get('nc_id'),
                'title': nc.get('title'),
                'severity': nc.get('severity'),
                'nc_type': nc.get('nc_type'),
                'product_id': nc.get('product_id'),
                'cqc_id': nc.get('cqc_id'),
                'status': nc.get('status')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    def publish_ncs_state(self, ncs: List[Dict[str, Any]]):
        """
        Publish active nonconformances state snapshot.
        Topic: UNS/{site}/quality/nonconformances/state
        QoS: 0, Retained
        """
        topic = f"UNS/{self.config.uns_site}/quality/nonconformances/state"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'active_nonconformances': [
                {
                    'nc_id': nc.get('nc_id'),
                    'title': nc.get('title'),
                    'severity': nc.get('severity'),
                    'status': nc.get('status'),
                    'age_hours': nc.get('age_hours')
                }
                for nc in ncs
            ],
            'count': len(ncs)
        }
        
        self._publish(topic, payload, qos=self.config.qos_state, retain=True)
    
    # ==================== CAPAs ====================
    
    def publish_capa_event(self, event_type: str, capa: Dict[str, Any]):
        """
        Publish CAPA event.
        Topic: UNS/{site}/quality/capas/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/capas/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': event_type,  # CAPA_CREATED, STATUS_CHANGED, SLA_BREACHED, etc.
            'capa': {
                'capa_id': capa.get('capa_id'),
                'title': capa.get('title'),
                'capa_type': capa.get('capa_type'),
                'severity': capa.get('severity'),
                'nc_id': capa.get('nc_id'),
                'ts_target': capa.get('ts_target'),
                'sla_breached': capa.get('sla_breached', False),
                'status': capa.get('status')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    def publish_capas_state(self, capas: List[Dict[str, Any]]):
        """
        Publish open CAPAs state snapshot.
        Topic: UNS/{site}/quality/capas/state
        QoS: 0, Retained
        """
        topic = f"UNS/{self.config.uns_site}/quality/capas/state"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'open_capas': [
                {
                    'capa_id': c.get('capa_id'),
                    'title': c.get('title'),
                    'severity': c.get('severity'),
                    'status': c.get('status'),
                    'days_until_due': c.get('days_until_due'),
                    'sla_breached': c.get('sla_breached', False)
                }
                for c in capas
            ],
            'count': len(capas),
            'overdue_count': sum(1 for c in capas if c.get('sla_breached'))
        }
        
        self._publish(topic, payload, qos=self.config.qos_state, retain=True)
    
    # ==================== Customer Complaints ====================
    
    def publish_complaint_event(self, event_type: str, complaint: Dict[str, Any]):
        """
        Publish customer complaint event.
        Topic: UNS/{site}/quality/complaints/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/complaints/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': event_type,
            'complaint': {
                'complaint_id': complaint.get('complaint_id'),
                'complaint_number': complaint.get('complaint_number'),
                'customer_name': complaint.get('customer_name'),
                'severity': complaint.get('severity'),
                'product_id': complaint.get('product_id'),
                'status': complaint.get('status')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    def publish_complaints_state(self, complaints: List[Dict[str, Any]]):
        """
        Publish open customer complaints state.
        Topic: UNS/{site}/quality/complaints/state
        QoS: 0, Retained
        """
        topic = f"UNS/{self.config.uns_site}/quality/complaints/state"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'open_complaints': [
                {
                    'complaint_id': c.get('complaint_id'),
                    'complaint_number': c.get('complaint_number'),
                    'customer_name': c.get('customer_name'),
                    'severity': c.get('severity'),
                    'status': c.get('status')
                }
                for c in complaints
            ],
            'count': len(complaints)
        }
        
        self._publish(topic, payload, qos=self.config.qos_state, retain=True)
    
    # ==================== Audit Findings ====================
    
    def publish_audit_finding_event(self, event_type: str, finding: Dict[str, Any]):
        """
        Publish audit finding event.
        Topic: UNS/{site}/quality/audits/events
        QoS: 1 (important event)
        """
        topic = f"UNS/{self.config.uns_site}/quality/audits/events"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'event': event_type,
            'finding': {
                'finding_id': finding.get('finding_id'),
                'audit_ref': finding.get('audit_ref'),
                'finding_type': finding.get('finding_type'),
                'severity': finding.get('severity'),
                'clause_ref': finding.get('clause_ref'),
                'status': finding.get('status')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_events)
    
    def publish_audit_findings_state(self, findings: List[Dict[str, Any]]):
        """
        Publish open audit findings state.
        Topic: UNS/{site}/quality/audits/state
        QoS: 0, Retained
        """
        topic = f"UNS/{self.config.uns_site}/quality/audits/state"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'open_findings': [
                {
                    'finding_id': f.get('finding_id'),
                    'audit_ref': f.get('audit_ref'),
                    'finding_type': f.get('finding_type'),
                    'severity': f.get('severity'),
                    'status': f.get('status')
                }
                for f in findings
            ],
            'count': len(findings)
        }
        
        self._publish(topic, payload, qos=self.config.qos_state, retain=True)
    
    # ==================== KPIs ====================
    
    def publish_kpis(self, kpis: Dict[str, Any]):
        """
        Publish quality KPIs snapshot.
        Topic: UNS/{site}/quality/kpis/current
        QoS: 0, Retained
        """
        topic = f"UNS/{self.config.uns_site}/quality/kpis/current"
        
        payload = {
            'ts': datetime.now(timezone.utc).isoformat(),
            'kpis': {
                'period_start': kpis.get('period_start'),
                'period_end': kpis.get('period_end'),
                'period_hours': kpis.get('period_hours'),
                'defect_rate_ppm': kpis.get('defect_rate_ppm'),
                'first_pass_yield': kpis.get('first_pass_yield'),
                'rework_rate_pct': kpis.get('rework_rate_pct'),
                'scrap_rate_pct': kpis.get('scrap_rate_pct'),
                'avg_cpk': kpis.get('avg_cpk'),
                'open_nonconformances': kpis.get('open_nonconformances'),
                'open_capas': kpis.get('open_capas'),
                'overdue_capas': kpis.get('overdue_capas'),
                'customer_complaints': kpis.get('customer_complaints'),
                'audit_findings': kpis.get('audit_findings'),
                'on_time_delivery_pct': kpis.get('on_time_delivery_pct')
            }
        }
        
        self._publish(topic, payload, qos=self.config.qos_state, retain=True)
