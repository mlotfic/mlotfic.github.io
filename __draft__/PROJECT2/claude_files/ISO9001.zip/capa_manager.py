"""
CAPA (Corrective and Preventive Action) Management Module

Manages lifecycle of quality CAPAs:
OPEN → PLANNING → IMPLEMENTING → VERIFYING → EFFECTIVE → CLOSED

CAPA types:
- CORRECTIVE: Fix existing problem
- PREVENTIVE: Prevent potential problem

SLA by severity:
- CRITICAL: 7 days
- MAJOR: 14 days
- MINOR: 30 days
- OBSERVATION: 90 days
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class CAPAManager:
    """
    Manage CAPA lifecycle, SLA compliance, and effectiveness.
    """
    
    VALID_STATES = ['OPEN', 'PLANNING', 'IMPLEMENTING', 'VERIFYING', 'EFFECTIVE', 'CLOSED']
    
    VALID_TRANSITIONS = {
        'OPEN': ['PLANNING'],
        'PLANNING': ['IMPLEMENTING', 'OPEN'],
        'IMPLEMENTING': ['VERIFYING', 'PLANNING'],
        'VERIFYING': ['EFFECTIVE', 'IMPLEMENTING'],
        'EFFECTIVE': ['CLOSED'],
        'CLOSED': []
    }
    
    SLA_DAYS = {
        'CRITICAL': 7,
        'MAJOR': 14,
        'MINOR': 30,
        'OBSERVATION': 90
    }
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
    
    def create_capa(
        self,
        title: str,
        description: str,
        severity: str,
        capa_type: str,  # CORRECTIVE or PREVENTIVE
        nc_id: Optional[int] = None,
        cqc_id: Optional[str] = None,
        process_id: Optional[str] = None,
        root_cause: Optional[str] = None
    ) -> int:
        """
        Create new CAPA with auto-calculated SLA deadline.
        
        Returns CAPA ID.
        """
        # Calculate SLA deadline
        sla_days = self.SLA_DAYS.get(severity, 30)
        ts_due = datetime.now(timezone.utc) + timedelta(days=sla_days)
        
        capa_data = {
            'title': title,
            'description': description,
            'severity': severity,
            'capa_type': capa_type,
            'status': 'OPEN',
            'nc_id': nc_id,
            'cqc_id': cqc_id,
            'process_id': process_id,
            'root_cause': root_cause,
            'corrective_action': None,
            'preventive_action': None,
            'assigned_to': None,
            'ts_opened': datetime.now(timezone.utc),
            'ts_due': ts_due,
            'ts_closed': None,
            'effectiveness_verified': False,
            'sla_breached': False
        }
        
        # Store in database
        capa_id = self.db.store_capa(capa_data)
        
        # Add timeline entry
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action='CREATED',
            actor='SYSTEM',
            notes=f"CAPA created: {title}"
        )
        
        # Publish event
        self.uns.publish_capa_event({
            'event': 'CREATED',
            'ts': datetime.now(timezone.utc),
            'capa_id': capa_id,
            **capa_data
        })
        
        logger.info(f"Created CAPA CAPA-{capa_id:05d}: {title} (due: {ts_due.date()})")
        
        return capa_id
    
    def update_status(
        self,
        capa_id: int,
        new_status: str,
        actor: str = 'SYSTEM',
        notes: Optional[str] = None
    ) -> bool:
        """
        Update CAPA status with validation.
        
        Returns True if successful, False if invalid transition.
        """
        # Get current status
        capa = self.db.get_capa(capa_id)
        if not capa:
            logger.error(f"CAPA {capa_id} not found")
            return False
        
        current_status = capa['status']
        
        # Validate transition
        if new_status not in self.VALID_TRANSITIONS.get(current_status, []):
            logger.error(
                f"Invalid status transition for CAPA-{capa_id}: "
                f"{current_status} -> {new_status}"
            )
            return False
        
        # Update status
        self.db.update_capa_status(capa_id, new_status)
        
        # Set closed timestamp if closing
        if new_status == 'CLOSED':
            self.db.update_capa_field(capa_id, 'ts_closed', datetime.now(timezone.utc))
        
        # Add timeline entry
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action=f'STATUS_CHANGED_TO_{new_status}',
            actor=actor,
            notes=notes or f'Status changed to {new_status}'
        )
        
        # Publish event
        self.uns.publish_capa_event({
            'event': 'STATUS_CHANGED',
            'ts': datetime.now(timezone.utc),
            'capa_id': capa_id,
            'old_status': current_status,
            'new_status': new_status,
            'actor': actor
        })
        
        logger.info(f"CAPA-{capa_id:05d} status: {current_status} -> {new_status}")
        
        return True
    
    def add_corrective_action(
        self,
        capa_id: int,
        action: str,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Add corrective action plan to CAPA.
        """
        self.db.update_capa_field(capa_id, 'corrective_action', action)
        
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action='CORRECTIVE_ACTION_PLANNED',
            actor=actor,
            notes=notes or action
        )
        
        logger.info(f"CAPA-{capa_id:05d} corrective action planned")
        return True
    
    def add_preventive_action(
        self,
        capa_id: int,
        action: str,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Add preventive action plan to CAPA.
        """
        self.db.update_capa_field(capa_id, 'preventive_action', action)
        
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action='PREVENTIVE_ACTION_PLANNED',
            actor=actor,
            notes=notes or action
        )
        
        logger.info(f"CAPA-{capa_id:05d} preventive action planned")
        return True
    
    def verify_effectiveness(
        self,
        capa_id: int,
        is_effective: bool,
        actor: str,
        notes: Optional[str] = None
    ) -> bool:
        """
        Record effectiveness verification result.
        """
        self.db.update_capa_field(capa_id, 'effectiveness_verified', is_effective)
        
        action = 'EFFECTIVENESS_VERIFIED' if is_effective else 'EFFECTIVENESS_FAILED'
        
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action=action,
            actor=actor,
            notes=notes or f'Effectiveness verification: {"PASSED" if is_effective else "FAILED"}'
        )
        
        # If effective, can move to CLOSED
        if is_effective:
            self.update_status(capa_id, 'EFFECTIVE', actor=actor)
        
        logger.info(f"CAPA-{capa_id:05d} effectiveness: {'VERIFIED' if is_effective else 'NOT VERIFIED'}")
        return True
    
    def assign_to(
        self,
        capa_id: int,
        assignee: str,
        actor: str = 'SYSTEM'
    ) -> bool:
        """
        Assign CAPA to person.
        """
        self.db.update_capa_field(capa_id, 'assigned_to', assignee)
        
        self.db.add_capa_timeline(
            capa_id=capa_id,
            action='ASSIGNED',
            actor=actor,
            notes=f'Assigned to {assignee}'
        )
        
        logger.info(f"CAPA-{capa_id:05d} assigned to {assignee}")
        return True
    
    def scan_sla_breaches(self) -> List[Dict]:
        """
        Scan for CAPAs exceeding SLA deadline.
        
        Returns list of breached CAPAs.
        
        Called periodically (e.g., every 5 minutes).
        """
        now = datetime.now(timezone.utc)
        
        # Get all open CAPAs past due date
        breached = self.db.get_sla_breached_capas(now)
        
        for capa in breached:
            capa_id = capa['capa_id']
            
            # Mark as breached if not already
            if not capa.get('sla_breached'):
                self.db.update_capa_field(capa_id, 'sla_breached', True)
                
                self.db.add_capa_timeline(
                    capa_id=capa_id,
                    action='SLA_BREACHED',
                    actor='SYSTEM',
                    notes=f'CAPA exceeded SLA deadline of {capa["ts_due"].date()}'
                )
                
                # Publish alert
                self.uns.publish_capa_event({
                    'event': 'SLA_BREACHED',
                    'ts': now,
                    'capa_id': capa_id,
                    'title': capa['title'],
                    'severity': capa['severity'],
                    'ts_due': capa['ts_due'],
                    'days_overdue': (now - capa['ts_due']).days
                })
                
                logger.warning(f"CAPA-{capa_id:05d} SLA BREACHED (due: {capa['ts_due'].date()})")
        
        return breached
    
    def get_open_capas(self) -> List[Dict]:
        """
        Get all open (not closed) CAPAs.
        """
        return self.db.get_open_capas()
    
    def get_capa_stats(self) -> Dict:
        """
        Get summary statistics for CAPAs.
        """
        stats = {
            'total_open': 0,
            'critical_open': 0,
            'major_open': 0,
            'overdue_count': 0,
            'overdue_rate_pct': 0
        }
        
        open_capas = self.get_open_capas()
        stats['total_open'] = len(open_capas)
        
        for capa in open_capas:
            if capa['severity'] == 'CRITICAL':
                stats['critical_open'] += 1
            elif capa['severity'] == 'MAJOR':
                stats['major_open'] += 1
            
            if capa.get('sla_breached'):
                stats['overdue_count'] += 1
        
        if stats['total_open'] > 0:
            stats['overdue_rate_pct'] = (stats['overdue_count'] / stats['total_open']) * 100
        
        return stats
