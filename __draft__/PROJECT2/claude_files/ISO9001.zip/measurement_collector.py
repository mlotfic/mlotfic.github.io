"""
Quality Measurement Collection Module

Collects quality measurements from multiple source types:
- Modbus TCP (PLCs, inspection systems)
- OPC UA (SCADA, MES systems)
- File (CSV, JSON, XML inspection data)
- HTTP API (quality databases, lab systems)
- Database (SQL queries against production systems)

All sources normalized to standard Measurement dict for downstream processing.
"""

import csv
import json
import logging
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from queue import Queue
from threading import Event, Thread
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


try:
    from pymodbus.client import ModbusTcpClient
    from pymodbus.exceptions import ModbusException
    MODBUS_AVAILABLE = True
except ImportError:
    MODBUS_AVAILABLE = False
    logger.warning("pymodbus not available - Modbus collection disabled")

try:
    from opcua import Client as OPCUAClient
    from opcua import ua
    OPCUA_AVAILABLE = True
except ImportError:
    OPCUA_AVAILABLE = False
    logger.warning("opcua not available - OPC UA collection disabled")

try:
    import psycopg2
    from psycopg2 import pool
    DATABASE_COLLECTION_AVAILABLE = True
except ImportError:
    DATABASE_COLLECTION_AVAILABLE = False
    logger.warning("psycopg2 not available - Database collection disabled")


class ModbusTCPCollector:
    """
    Collect quality measurements via Modbus TCP.
    
    Use case: Read measurements from PLCs, vision systems, CMMs, gages.
    Supports holding registers only (function code 3).
    """
    
    def __init__(self, source_config: Dict, queue: Queue, db):
        self.source_id = source_config['source_id']
        self.host = source_config['host']
        self.port = source_config.get('port', 502)
        self.unit_id = source_config.get('unit_id', 1)
        self.register_map = source_config['register_map']  # List of {address, count, cqc_id, scale}
        self.poll_interval = source_config.get('poll_interval_seconds', 60)
        self.queue = queue
        self.db = db
        self.client = None
        self.running = False
        self.thread = None
    
    def start(self):
        """Start collector thread"""
        if not MODBUS_AVAILABLE:
            logger.error(f"Cannot start {self.source_id}: pymodbus not installed")
            return
        
        self.running = True
        self.thread = Thread(target=self._collect_loop, daemon=True)
        self.thread.start()
        logger.info(f"Started Modbus collector: {self.source_id} ({self.host}:{self.port})")
    
    def stop(self):
        """Stop collector thread"""
        self.running = False
        if self.client:
            self.client.close()
        if self.thread:
            self.thread.join(timeout=5)
    
    def _collect_loop(self):
        """Main collection loop"""
        while self.running:
            try:
                self._poll_once()
            except Exception as e:
                logger.error(f"Error in {self.source_id} collection: {e}")
            
            time.sleep(self.poll_interval)
    
    def _poll_once(self):
        """Poll Modbus registers once"""
        # Connect if needed
        if not self.client or not self.client.is_socket_open():
            self.client = ModbusTcpClient(self.host, port=self.port)
            if not self.client.connect():
                logger.error(f"Failed to connect to {self.host}:{self.port}")
                return
        
        ts = datetime.now(timezone.utc)
        
        for reg in self.register_map:
            try:
                result = self.client.read_holding_registers(
                    address=reg['address'],
                    count=reg.get('count', 1),
                    unit=self.unit_id
                )
                
                if result.isError():
                    logger.warning(f"Modbus error reading {reg['cqc_id']}: {result}")
                    continue
                
                # Extract value (assume first register if multi-register)
                raw_value = result.registers[0]
                scale = reg.get('scale', 1.0)
                offset = reg.get('offset', 0.0)
                measured_value = (raw_value * scale) + offset
                
                # Build normalized measurement
                measurement = {
                    'ts_utc': ts,
                    'source_id': self.source_id,
                    'cqc_id': reg['cqc_id'],
                    'product_id': reg.get('product_id'),
                    'process_id': reg.get('process_id'),
                    'lot_number': reg.get('lot_number'),
                    'serial_number': None,
                    'measured_value': measured_value,
                    'measurement_unit': reg.get('unit', ''),
                    'operator': None,
                    'equipment_id': reg.get('equipment_id'),
                    'pass_fail': None,  # Can compute based on spec limits
                    'details': {'modbus_address': reg['address'], 'raw_value': raw_value},
                    'quality': 'GOOD'
                }
                
                # Enqueue
                if not self.queue.full():
                    self.queue.put(measurement)
                else:
                    logger.warning(f"Queue full, dropping measurement from {self.source_id}")
            
            except Exception as e:
                logger.error(f"Error reading register {reg['address']}: {e}")


class FileCollector:
    """
    Collect quality measurements from files (CSV, JSON, XML).
    
    Use case: Import lab results, inspection reports, CMM data exports.
    Supports file watching (new files) or periodic re-read.
    """
    
    def __init__(self, source_config: Dict, queue: Queue, db):
        self.source_id = source_config['source_id']
        self.file_path = Path(source_config['file_path'])
        self.file_format = source_config.get('format', 'csv').lower()
        self.field_mapping = source_config['field_mapping']  # Map file columns to measurement fields
        self.poll_interval = source_config.get('poll_interval_seconds', 300)
        self.watch_mode = source_config.get('watch_mode', 'poll')  # poll or watch
        self.queue = queue
        self.db = db
        self.last_mtime = 0
        self.running = False
        self.thread = None
    
    def start(self):
        """Start collector thread"""
        self.running = True
        self.thread = Thread(target=self._collect_loop, daemon=True)
        self.thread.start()
        logger.info(f"Started File collector: {self.source_id} ({self.file_path})")
    
    def stop(self):
        """Stop collector thread"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
    
    def _collect_loop(self):
        """Main collection loop"""
        while self.running:
            try:
                if self.file_path.exists():
                    mtime = self.file_path.stat().st_mtime
                    if mtime > self.last_mtime:
                        self._read_file()
                        self.last_mtime = mtime
            except Exception as e:
                logger.error(f"Error in {self.source_id} collection: {e}")
            
            time.sleep(self.poll_interval)
    
    def _read_file(self):
        """Read and parse file"""
        logger.info(f"Reading {self.file_format} file: {self.file_path}")
        
        if self.file_format == 'csv':
            records = self._parse_csv()
        elif self.file_format == 'json':
            records = self._parse_json()
        elif self.file_format == 'xml':
            records = self._parse_xml()
        else:
            logger.error(f"Unsupported file format: {self.file_format}")
            return
        
        # Convert records to measurements
        for record in records:
            measurement = self._map_record_to_measurement(record)
            if measurement and not self.queue.full():
                self.queue.put(measurement)
    
    def _parse_csv(self) -> List[Dict]:
        """Parse CSV file"""
        records = []
        with open(self.file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append(row)
        return records
    
    def _parse_json(self) -> List[Dict]:
        """Parse JSON file"""
        with open(self.file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Handle both array of objects and nested structure
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            # Try common keys
            for key in ['results', 'data', 'measurements', 'records']:
                if key in data and isinstance(data[key], list):
                    return data[key]
        
        return [data]
    
    def _parse_xml(self) -> List[Dict]:
        """Parse XML file"""
        tree = ET.parse(self.file_path)
        root = tree.getroot()
        
        records = []
        # Assume measurements are in <measurement> or <record> tags
        for elem in root.findall('.//measurement') or root.findall('.//record'):
            record = {}
            for child in elem:
                record[child.tag] = child.text
            records.append(record)
        
        return records
    
    def _map_record_to_measurement(self, record: Dict) -> Optional[Dict]:
        """Map file record to standard measurement dict"""
        try:
            # Extract timestamp
            ts_field = self.field_mapping.get('timestamp', 'timestamp')
            ts_str = record.get(ts_field)
            if ts_str:
                # Try parsing common formats
                try:
                    ts = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
                except:
                    ts = datetime.now(timezone.utc)
            else:
                ts = datetime.now(timezone.utc)
            
            # Extract measured value
            value_field = self.field_mapping.get('measured_value', 'value')
            measured_value = float(record.get(value_field, 0))
            
            # Build measurement
            measurement = {
                'ts_utc': ts,
                'source_id': self.source_id,
                'cqc_id': record.get(self.field_mapping.get('cqc_id', 'cqc_id')),
                'product_id': record.get(self.field_mapping.get('product_id', 'product_id')),
                'process_id': record.get(self.field_mapping.get('process_id', 'process_id')),
                'lot_number': record.get(self.field_mapping.get('lot_number', 'lot_number')),
                'serial_number': record.get(self.field_mapping.get('serial_number', 'serial_number')),
                'measured_value': measured_value,
                'measurement_unit': record.get(self.field_mapping.get('unit', 'unit'), ''),
                'operator': record.get(self.field_mapping.get('operator', 'operator')),
                'equipment_id': record.get(self.field_mapping.get('equipment_id', 'equipment_id')),
                'pass_fail': record.get(self.field_mapping.get('pass_fail', 'pass_fail')),
                'details': {k: v for k, v in record.items() if k not in self.field_mapping.values()},
                'quality': 'GOOD'
            }
            
            return measurement
        
        except Exception as e:
            logger.error(f"Error mapping record: {e}")
            return None


class APICollector:
    """
    Collect quality measurements via HTTP API.
    
    Use case: Pull data from lab systems, quality databases, MES APIs.
    Supports GET/POST with JSON payloads and responses.
    """
    
    def __init__(self, source_config: Dict, queue: Queue, db):
        self.source_id = source_config['source_id']
        self.url = source_config['url']
        self.method = source_config.get('method', 'GET').upper()
        self.headers = source_config.get('headers', {})
        self.payload = source_config.get('payload', {})
        self.json_path = source_config.get('json_path', '$')
        self.field_mapping = source_config['field_mapping']
        self.poll_interval = source_config.get('poll_interval_seconds', 300)
        self.queue = queue
        self.db = db
        self.running = False
        self.thread = None
    
    def start(self):
        """Start collector thread"""
        self.running = True
        self.thread = Thread(target=self._collect_loop, daemon=True)
        self.thread.start()
        logger.info(f"Started API collector: {self.source_id} ({self.url})")
    
    def stop(self):
        """Stop collector thread"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
    
    def _collect_loop(self):
        """Main collection loop"""
        while self.running:
            try:
                self._fetch_api()
            except Exception as e:
                logger.error(f"Error in {self.source_id} collection: {e}")
            
            time.sleep(self.poll_interval)
    
    def _fetch_api(self):
        """Fetch data from API"""
        try:
            if self.method == 'GET':
                response = requests.get(self.url, headers=self.headers, timeout=30)
            elif self.method == 'POST':
                response = requests.post(self.url, headers=self.headers, json=self.payload, timeout=30)
            else:
                logger.error(f"Unsupported HTTP method: {self.method}")
                return
            
            response.raise_for_status()
            data = response.json()
            
            # Navigate JSON path
            records = self._extract_json_path(data, self.json_path)
            
            # Convert to measurements
            if isinstance(records, list):
                for record in records:
                    measurement = self._map_record_to_measurement(record)
                    if measurement and not self.queue.full():
                        self.queue.put(measurement)
            elif isinstance(records, dict):
                measurement = self._map_record_to_measurement(records)
                if measurement and not self.queue.full():
                    self.queue.put(measurement)
        
        except Exception as e:
            logger.error(f"API fetch error from {self.url}: {e}")
    
    def _extract_json_path(self, data: Any, path: str) -> Any:
        """Simple JSON path extraction (supports dot notation)"""
        if path == '$':
            return data
        
        parts = path.lstrip('$.').split('.')
        current = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
        
        return current
    
    def _map_record_to_measurement(self, record: Dict) -> Optional[Dict]:
        """Map API record to standard measurement dict"""
        try:
            measurement = {
                'ts_utc': datetime.now(timezone.utc),
                'source_id': self.source_id,
                'cqc_id': record.get(self.field_mapping.get('cqc_id', 'cqc_id')),
                'product_id': record.get(self.field_mapping.get('product_id', 'product_id')),
                'process_id': record.get(self.field_mapping.get('process_id', 'process_id')),
                'lot_number': record.get(self.field_mapping.get('lot_number', 'lot_number')),
                'serial_number': record.get(self.field_mapping.get('serial_number', 'serial_number')),
                'measured_value': float(record.get(self.field_mapping.get('measured_value', 'value'), 0)),
                'measurement_unit': record.get(self.field_mapping.get('unit', 'unit'), ''),
                'operator': record.get(self.field_mapping.get('operator', 'operator')),
                'equipment_id': record.get(self.field_mapping.get('equipment_id', 'equipment_id')),
                'pass_fail': record.get(self.field_mapping.get('pass_fail', 'pass_fail')),
                'details': {k: v for k, v in record.items() if k not in self.field_mapping.values()},
                'quality': 'GOOD'
            }
            
            return measurement
        
        except Exception as e:
            logger.error(f"Error mapping API record: {e}")
            return None


class MeasurementCollectorManager:
    """
    Manages multiple measurement collectors from different sources.
    """
    
    def __init__(self, source_configs: List[Dict], queue: Queue, db):
        self.queue = queue
        self.db = db
        self.collectors = []
        
        # Instantiate collectors based on config
        for config in source_configs:
            source_type = config['type'].lower()
            
            if source_type == 'modbus_tcp':
                collector = ModbusTCPCollector(config, queue, db)
            elif source_type == 'file':
                collector = FileCollector(config, queue, db)
            elif source_type == 'api':
                collector = APICollector(config, queue, db)
            else:
                logger.warning(f"Unknown source type: {source_type}")
                continue
            
            self.collectors.append(collector)
        
        logger.info(f"Initialized {len(self.collectors)} measurement collectors")
    
    def start(self):
        """Start all collectors"""
        for collector in self.collectors:
            collector.start()
        logger.info("All measurement collectors started")
    
    def stop(self):
        """Stop all collectors"""
        for collector in self.collectors:
            collector.stop()
        logger.info("All measurement collectors stopped")
