-- ============================================================================
-- ISO 9001 Quality Management System - Database Schema
-- ============================================================================
-- PostgreSQL 15+ required
-- Optional: TimescaleDB for time-series optimization
--
-- This schema implements ISO 9001:2015 requirements for:
-- - Clause 8.5: Production and service provision
-- - Clause 8.7: Control of nonconforming outputs
-- - Clause 9.1: Monitoring, measurement, analysis
-- - Clause 9.2: Internal audit
-- - Clause 10.2: Nonconformity and corrective action
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ==================== Product & Process Master Data ====================

CREATE TABLE products (
    product_id VARCHAR(50) PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL,
    product_family VARCHAR(100),
    part_number VARCHAR(100),
    revision VARCHAR(20),
    customer VARCHAR(200),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE processes (
    process_id VARCHAR(50) PRIMARY KEY,
    process_name VARCHAR(200) NOT NULL,
    process_type VARCHAR(50) CHECK (process_type IN (
        'MACHINING', 'ASSEMBLY', 'INSPECTION', 'TESTING', 'PACKAGING', 'OTHER'
    )),
    department VARCHAR(100),
    owner VARCHAR(100),
    description TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==================== Critical Quality Characteristics (CQCs) ====================

CREATE TABLE critical_quality_characteristics (
    cqc_id VARCHAR(50) PRIMARY KEY,
    cqc_name VARCHAR(200) NOT NULL,
    product_id VARCHAR(50) REFERENCES products(product_id),
    process_id VARCHAR(50) REFERENCES processes(process_id),
    characteristic_type VARCHAR(50) CHECK (characteristic_type IN (
        'DIMENSION', 'HARDNESS', 'SURFACE_FINISH', 'PRESSURE', 
        'TORQUE', 'WEIGHT', 'TEMPERATURE', 'OTHER'
    )),
    measurement_unit VARCHAR(20),
    lower_spec_limit NUMERIC(15, 6),
    upper_spec_limit NUMERIC(15, 6),
    target_value NUMERIC(15, 6),
    target_cpk NUMERIC(5, 2) DEFAULT 1.33,
    warning_cpk NUMERIC(5, 2) DEFAULT 1.0,
    critical_cpk NUMERIC(5, 2) DEFAULT 0.67,
    sample_size INTEGER DEFAULT 30,
    control_method VARCHAR(50) DEFAULT 'SPC' CHECK (control_method IN (
        'SPC', '100PCT_INSPECTION', 'SAMPLING', 'NONE'
    )),
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==================== Quality Measurements ====================

CREATE TABLE quality_measurements (
    measurement_id BIGSERIAL PRIMARY KEY,
    ts_utc TIMESTAMP WITH TIME ZONE NOT NULL,
    source_id VARCHAR(100) NOT NULL,
    cqc_id VARCHAR(50) NOT NULL REFERENCES critical_quality_characteristics(cqc_id),
    product_id VARCHAR(50) REFERENCES products(product_id),
    process_id VARCHAR(50) REFERENCES processes(process_id),
    lot_number VARCHAR(100),
    serial_number VARCHAR(100),
    measured_value NUMERIC(15, 6) NOT NULL,
    measurement_unit VARCHAR(20),
    operator VARCHAR(100),
    equipment_id VARCHAR(100),
    pass_fail VARCHAR(10) CHECK (pass_fail IN ('PASS', 'FAIL')),
    details JSONB,
    quality VARCHAR(20) DEFAULT 'GOOD' CHECK (quality IN ('GOOD', 'BAD', 'UNCERTAIN')),
    nc_id INTEGER,  -- Link to nonconformance if measurement triggered NC
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for time-series queries
CREATE INDEX idx_qm_ts_cqc ON quality_measurements(ts_utc DESC, cqc_id);
CREATE INDEX idx_qm_cqc ON quality_measurements(cqc_id, ts_utc DESC);
CREATE INDEX idx_qm_product ON quality_measurements(product_id, ts_utc DESC);
CREATE INDEX idx_qm_lot ON quality_measurements(lot_number) WHERE lot_number IS NOT NULL;

-- TimescaleDB hypertable (optional - uncomment if using TimescaleDB)
-- SELECT create_hypertable('quality_measurements', 'ts_utc', chunk_time_interval => INTERVAL '1 month');
-- SELECT add_compression_policy('quality_measurements', INTERVAL '7 days');

-- ==================== SPC Control Limits ====================

CREATE TABLE spc_control_limits (
    cqc_id VARCHAR(50) PRIMARY KEY REFERENCES critical_quality_characteristics(cqc_id),
    ts_calculated TIMESTAMP WITH TIME ZONE NOT NULL,
    center_line NUMERIC(15, 6) NOT NULL,
    ucl NUMERIC(15, 6) NOT NULL,  -- Upper Control Limit (mean + 3σ)
    lcl NUMERIC(15, 6) NOT NULL,  -- Lower Control Limit (mean - 3σ)
    usl NUMERIC(15, 6),  -- Upper Spec Limit (from CQC)
    lsl NUMERIC(15, 6),  -- Lower Spec Limit (from CQC)
    sample_size INTEGER,
    sigma NUMERIC(15, 6)  -- Standard deviation
);

CREATE TABLE spc_violations (
    violation_id BIGSERIAL PRIMARY KEY,
    ts_utc TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    cqc_id VARCHAR(50) NOT NULL REFERENCES critical_quality_characteristics(cqc_id),
    measurement_id BIGINT REFERENCES quality_measurements(measurement_id),
    rule_number INTEGER NOT NULL CHECK (rule_number BETWEEN 1 AND 8),
    rule_description TEXT NOT NULL,
    severity VARCHAR(20) CHECK (severity IN ('INFO', 'WARNING', 'CRITICAL')),
    nc_id INTEGER  -- Link to created nonconformance
);

CREATE INDEX idx_spc_viol_ts ON spc_violations(ts_utc DESC);
CREATE INDEX idx_spc_viol_cqc ON spc_violations(cqc_id, ts_utc DESC);

-- ==================== Process Capability ====================

CREATE TABLE capability_results (
    result_id BIGSERIAL PRIMARY KEY,
    cqc_id VARCHAR(50) NOT NULL REFERENCES critical_quality_characteristics(cqc_id),
    ts_calculated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    cp NUMERIC(5, 2),  -- Process potential
    cpk NUMERIC(5, 2), -- Process performance
    pp NUMERIC(5, 2),  -- Long-term process potential
    ppk NUMERIC(5, 2), -- Long-term process performance
    mean_value NUMERIC(15, 6),
    std_dev NUMERIC(15, 6),
    sample_size INTEGER,
    capability_status VARCHAR(20) CHECK (capability_status IN (
        'CAPABLE', 'WARNING', 'CRITICAL', 'INSUFFICIENT_DATA'
    ))
);

CREATE INDEX idx_cap_cqc_ts ON capability_results(cqc_id, ts_calculated DESC);

-- ==================== Nonconformances ====================

CREATE TABLE nonconformances (
    nc_id SERIAL PRIMARY KEY,
    ts_detected TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    title VARCHAR(500) NOT NULL,
    description TEXT,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('CRITICAL', 'MAJOR', 'MINOR')),
    nc_type VARCHAR(20) CHECK (nc_type IN ('PRODUCT', 'PROCESS', 'SYSTEM', 'SUPPLIER')),
    product_id VARCHAR(50) REFERENCES products(product_id),
    process_id VARCHAR(50) REFERENCES processes(process_id),
    cqc_id VARCHAR(50) REFERENCES critical_quality_characteristics(cqc_id),
    lot_number VARCHAR(100),
    quantity_affected INTEGER,
    detected_by VARCHAR(100),
    containment_action TEXT,
    root_cause TEXT,
    corrective_action TEXT,
    status VARCHAR(30) DEFAULT 'DETECTED' CHECK (status IN (
        'DETECTED', 'CONTAINED', 'INVESTIGATING', 'RESOLVED', 'CLOSED'
    )),
    ts_contained TIMESTAMP WITH TIME ZONE,
    ts_investigated TIMESTAMP WITH TIME ZONE,
    ts_resolved TIMESTAMP WITH TIME ZONE,
    ts_closed TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_nc_status ON nonconformances(status) WHERE status NOT IN ('CLOSED');
CREATE INDEX idx_nc_severity ON nonconformances(severity, ts_detected DESC);
CREATE INDEX idx_nc_product ON nonconformances(product_id, ts_detected DESC);

CREATE TABLE nonconformance_timeline (
    timeline_id BIGSERIAL PRIMARY KEY,
    nc_id INTEGER NOT NULL REFERENCES nonconformances(nc_id) ON DELETE CASCADE,
    ts_utc TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    action VARCHAR(100) NOT NULL,
    actor VARCHAR(100),
    notes TEXT
);

CREATE INDEX idx_nc_timeline ON nonconformance_timeline(nc_id, ts_utc DESC);

-- ==================== CAPAs ====================

CREATE TABLE capas (
    capa_id SERIAL PRIMARY KEY,
    ts_created TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    title VARCHAR(500) NOT NULL,
    description TEXT,
    capa_type VARCHAR(20) NOT NULL CHECK (capa_type IN ('CORRECTIVE', 'PREVENTIVE')),
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('CRITICAL', 'MAJOR', 'MINOR', 'OBSERVATION')),
    nc_id INTEGER REFERENCES nonconformances(nc_id),
    complaint_id INTEGER,  -- References customer_complaints
    finding_id INTEGER,    -- References audit_findings
    root_cause TEXT,
    corrective_action TEXT,
    preventive_action TEXT,
    assigned_to VARCHAR(100),
    ts_target TIMESTAMP WITH TIME ZONE NOT NULL,  -- SLA deadline
    effectiveness_criteria TEXT,
    status VARCHAR(30) DEFAULT 'OPEN' CHECK (status IN (
        'OPEN', 'PLANNING', 'IMPLEMENTING', 'VERIFYING', 
        'EFFECTIVE', 'CLOSED', 'CANCELLED'
    )),
    ts_implementing TIMESTAMP WITH TIME ZONE,
    ts_verifying TIMESTAMP WITH TIME ZONE,
    ts_effective TIMESTAMP WITH TIME ZONE,
    ts_closed TIMESTAMP WITH TIME ZONE,
    sla_breached BOOLEAN DEFAULT false
);

CREATE INDEX idx_capa_status ON capas(status) WHERE status NOT IN ('CLOSED', 'CANCELLED');
CREATE INDEX idx_capa_target ON capas(ts_target) WHERE status NOT IN ('CLOSED', 'CANCELLED');
CREATE INDEX idx_capa_severity ON capas(severity, ts_created DESC);

-- ==================== Customer Complaints ====================

CREATE TABLE customer_complaints (
    complaint_id SERIAL PRIMARY KEY,
    ts_received TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    complaint_number VARCHAR(100) UNIQUE NOT NULL,
    customer_name VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('CRITICAL', 'MAJOR', 'MINOR')),
    product_id VARCHAR(50) REFERENCES products(product_id),
    lot_number VARCHAR(100),
    serial_number VARCHAR(100),
    quantity_affected INTEGER,
    root_cause TEXT,
    containment_action TEXT,
    corrective_action TEXT,
    customer_notification TEXT,
    status VARCHAR(30) DEFAULT 'RECEIVED' CHECK (status IN (
        'RECEIVED', 'ACKNOWLEDGED', 'INVESTIGATING', 'RESOLVED', 'CLOSED'
    )),
    ts_acknowledged TIMESTAMP WITH TIME ZONE,
    ts_resolved TIMESTAMP WITH TIME ZONE,
    ts_closed TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_complaint_status ON customer_complaints(status) WHERE status != 'CLOSED';
CREATE INDEX idx_complaint_customer ON customer_complaints(customer_name, ts_received DESC);

-- ==================== Audit Findings ====================

CREATE TABLE audit_findings (
    finding_id SERIAL PRIMARY KEY,
    audit_ref VARCHAR(100) NOT NULL,
    finding_type VARCHAR(30) NOT NULL CHECK (finding_type IN (
        'NON_CONFORMANCE', 'OBSERVATION', 'OPPORTUNITY'
    )),
    description TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('CRITICAL', 'MAJOR', 'MINOR')),
    clause_ref VARCHAR(50),  -- ISO 9001 clause reference (e.g., "8.5.1")
    process_id VARCHAR(50) REFERENCES processes(process_id),
    owner VARCHAR(100),
    corrective_action TEXT,
    target_date DATE,
    status VARCHAR(30) DEFAULT 'OPEN' CHECK (status IN (
        'OPEN', 'IN_PROGRESS', 'CLOSED', 'VERIFIED'
    )),
    ts_closed TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_finding_status ON audit_findings(status) WHERE status NOT IN ('CLOSED', 'VERIFIED');
CREATE INDEX idx_finding_audit ON audit_findings(audit_ref);

-- ==================== Quality KPIs ====================

CREATE TABLE quality_kpis (
    kpi_id BIGSERIAL PRIMARY KEY,
    ts_utc TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    period_hours NUMERIC(10, 2),
    defect_rate_ppm NUMERIC(10, 2),        -- Defects per million opportunities
    first_pass_yield NUMERIC(5, 2),        -- First pass yield %
    rework_rate_pct NUMERIC(5, 2),         -- Rework rate %
    scrap_rate_pct NUMERIC(5, 2),          -- Scrap rate %
    avg_cpk NUMERIC(5, 2),                 -- Average Cpk across all CQCs
    open_nonconformances INTEGER,
    open_capas INTEGER,
    overdue_capas INTEGER,
    customer_complaints INTEGER,
    audit_findings INTEGER,
    on_time_delivery_pct NUMERIC(5, 2)    -- On-time delivery %
);

CREATE INDEX idx_kpi_ts ON quality_kpis(ts_utc DESC);

-- ==================== Shipments (for OTD calculation) ====================

CREATE TABLE shipments (
    shipment_id BIGSERIAL PRIMARY KEY,
    ts_promised TIMESTAMP WITH TIME ZONE NOT NULL,
    ts_actual TIMESTAMP WITH TIME ZONE,
    product_id VARCHAR(50) REFERENCES products(product_id),
    quantity INTEGER,
    on_time BOOLEAN GENERATED ALWAYS AS (ts_actual <= ts_promised) STORED
);

CREATE INDEX idx_shipment_ts ON shipments(ts_actual DESC);

-- ==================== Process Steps (for RTY calculation) ====================

CREATE TABLE process_steps (
    step_id SERIAL PRIMARY KEY,
    process_id VARCHAR(50) NOT NULL REFERENCES processes(process_id),
    step_number INTEGER NOT NULL,
    step_name VARCHAR(200) NOT NULL,
    fpy NUMERIC(5, 2),  -- First pass yield for this step
    UNIQUE(process_id, step_number)
);

-- ============================================================================
-- VIEWS
-- ============================================================================

-- Active nonconformances with age
CREATE VIEW active_nonconformances AS
SELECT 
    nc_id,
    ts_detected,
    title,
    severity,
    nc_type,
    product_id,
    process_id,
    status,
    EXTRACT(EPOCH FROM (NOW() - ts_detected)) / 3600 AS age_hours,
    ts_contained,
    ts_investigated,
    ts_resolved
FROM nonconformances
WHERE status NOT IN ('CLOSED')
ORDER BY severity DESC, ts_detected ASC;

-- Latest capability per CQC
CREATE VIEW capability_summary AS
SELECT DISTINCT ON (cqc_id)
    cqc_id,
    ts_calculated,
    cp,
    cpk,
    pp,
    ppk,
    mean_value,
    std_dev,
    sample_size,
    capability_status
FROM capability_results
ORDER BY cqc_id, ts_calculated DESC;

-- CAPA status with overdue flags
CREATE VIEW capa_status AS
SELECT 
    capa_id,
    ts_created,
    title,
    capa_type,
    severity,
    status,
    ts_target,
    CASE 
        WHEN ts_target < NOW() AND status NOT IN ('CLOSED', 'CANCELLED')
        THEN true
        ELSE false
    END AS overdue,
    EXTRACT(DAY FROM (ts_target - NOW())) AS days_until_due,
    assigned_to,
    nc_id
FROM capas
WHERE status NOT IN ('CLOSED', 'CANCELLED')
ORDER BY ts_target ASC;

-- Customer complaint summary
CREATE VIEW customer_complaint_summary AS
SELECT 
    complaint_id,
    ts_received,
    complaint_number,
    customer_name,
    severity,
    status,
    EXTRACT(EPOCH FROM (NOW() - ts_received)) / 3600 AS age_hours,
    product_id
FROM customer_complaints
WHERE status != 'CLOSED'
ORDER BY severity DESC, ts_received ASC;

-- Audit finding summary
CREATE VIEW audit_finding_summary AS
SELECT 
    finding_id,
    audit_ref,
    finding_type,
    severity,
    clause_ref,
    status,
    target_date,
    CASE 
        WHEN target_date < CURRENT_DATE AND status NOT IN ('CLOSED', 'VERIFIED')
        THEN true
        ELSE false
    END AS overdue
FROM audit_findings
WHERE status NOT IN ('CLOSED', 'VERIFIED')
ORDER BY severity DESC;

-- Quality dashboard snapshot
CREATE VIEW quality_dashboard AS
SELECT
    (SELECT COUNT(*) FROM active_nonconformances) AS open_nonconformances,
    (SELECT COUNT(*) FROM active_nonconformances WHERE severity = 'CRITICAL') AS critical_nonconformances,
    (SELECT COUNT(*) FROM capas WHERE status NOT IN ('CLOSED', 'CANCELLED')) AS open_capas,
    (SELECT COUNT(*) FROM capas WHERE overdue = true) AS overdue_capas,
    (SELECT COUNT(*) FROM customer_complaints WHERE status != 'CLOSED') AS open_complaints,
    (SELECT COUNT(*) FROM audit_findings WHERE status NOT IN ('CLOSED', 'VERIFIED')) AS open_findings,
    (SELECT AVG(cpk) FROM capability_summary) AS avg_cpk,
    (SELECT COUNT(*) FROM capability_summary WHERE capability_status = 'CRITICAL') AS critical_capabilities,
    (SELECT COUNT(*) FROM quality_measurements 
     WHERE ts_utc >= NOW() - INTERVAL '24 hours') AS measurements_24h,
    (SELECT COUNT(*) FROM spc_violations 
     WHERE ts_utc >= NOW() - INTERVAL '24 hours') AS spc_violations_24h;

-- ============================================================================
-- INITIAL DATA (Optional - can be loaded from CSV templates instead)
-- ============================================================================

-- You can uncomment these to insert sample data, or use the CSV import script

-- INSERT INTO products (product_id, product_name) VALUES
-- ('PROD_SHAFT_001', 'Drive Shaft Assembly'),
-- ('PROD_HOUSING_001', 'Motor Housing');

-- INSERT INTO processes (process_id, process_name, process_type) VALUES
-- ('PROC_CNC_TURN_001', 'CNC Turning Center', 'MACHINING'),
-- ('PROC_CMM_001', 'Coordinate Measuring Machine', 'INSPECTION');

-- ============================================================================
-- GRANTS (Adjust based on your security requirements)
-- ============================================================================

-- Grant appropriate permissions
-- GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO quality_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO quality_user;
