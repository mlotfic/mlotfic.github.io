"""
QMS Control Monitoring Module

Monitors compliance with ISO 9001:2015 clauses:
- Clause 4: Context of the organization
- Clause 5: Leadership
- Clause 6: Planning
- Clause 7: Support
- Clause 8: Operation
- Clause 9: Performance evaluation
- Clause 10: Improvement

Automated assessors evaluate control effectiveness based on live data.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class QMSControlMonitor:
    """
    Monitor ISO 9001:2015 clause compliance and effectiveness.
    """
    
    def __init__(self, db, uns, site_name: str):
        self.db = db
        self.uns = uns
        self.site_name = site_name
        
        # Effectiveness threshold
        self.effectiveness_threshold = 70  # Below 70% = INEFFECTIVE
    
    def assess_all(self):
        """
        Assess all QMS controls.
        
        Called periodically (e.g., every 24 hours).
        """
        logger.info("Assessing QMS control compliance...")
        
        controls = self.db.get_qms_controls()
        
        for control in controls:
            try:
                self.assess_control(control['control_id'])
            except Exception as e:
                logger.error(f"Error assessing control {control['control_id']}: {e}")
    
    def assess_control(self, control_id: str) -> Optional[Dict]:
        """
        Assess effectiveness of a single control.
        
        Uses automated assessors when available, otherwise manual assessment.
        """
        control = self.db.get_qms_control(control_id)
        if not control:
            logger.warning(f"Control {control_id} not found")
            return None
        
        # Try automated assessment
        assessor = self._get_automated_assessor(control_id)
        
        if assessor:
            effectiveness = assessor(self.db, control_id)
            
            if effectiveness is not None:
                # Store assessment
                assessment = {
                    'control_id': control_id,
                    'assessed_at': datetime.now(timezone.utc),
                    'assessor': 'AUTOMATED',
                    'effectiveness': effectiveness,
                    'status_at_time': control['status'],
                    'findings': f"Automated assessment: {effectiveness:.1f}%"
                }
                
                self.db.store_control_assessment(assessment)
                
                # Update control effectiveness
                self.db.update_qms_control_field(control_id, 'effectiveness', effectiveness)
                self.db.update_qms_control_field(control_id, 'last_assessed', datetime.now(timezone.utc))
                
                # Mark as INEFFECTIVE if below threshold
                if effectiveness < self.effectiveness_threshold and control['status'] != 'INEFFECTIVE':
                    self.db.update_qms_control_field(control_id, 'status', 'INEFFECTIVE')
                    
                    # Publish alert
                    self.uns.publish_control_event({
                        'event': 'EFFECTIVENESS_DEGRADED',
                        'control_id': control_id,
                        'clause': control['clause'],
                        'effectiveness': effectiveness,
                        'threshold': self.effectiveness_threshold
                    })
                    
                    logger.warning(f"Control {control_id} marked INEFFECTIVE (effectiveness: {effectiveness:.1f}%)")
                
                logger.info(f"Control {control_id} assessed: {effectiveness:.1f}%")
                return assessment
        
        # No automated assessor available
        logger.debug(f"No automated assessor for {control_id}")
        return None
    
    def _get_automated_assessor(self, control_id: str):
        """
        Get automated assessor function for control.
        
        Returns callable(db, control_id) -> float or None.
        """
        # Map control IDs to assessor functions
        ASSESSORS = {
            'CTRL_8.5': self._assess_production_control,
            'CTRL_8.6': self._assess_product_release,
            'CTRL_8.7': self._assess_nc_control,
            'CTRL_9.1.1': self._assess_customer_satisfaction,
            'CTRL_9.1.2': self._assess_measurement_analysis,
            'CTRL_10.2': self._assess_capa_effectiveness
        }
        
        return ASSESSORS.get(control_id)
    
    def _assess_production_control(self, db, control_id: str) -> Optional[float]:
        """
        Assess 8.5 Production and service provision.
        
        Effectiveness = FPY (First Pass Yield) across all processes.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=7)
        processes = db.get_active_processes()
        
        if not processes:
            return None
        
        fpy_values = []
        for process in processes:
            stats = db.get_process_stats(process['process_id'], since=cutoff)
            if stats and stats['total_units'] > 0:
                fpy = (stats['passed_units'] / stats['total_units']) * 100
                fpy_values.append(fpy)
        
        if fpy_values:
            return sum(fpy_values) / len(fpy_values)
        
        return None
    
    def _assess_product_release(self, db, control_id: str) -> Optional[float]:
        """
        Assess 8.6 Release of products and services.
        
        Effectiveness = % of products with all required checks completed.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=7)
        
        # Get recent production
        total = db.count_produced_units(since=cutoff)
        if total == 0:
            return None
        
        # Get units with all checks complete
        checked = db.count_fully_inspected_units(since=cutoff)
        
        return (checked / total) * 100
    
    def _assess_nc_control(self, db, control_id: str) -> Optional[float]:
        """
        Assess 8.7 Control of nonconforming outputs.
        
        Effectiveness = % of NCs properly contained and resolved.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        
        total_ncs = db.count_nonconformances(since=cutoff)
        if total_ncs == 0:
            return 100.0  # No NCs = effective
        
        # Count NCs with containment action
        contained = db.count_contained_nonconformances(since=cutoff)
        
        return (contained / total_ncs) * 100
    
    def _assess_customer_satisfaction(self, db, control_id: str) -> Optional[float]:
        """
        Assess 9.1.1 Monitoring, measurement, analysis and evaluation - Customer satisfaction.
        
        Effectiveness = Average customer satisfaction score.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=90)
        
        avg_score = db.get_avg_customer_satisfaction(since=cutoff)
        
        if avg_score is not None:
            # Convert to percentage (assume 1-5 scale)
            return (avg_score / 5.0) * 100
        
        return None
    
    def _assess_measurement_analysis(self, db, control_id: str) -> Optional[float]:
        """
        Assess 9.1.2 Monitoring, measurement, analysis and evaluation.
        
        Effectiveness = % of CQCs with active control charts.
        """
        total_cqcs = db.count_active_cqcs()
        if total_cqcs == 0:
            return None
        
        with_charts = db.count_cqcs_with_control_charts()
        
        return (with_charts / total_cqcs) * 100
    
    def _assess_capa_effectiveness(self, db, control_id: str) -> Optional[float]:
        """
        Assess 10.2 Nonconformity and corrective action.
        
        Effectiveness = % of CAPAs verified as effective.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=90)
        
        total_capas = db.count_closed_capas(since=cutoff)
        if total_capas == 0:
            return None
        
        effective = db.count_effective_capas(since=cutoff)
        
        return (effective / total_capas) * 100
    
    def get_control_gaps(self) -> List[Dict]:
        """
        Identify controls that are PLANNED or INEFFECTIVE.
        
        Returns list of control gap summaries.
        """
        return self.db.get_control_gaps()
