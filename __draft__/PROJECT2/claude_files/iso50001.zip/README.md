# ISO 50001 Energy Manager

**Production-ready energy-management module | Modbus + PostgreSQL + MQTT/UNS | ISO 50001 compliant**

Mirrors the three-layer architecture established in the ISA-18.2 Alarm Manager
(device → domain-logic → historian) and maps it cleanly onto ISO 50001 concepts:
Significant Energy Uses, baselines, deviation detection, KPIs, action plans, and
nonconformances.

---

## Architecture at a Glance

```
┌─────────────────────────────────────────────────────────────┐
│  DEVICE LAYER   – Energy meters (Modbus TCP)                │
│    kW · kVAR · kWh · PF · V · I   quality: GOOD/BAD/UNC    │
└──────────────────────────┬──────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  ISO 50001 LAYER  – Energy Manager (Python)                 │
│    SEU mapping · Baselines (SMA / Regression / Fixed)       │
│    Deviation detection (anti-chatter) · KPI engine          │
│    Action plans · Nonconformances                           │
└──────────────────────────┬──────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  HISTORIAN / REPORTING  – PostgreSQL + MQTT/UNS             │
│    Time-series readings · Deviation lifecycle               │
│    Hourly / Daily / Monthly KPIs · Audit trail              │
└─────────────────────────────────────────────────────────────┘
```

---

## Prerequisites

| Service | Version | Role |
|---|---|---|
| Docker + Compose | 24+ | Container orchestration |
| PostgreSQL | 15 | Time-series storage (TimescaleDB optional) |
| Eclipse Mosquitto | 2.0 | MQTT broker |
| Modbus-capable meters | — | TCP port 502 accessible from host |

No cloud dependencies. Everything runs on-premises.

---

## Quick Start

```bash
# 1. Clone / extract this directory
cd energy_manager

# 2. Edit meter IPs  →  config/config.yaml  →  meters[].host
# 3. Bring up the full stack
docker compose up -d --build

# 4. Import reference data (SEUs, meters, alerts, baselines)
docker compose exec energy-manager python /app/scripts/import_csv.py

# 5. Watch the logs
docker compose logs -f energy-manager

# 6. Run the test suite
docker compose exec energy-manager python /app/tests/test_energy_manager.py
```

UIs available immediately:

| Tool | URL |
|---|---|
| pgAdmin (database) | http://localhost:5050 |
| MQTT Explorer | http://localhost:4000 |

---

## Project Layout

```
energy_manager/
├── config/
│   ├── config.yaml            # App config: DB, MQTT, meter list, tuning
│   └── mosquitto.conf         # Broker settings
├── docs/
│   └── energy_baseline_guide.md   # Theory, best practices, golden rules
├── migrations/
│   └── 001_create_energy_tables.sql   # Full schema (10 tables, 4 views)
├── scripts/
│   └── import_csv.py          # Bulk-load CSVs → database (upsert-safe)
├── src/
│   ├── energy_manager.py      # Main orchestrator (poll → detect → KPI → publish)
│   ├── meter_poller.py        # Modbus TCP reader + interval-kWh computation
│   ├── baseline_engine.py     # SMA / Regression / Fixed + deviation detector
│   ├── kpi_calculator.py      # SEC, EI, BCR, Savings, Peak Reduction
│   ├── database.py            # PostgreSQL access (pool, upsert, queries)
│   ├── uns_publisher.py       # MQTT/UNS publish helpers
│   └── config.py              # Dataclass config + YAML/env loading
├── templates/
│   ├── seu_definition.csv         # 10 example SEUs
│   ├── energy_meter_map.csv       # 13 meter→SEU mappings
│   ├── alert_definition.csv       # 10 deviation alert configs
│   └── baseline_config.csv        # 10 baseline method configs
├── tests/
│   └── test_energy_manager.py     # 5-test integration + unit suite
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md                  # ← you are here
```

---

## Configuration

### config/config.yaml

The single source of truth for the running application. Key sections:

```yaml
database:                    # PostgreSQL connection
  host: postgres
  port: 5432
  name: energy_db
  user: energy_user
  password: change_me_in_production

mqtt:                        # MQTT broker
  host: mosquitto
  port: 1883
  site: EgyptPlant           # Becomes UNS/{site}/…

meters:                      # One block per physical meter
  - meter_id: EM_COMP_01
    host: 192.168.1.50       # ← change to real IP
    port: 502
    unit_id: 1
    poll_interval_ms: 5000
    # Modbus register addresses (adjust to your meter firmware)
    reg_active_power_kw:     0
    reg_reactive_power_kvar: 1
    reg_active_energy_kwh:   2   # cumulative; 32-bit if energy_reg_is_32bit
    reg_power_factor:        4
    reg_voltage_v:           5
    reg_current_a:           6
    # Scale factors: raw_register_value × scale = engineering_value
    scale_power:             0.1
    scale_energy:            0.1
    scale_pf:                0.01
    scale_voltage:           0.1
    scale_current:           0.1
    energy_reg_is_32bit:     true   # two consecutive registers

baseline:
  moving_avg_days:  30      # SMA window
  min_readings:     7       # days before baseline is valid
  recalc_interval_h: 6      # how often to recompute SMA from history

alerts:
  default_warning_pct:  10
  default_critical_pct: 25
  default_min_consecutive: 3

features:
  enable_deviation_alerts:   true
  enable_kpi_calculation:    true
  enable_uns_publishing:     true
```

### Environment overrides

Every value in config.yaml can be overridden via environment variables
(set in docker-compose.yml or your shell):

| Variable | Overrides |
|---|---|
| `DB_HOST` / `DB_PORT` / `DB_NAME` / `DB_USER` / `DB_PASSWORD` | database.* |
| `MQTT_HOST` / `MQTT_PORT` | mqtt.host / mqtt.port |
| `UNS_SITE` | mqtt.site |
| `CONFIG_PATH` | path to config.yaml |

---

## CSV Template Guide

### seu_definition.csv — Significant Energy Uses

```
seu_id,seu_name,category,location,description,annual_kwh,pct_of_total,responsible_owner,last_review,active
SEU_COMP_01,Compressor Station 01,EQUIPMENT,Plant-A,Primary air compressor,1200000,28.5,Mech-Team-01,2025-12-15,TRUE
```

| Field | Type | Notes |
|---|---|---|
| seu_id | string | Unique key; referenced by other CSVs |
| category | enum | `EQUIPMENT`, `AREA`, `PROCESS` |
| pct_of_total | float | ≥5 % qualifies as SEU automatically |
| active | bool | FALSE = excluded from alerting & KPIs |

### energy_meter_map.csv — Meter → SEU mapping

```
meter_id,seu_id,contribution_pct,notes
EM_COMP_01,SEU_COMP_01,100,Direct sub-meter
EM_PUMP_01,SEU_PUMP_MAIN,50,Shared meter – split 50/50
```

One meter can map to **multiple** SEUs (contribution_pct sums to 100 across
all rows for that meter). One SEU can be fed by **multiple** meters.

### alert_definition.csv — Deviation thresholds

```
alert_id,seu_id,description,warning_pct,critical_pct,min_consecutive,comparison_period,enabled,notes
ALR_COMP01_HI,SEU_COMP_01,Compressor over-energy,10,25,3,HOURLY,TRUE,Standard threshold
```

| Field | Notes |
|---|---|
| warning_pct | Deviation fires WARNING when actual exceeds baseline by this % |
| critical_pct | Escalates to CRITICAL |
| min_consecutive | Anti-chatter: number of consecutive readings required before firing |
| comparison_period | `HOURLY` or `DAILY` — granularity of the baseline comparison |

### baseline_config.csv — Baseline method per SEU

```
seu_id,method,window_days,min_samples,independent_var,fixed_kwh_per_hour,cal_start,cal_end,notes
SEU_COMP_01,SMA,30,7,,,,,Standard 30-day moving average
SEU_PUMP_MAIN,REGRESSION,30,14,production_units,,,,"Calibrate after 14 days of data"
SEU_LIGHTING_SITE,FIXED,,,,20.5,,,"Constant expected consumption"
```

| method | Required fields | Notes |
|---|---|---|
| `SMA` | window_days, min_samples | Default. No external data needed. |
| `REGRESSION` | window_days, min_samples, independent_var | Needs a data feed for the independent variable |
| `FIXED` | fixed_kwh_per_hour | Manual constant; no history needed |

---

## MQTT / UNS Topic Map

```
UNS/
  {site}/                              # e.g. EgyptPlant
    devices/
      {meter_id}/                      # e.g. EM_COMP_01
        energy/
          readings                     # QoS 0 · every poll cycle
          state                       # QoS 0 · retained · current snapshot
    scada/
      energy/
        deviations/
          events                       # QoS 1 · lifecycle transitions
          state                       # QoS 0 · retained · all active deviations
        kpis/
          {seu_id}                     # QoS 0 · retained · latest KPI per SEU
```

### Payload examples

**Energy reading** (`devices/EM_COMP_01/energy/readings`)
```json
{
  "ts": "2026-02-03T06:30:15.231Z",
  "power":      { "active_kw": 142.5, "reactive_kvar": 38.2, "factor": 0.92 },
  "energy":     { "cumulative_kwh": 98765.4, "interval_kwh": 0.198, "interval_s": 5.0 },
  "electrical": { "voltage_v": 400.2, "current_a": 205.3 },
  "quality": "GOOD"
}
```

**Deviation event** (`scada/energy/deviations/events`)
```json
{
  "ts": "2026-02-03T06:30:15.350Z",
  "event": "DETECTED",
  "deviation": {
    "meter_id": "EM_COMP_01", "seu_id": "SEU_COMP_01",
    "alert_id": "ALR_COMP01_HI", "severity": "CRITICAL",
    "actual_kwh": 155.0, "baseline_kwh": 120.0, "deviation_pct": 29.2
  }
}
```

**KPI snapshot** (`scada/energy/kpis/SEU_COMP_01`)
```json
{
  "ts": "2026-02-03T07:00:00.000Z",
  "period": { "type": "HOURLY", "start": "2026-02-03T06:00:00Z", "end": "2026-02-03T07:00:00Z" },
  "actual_kwh": 145.2, "baseline_kwh": 120.0,
  "kpis": {
    "sec": 0.726,
    "energy_intensity": 0.290,
    "baseline_comparison_ratio": 1.210,
    "savings_kwh": -25.2,
    "savings_pct": -21.0,
    "peak_reduction_kw": -15.5
  }
}
```

---

## Useful Database Queries

```sql
-- Current active deviations with SEU names
SELECT * FROM active_energy_deviations ORDER BY age_minutes;

-- Latest KPI per SEU (all period types)
SELECT * FROM latest_kpis_per_seu;

-- Monthly energy summary for management review
SELECT * FROM monthly_energy_summary ORDER BY year DESC, month DESC;

-- Open or overdue action plans
SELECT * FROM open_action_plans_view ORDER BY overdue DESC;

-- Raw readings for a specific meter in the last hour
SELECT ts_utc, active_power_kw, interval_kwh, quality
FROM energy_readings
WHERE meter_id = 'EM_COMP_01'
  AND ts_utc >= NOW() - INTERVAL '1 hour'
ORDER BY ts_utc;
```

---

## Operational Best Practices

**SEU vs Meter.** Never treat site-total as the only meter. Sub-meter at the
SEU level; the site-total meter is cross-check only.  The `energy_meter_seu_map`
table handles the many-to-many relationship and contribution splitting.

**Baseline selection.** Start every SEU on SMA.  Once you have a reliable
production-data feed (CSV, API, or direct DB write), calibrate a regression model.
Only switch after R² ≥ 0.7.  Use FIXED only for genuinely constant loads like
corridor lighting.

**Deviation thresholds.** 10 % warning / 25 % critical is a safe default for
most SEUs.  Tighten to 8/20 for high-value processes; loosen to 15/35 for
inherently noisy loads (e.g. cooling towers).  Always keep min_consecutive ≥ 2.

**KPI cadence.** Hourly KPIs give early warning.  The `monthly_energy_summary`
view rolls them up for management review automatically.  Avoid computing KPIs
only monthly — you will miss issues until they become expensive.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| No readings in DB | Modbus TCP connection failed | Verify `host` / `port` / `unit_id` in config.yaml; check firewall on port 502 |
| Baseline stays NULL | Not enough history | Wait `min_samples` days (default 7); check `energy_baselines` table |
| Deviation flood | `min_consecutive` too low or noisy meter | Increase `min_consecutive`; verify meter quality states |
| MQTT messages missing | Broker not reachable | Check Mosquitto container logs; verify `MQTT_HOST` env var |
| KPIs all NULL | No `production_units` or `reference_area` | For SEC: provide production data feed. For EI: set `reference_area_m2` in SEU config |
| Counter rollover error | 32-bit cumulative kWh overflowed | Confirm `energy_reg_is_32bit: true` in meter config |

---

## Performance Tuning

| Scale | Recommendation |
|---|---|
| 1–5 meters | Vanilla PostgreSQL 15. Default settings are fine. |
| 5–50 meters | Enable TimescaleDB hypertable on `energy_readings`. Uncomment the `SELECT create_hypertable(…)` lines in the migration. |
| 50+ meters | Add compression policy (7-day uncompressed → 1-year compressed). Consider read-replica for dashboards. |

Batch inserts (`execute_values`) are used by default for all high-frequency
writes.  Log level should be `WARNING` or `ERROR` in production.

---

## Security Checklist

- [ ] Change `POSTGRES_PASSWORD` in docker-compose.yml (and config.yaml)
- [ ] Change `PGADMIN_DEFAULT_PASSWORD`
- [ ] Enable MQTT authentication: edit `mosquitto.conf`, set `allow_anonymous false`, create password file
- [ ] Use TLS for MQTT (port 8883) in production
- [ ] Firewall: restrict 502 (Modbus), 5432 (PG), 1883 (MQTT) to internal network only
- [ ] Schedule daily `pg_dump` backups with offsite retention

---

*Last updated: 2026-02-03 | Version 1.0*
